"""Compressible Reese--Govindjee material with a current-step implicit tangent.

Stress and time units must be consistent. F and Cv are three dimensional,
including in plane strain. The caller owns accepted history: update never
mutates Cv_old. The returned state is for committing after global convergence.

The spectral backward uses divided differences with their repeated-root limit;
it never differentiates eigenvectors. It supplies first derivatives of stress
for a forward boundary-value solve, not derivatives through committed histories
or higher derivatives. Parameter fitting must rerun the complete history.
"""
from dataclasses import dataclass
import math

import torch


@dataclass(frozen=True)
class Material:
    mu0: float
    k0: float
    mu1: float
    k1: float
    eta_d: float
    eta_v: float

    def __post_init__(self):
        values = (self.mu0, self.k0, self.mu1, self.k1, self.eta_d)
        if any(not math.isfinite(x) or x <= 0 for x in values):
            raise ValueError("Moduli and deviatoric viscosity must be finite and positive")
        if self.eta_v <= 0 or math.isnan(self.eta_v):
            raise ValueError("Volumetric viscosity must be positive or infinity")

    @classmethod
    def from_young(cls, e0, e1, nu, tau_d, tau_v=None):
        if not -1 < nu < .5:
            raise ValueError("Poisson ratio must lie between -1 and 0.5")
        mu0, mu1 = e0/(2*(1+nu)), e1/(2*(1+nu))
        k0, k1 = e0/(3*(1-2*nu)), e1/(3*(1-2*nu))
        return cls(mu0, k0, mu1, k1, tau_d*mu1,
                   (tau_d if tau_v is None else tau_v)*k1)


def principal_law(e, mu, bulk):
    """Principal Kirchhoff stress, deviatoric stress, and d(tau)/d(e)."""
    eye = torch.eye(3, dtype=e.dtype, device=e.device)
    # Near a strongly relaxed root the principal distortions are almost equal.
    # Subtracting their exponentials loses stress digits that high mobility
    # amplifies in the local residual. expm1 evaluates the same law stably.
    dm1 = torch.expm1(2*(e-e.mean(-1, keepdim=True)))
    d = dm1+1
    td = mu*(dm1-dm1.mean(-1, keepdim=True))
    je2 = torch.exp(2*e.sum(-1))
    tv = bulk/2*torch.expm1(2*e.sum(-1))
    hd = 2*mu*(torch.diag_embed(d)-(d[..., :, None]+d[..., None, :])/3
               + d.sum(-1)[..., None, None]/9)
    h = hd + bulk*je2[..., None, None]*torch.ones_like(eye)
    return td+tv[..., None], td, h, hd, je2


def principal_update(e_trial, dt, m, *, tolerance=2e-12, max_iterations=35):
    """Solve the three coupled log-stretch equations (RG 1998, Eq. 60)."""
    if dt < 0 or not math.isfinite(dt):
        raise ValueError("Time increment must be finite and nonnegative")
    eye = torch.eye(3, dtype=e_trial.dtype, device=e_trial.device)

    def evaluate(e):
        tau, td, h, hd, je2 = principal_law(e, m.mu1, m.k1)
        tv = m.k1/2*torch.expm1(2*e.sum(-1))
        flow = td/(2*m.eta_d)+tv[..., None]/(3*m.eta_v)
        jac = eye+dt*(hd/(2*m.eta_d)
                      + m.k1*je2[..., None, None]/(3*m.eta_v))
        return e-e_trial+dt*flow, jac, tau, h

    e = e_trial.clone()
    for _ in range(max_iterations):
        r, jac, tau, h = evaluate(e)
        if float(r.abs().max()) <= tolerance:
            return e, tau, h, jac
        delta = torch.linalg.solve(jac, r[..., None]).squeeze(-1)
        old_norm = r.square().sum(-1)
        step = torch.ones_like(old_norm)
        for _ in range(25):
            candidate = e-step[..., None]*delta
            rr = evaluate(candidate)[0]
            good = (rr.square().sum(-1) <= old_norm) | (old_norm <= tolerance**2)
            if bool(good.all()):
                e = candidate
                break
            step = torch.where(good, step, step/2)
        else:
            raise RuntimeError("Local viscoelastic Newton line search failed")
    raise RuntimeError("Local viscoelastic Newton did not converge")


class _Branch(torch.autograd.Function):
    @staticmethod
    def forward(ctx, b_trial, dt, material):
        values, q = torch.linalg.eigh(b_trial)
        if bool((values <= 0).any()):
            raise ValueError("Trial elastic metric must be positive definite")
        e, tau, h, jac = principal_update(.5*values.log(), dt, material)
        de_dtrial = torch.linalg.solve(jac, torch.eye(3, device=q.device, dtype=q.dtype).expand_as(jac))
        d_tau_d_values = (h @ de_dtrial)/(2*values[..., None, :])
        gap = values[..., :, None]-values[..., None, :]
        numerator = tau[..., :, None]-tau[..., None, :]
        near = gap.abs() <= 1e-7*values.abs().amax(-1)[..., None, None]
        diag = d_tau_d_values.diagonal(dim1=-2, dim2=-1)
        limit = .5*(diag[..., :, None]+diag[..., None, :]
                     -d_tau_d_values-d_tau_d_values.transpose(-1, -2))
        divided = torch.where(near, limit, numerator/torch.where(near, torch.ones_like(gap), gap))
        divided = divided-torch.diag_embed(divided.diagonal(dim1=-2, dim2=-1))
        ctx.save_for_backward(q, d_tau_d_values, divided)
        stress = (q*tau[..., None, :]) @ q.transpose(-1, -2)
        be = (q*torch.exp(2*e)[..., None, :]) @ q.transpose(-1, -2)
        ctx.mark_non_differentiable(be)
        return stress, be

    @staticmethod
    @torch.autograd.function.once_differentiable
    def backward(ctx, grad_stress, grad_be):
        q, jac, divided = ctx.saved_tensors
        g = q.transpose(-1, -2) @ grad_stress @ q
        g = .5*(g+g.transpose(-1, -2))
        diagonal = torch.einsum("...ij,...i->...j", jac, g.diagonal(dim1=-2, dim2=-1))
        result = q @ (divided*g+torch.diag_embed(diagonal)) @ q.transpose(-1, -2)
        return result, None, None


def elastic(b, mu, bulk):
    je2 = torch.linalg.det(b)
    eye = torch.eye(3, dtype=b.dtype, device=b.device)
    iso = b*je2[..., None, None].pow(-1/3)
    trace = iso.diagonal(dim1=-2, dim2=-1).sum(-1)
    tau = mu*(iso-trace[..., None, None]*eye/3)+bulk/2*(je2-1)[..., None, None]*eye
    energy = mu/2*(trace-3)+bulk/4*(je2-1-je2.log())
    return tau, energy


@dataclass
class Response:
    piola: torch.Tensor
    cauchy: torch.Tensor
    kirchhoff: torch.Tensor
    cv: torch.Tensor
    energy: torch.Tensor
    dissipation: torch.Tensor


def update(f, cv_old, dt, material):
    """Trial response with Cv_old fixed; accepting/rolling back is caller-owned."""
    if f.shape[-2:] != (3, 3) or cv_old.shape != f.shape:
        raise ValueError("F and Cv must have equal (..., 3, 3) shapes")
    j = torch.linalg.det(f)
    if bool((j <= 0).any()) or not bool(torch.isfinite(f).all()):
        raise ValueError("F must be finite and orientation preserving")
    if cv_old.requires_grad:
        raise ValueError("This current-step API requires fixed accepted history")
    b_trial = f @ torch.linalg.solve(cv_old, f.transpose(-1, -2))
    tau1, be = _Branch.apply(b_trial, dt, material)
    tau0, w0 = elastic(f @ f.transpose(-1, -2), material.mu0, material.k0)
    _, w1 = elastic(be, material.mu1, material.k1)
    tau = tau0+tau1
    piola = torch.linalg.solve(f, tau.transpose(-1, -2)).transpose(-1, -2)
    with torch.no_grad():
        cv = f.transpose(-1, -2) @ torch.linalg.solve(be, f)
        cv = .5*(cv+cv.transpose(-1, -2))
        trace = tau1.diagonal(dim1=-2, dim2=-1).sum(-1)
        dev = tau1-trace[..., None, None]*torch.eye(3, device=f.device, dtype=f.dtype)/3
        dissipation = dev.square().sum((-2, -1))/(2*material.eta_d)+trace.square()/(9*material.eta_v)
    return Response(piola, tau/j[..., None, None], tau, cv, w0+w1, dissipation)
