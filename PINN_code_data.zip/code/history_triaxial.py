"""Principal tensor operations for axisymmetric stress control."""
import numpy as np

def law(e, mu, bulk):
    d = np.exp(2*(e-np.mean(e)))
    je2 = np.exp(2*sum(e))
    td = mu*(d-np.mean(d))
    tau = td+bulk/2*(je2-1)
    h = 2*mu*(np.diag(d)-(d[:, None]+d[None, :])/3+sum(d)/9)+bulk*je2
    return tau, td, h


def expand(x):
    return np.array([x[0], x[0], x[1]])


def reduce_h(h):
    return np.array([[h[0, 0]+h[0, 1], h[0, 2]], [h[2, 0]+h[2, 1], h[2, 2]]])
