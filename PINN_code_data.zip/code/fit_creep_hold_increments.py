"""Load measured creep curves and evaluate hold increments."""
import csv
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data/laboratory"

def load_curves():
    curves = []
    for cp in (15, 20, 25):
        path = SOURCE / f"phyllite_creep_strain_vs_time_cp{cp}.csv"
        with path.open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        levels = sorted({float(r["series"].replace("MPa", "")) for r in rows})
        for stage, q in enumerate(levels):
            data = sorted((float(r["time_h"]), float(r["axial_strain_1e-2"])*.01)
                          for r in rows if float(r["series"].replace("MPa", "")) == q)
            times, strains = np.array(data).T
            curves.append({"cp": cp, "q": q, "stage": stage+1, "levels": levels,
                           "t": times, "strain": strains, "increment": strains-strains[0],
                           "file": str(path.relative_to(ROOT)).replace("\\", "/")})
    return curves


def metrics(curve, prediction):
    error = prediction[1:]-curve["increment"][1:]
    rms = float(np.sqrt(np.mean(error**2)))
    observed_range = float(np.ptp(curve["increment"]))
    return {"confinement_MPa": curve["cp"], "deviatoric_stress_MPa": curve["q"],
            "stage": curve["stage"], "samples": len(curve["t"]),
            "first_time_h": float(curve["t"][0]), "last_time_h": float(curve["t"][-1]),
            "measured_increment_last": float(curve["increment"][-1]),
            "predicted_increment_last": float(prediction[-1]),
            "increment_rmse": rms,
            "rmse_over_observed_range": rms/observed_range if observed_range else None}
