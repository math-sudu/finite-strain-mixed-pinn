"""Survey observables and forecast origins for explicit measurement layouts.

Coordinates are in metres. No geometry or point coordinates are inferred from
clearance, a channel name, or a circular mean radial displacement.
"""
from __future__ import annotations

import numpy as np


def forecast_from_last_reading(times, observed, predicted, cutoff):
    """Anchor predicted increments to the last observation available at cutoff.

    This changes the observation origin once. It does not alter material states,
    fit a scale, or use subsequent observations to update the forecast.
    """
    anchor = np.flatnonzero(np.asarray(times) <= cutoff)[-1]
    return np.asarray(predicted) + observed[anchor] - predicted[anchor], anchor


def forecast_from_recent_trend(times, observed, cutoff, history_days):
    """Extrapolate a past-only least-squares slope from the last reading."""
    times, observed = np.asarray(times), np.asarray(observed)
    past = (times <= cutoff) & (times >= cutoff-history_days)
    if past.sum() < 2:
        raise ValueError("The recent-trend baseline needs at least two past readings")
    anchor = np.flatnonzero(times <= cutoff)[-1]
    slope = np.polyfit(times[past]-times[anchor], observed[past]-observed[anchor], 1)[0]
    return observed[anchor]+slope*(times-times[anchor]), float(slope)


def line_closure(reference_endpoints_m, current_endpoints_m):
    """Return L(reference) - L(current), positive for closure.

    The last two array axes are (2 endpoints, 2 or 3 coordinates). Leading axes
    may describe times/cases. Positions at the actual survey reference epoch
    must include any displacement accumulated before the first reading.
    """
    reference = np.asarray(reference_endpoints_m, dtype=float)
    current = np.asarray(current_endpoints_m, dtype=float)
    for positions in (reference, current):
        if (positions.ndim < 2 or positions.shape[-2] != 2
                or positions.shape[-1] not in (2, 3)):
            raise ValueError("two endpoint positions in 2D or 3D are required")
        if not np.isfinite(positions).all():
            raise ValueError("endpoint positions must be finite and supplied")
    if reference.shape[-1] != current.shape[-1]:
        raise ValueError("reference and current coordinates must have the same dimension")
    length_ref = np.linalg.norm(reference[..., 1, :] - reference[..., 0, :], axis=-1)
    if np.any(length_ref <= 0):
        raise ValueError("reference endpoints must be distinct")
    length_now = np.linalg.norm(current[..., 1, :] - current[..., 0, :], axis=-1)
    return length_ref - length_now
