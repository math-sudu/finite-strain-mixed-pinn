"""Source-section geometry and observation mapping for the +860 field history."""
from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import torch

from horseshoe_geometry import HorseshoeWall
from prepare_field_section import horizontal_intersections

ROOT = Path(__file__).resolve().parents[1]


class FieldSection:
    def __init__(self, path):
        self.data = json.loads((ROOT/path).read_text(encoding="utf-8"))
        self.arcs = {b["role"]: b["circular_arcs"] for b in self.data["boundaries"]}
        self.outer = HorseshoeWall.from_json(ROOT/path, device="cpu")
        outer = {a["arc_id"]: a for a in self.arcs["initial_support_outer"]}
        inner = {a["arc_id"]: a for a in self.arcs["initial_support_inner"]}
        self.crown = outer["crown"]["center"][1]+outer["crown"]["radius"]
        self.invert = outer["invert"]["center"][1]-outer["invert"]["radius"]
        self.inner_crown = inner["crown"]["center"][1]+inner["crown"]["radius"]
        self.thickness = self.data["source_dimensions"]["initial_support_thickness_m"]
        self.lengths = self.outer.radii*self.outer.sweeps
        self.offsets = torch.cat((self.lengths[:1]*0, self.lengths.cumsum(0)[:-1]))
        self.perimeter = float(self.lengths.sum())

    def ray_radius(self, points):
        """Differentiable intersection radius, including the derivative of the wall."""
        radius = points.norm(dim=-1, keepdim=True)
        direction = points/radius.clamp_min(torch.finfo(points.dtype).eps)
        direction = torch.where(radius > 0, direction, points.new_tensor([1., 0.]))
        centers, radii = self.outer.centers, self.outer.radii
        dot = (direction[:, None, :]*centers).sum(-1)
        disc = radii.square()-centers.square().sum(-1)+dot.square()
        root = dot+disc.clamp_min(torch.finfo(points.dtype).eps).sqrt()
        wall = root[:, :, None]*direction[:, None, :]
        angle = torch.atan2(wall[..., 1]-centers[:, 1], wall[..., 0]-centers[:, 0])
        relative = torch.remainder(angle-self.outer.starts, 2*torch.pi)
        relative = torch.where(relative > 2*torch.pi-1e-10, 0., relative)
        valid = (disc >= 0) & (root > 0) & (relative <= self.outer.sweeps+1e-10)
        index = valid.to(torch.long).argmax(-1)
        return root.gather(1, index[:, None]).squeeze(1)

    def arc_length(self, points):
        projection = self.outer.project(points)
        index = projection.arc_index
        radial = projection.point-self.outer.centers[index]
        relative = torch.remainder(torch.atan2(radial[:, 1], radial[:, 0])
                                   -self.outer.starts[index], 2*torch.pi)
        relative = torch.where(relative > 2*torch.pi-1e-10, 0., relative)
        return self.offsets[index]+self.outer.radii[index]*relative

    def survey(self, depths):
        """Inner-face readings inherit the displacement of their outer normal foot.

        The support thickness is treated as kinematically constant: this maps
        monitoring to ground displacement without introducing a lining model.
        """
        inner = [[0., self.inner_crown]]
        outer = [[0., self.crown]]
        for depth in depths:
            y = self.inner_crown-depth
            for x, angle in horizontal_intersections(self.arcs["initial_support_inner"], y):
                normal = np.array([np.cos(np.deg2rad(angle)), np.sin(np.deg2rad(angle))])
                inner.append([x, y])
                outer.append((np.array([x, y])+self.thickness*normal).tolist())
        return torch.tensor(inner), torch.tensor(outer)

    def core_rays(self, counts, levels, order):
        """Wall rays split where each excavation interface reaches the contour."""
        g, w = np.polynomial.legendre.leggauss(order)
        for arc, count in zip(self.arcs["initial_support_outer"], counts):
            start, sweep, radius = arc["start_rad"], arc["sweep_rad"], arc["radius"]
            center = np.array(arc["center"])
            cuts = list(np.linspace(0., sweep, count+1))
            for level in levels:
                height = (level-center[1])/radius
                if abs(height) <= 1:
                    angle = np.arcsin(height)
                    for candidate in (angle, np.pi-angle):
                        relative = (candidate-start) % (2*np.pi)
                        if 1e-10 < relative < sweep-1e-10:
                            cuts.append(relative)
            cuts = sorted(set(cuts))
            for low, high in zip(cuts[:-1], cuts[1:]):
                angle = start+(low+high)/2+(high-low)/2*g
                wall = center+radius*np.stack((np.cos(angle), np.sin(angle)), -1)
                derivative = radius*np.stack((-np.sin(angle), np.cos(angle)), -1)
                measure = (wall[:, 0]*derivative[:, 1]-wall[:, 1]*derivative[:, 0])*w*(high-low)/2
                yield wall, measure


def resolve_field_configuration(config):
    if "field_geometry" not in config:
        return config
    c = deepcopy(config)
    section = FieldSection(c["field_geometry"])
    if c["survey_mapping"] != "inner_normal_constant_displacement":
        raise ValueError("Unknown field observation mapping")
    c.pop("semiaxis_y", None)
    if "progressive_release" in c:
        stage = c["progressive_release"]
        stage["interface_y_m"] = section.crown-stage["depth_below_outer_crown_m"]
        if not section.invert < stage["interface_y_m"] < section.crown:
            raise ValueError("The bench interface must lie inside the source section")
    if "invert_release" in c:
        stage = c["invert_release"]
        stage["interface_y_m"] = section.invert+stage["retained_thickness_m"]
        if not section.invert < stage["interface_y_m"] < c["progressive_release"]["interface_y_m"]:
            raise ValueError("The retained invert must lie below the bench")
    return c
