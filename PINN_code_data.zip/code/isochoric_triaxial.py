"""Independent continuous triaxial specialization of history_isochoric.

State is (log lambda_r, log lambda_z, log lambda_v,r); incompressible viscous
flow sets log lambda_v,z=-2 log lambda_v,r. Total volume remains compressible.
"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root

from history_triaxial import law, expand, reduce_h


def initial_state(cp, material):
    y = np.arcsinh(-cp/material.bulk)/3
    return np.array([y,y,0.])


def mapping(cp, material, convention="nominal_piston", gauge="original", area="original"):
    stretch = np.exp(initial_state(cp,material)[0])
    if gauge not in ("original","confined") or area not in ("original","confined"):
        raise ValueError("Unknown gauge/area reference")
    if convention not in ("nominal_piston","cauchy"):
        raise ValueError("Unknown stress convention")
    return dict(convention=convention, gauge_stretch=1. if gauge=="original" else stretch,
                area_ratio=1. if area=="original" else stretch**2)


def response(y, v, material):
    tau0, _, h0 = law(expand(y),material.mu0,material.bulk)
    s, _, h1 = law(expand(y)-np.array([v,v,-2*v]),material.mu1,0.)
    logj=2*y[0]+y[1]
    p=-material.bulk*np.sinh(logj)
    q=np.sqrt(1.5*(s@s))
    if material.qstar is None:
        multiplier=1.
    else:
        x=q/material.qstar
        multiplier=1+x*x/6+x**4/120 if x<1e-3 else np.sinh(x)/x
    g=np.exp(-material.pressure_a*(p-material.pressure_ref)/material.pressure_ref)*multiplier/(2*material.eta)
    return tau0+s,h0+h1,h1,g*s[0]


def system(y,v,cp,q,material,observation):
    tau,h,h1,flow=response(y,v,material)
    j=np.exp(2*y[0]+y[1])
    if observation["convention"]=="nominal_piston":
        force=q*observation["area_ratio"]*np.exp(y[1])
        target=np.array([-j*cp,-j*cp-force])
        dy=np.array([[-2*j*cp,-j*cp],[-2*j*cp,-j*cp-force]])
    else:
        target=-j*np.array([cp,cp+q])
        dy=target[:,None]*np.array([[2.,1.]])
    return tau[[0,2]]-target,reduce_h(h)-dy,reduce_h(h1),flow


def hold(state,cp,q,material,observation,end,*,rtol=2e-8,atol=2e-11):
    solved=root(lambda y:system(y,state[2],cp,q,material,observation)[0],state[:2],
                jac=lambda y:system(y,state[2],cp,q,material,observation)[1],tol=1e-10)
    if np.max(abs(system(solved.x,state[2],cp,q,material,observation)[0]))>2e-7:
        raise RuntimeError("Triaxial load-step equilibrium did not converge")

    def ode(t,z):
        _,a,h1,flow=system(z[:2],z[2],cp,q,material,observation)
        ydot=np.linalg.solve(a,h1 @ np.array([flow,-2*flow]))
        return np.array([ydot[0],ydot[1],flow])

    solution=solve_ivp(ode,(0.,end),np.r_[solved.x,state[2]],method="Radau",
                       rtol=rtol,atol=atol,dense_output=True)
    if not solution.success:
        raise RuntimeError(solution.message)
    defect=system(solution.y[:2,-1],solution.y[2,-1],cp,q,material,observation)[0]
    if np.max(abs(defect))>2e-4:
        raise RuntimeError(f"Stress constraint drift: {defect}")
    return solution


def predict(curves,material,convention="nominal_piston",gauge="original",area="original",preceding_hold=24.):
    outputs={}
    for cp in sorted({c["cp"] for c in curves}):
        state=initial_state(cp,material)
        observation=mapping(cp,material,convention,gauge,area)
        for c in sorted([c for c in curves if c["cp"]==cp],key=lambda c:c["stage"]):
            solution=hold(state,cp,c["q"],material,observation,max(preceding_hold,float(c["t"][-1])))
            z=solution.sol(c["t"])
            axial=np.exp(z[1])
            zero_stretch=observation["gauge_stretch"]
            outputs[(cp,c["stage"])]=dict(increment=(axial[0]-axial)/zero_stretch,
                engineering_strain=(zero_stretch-axial)/zero_stretch,
                radial_stretch=np.exp(z[0]),axial_stretch=axial,
                cv_radial=np.exp(2*z[2]),cv_axial=np.exp(-4*z[2]))
            state=solution.sol(preceding_hold)
    return outputs
