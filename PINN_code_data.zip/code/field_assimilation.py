"""Sequential observation learning for the finite-history field PINN.

The learned discrepancy is a generalized weak-equilibrium load. It is carried
between readings; material memory is always obtained from the constitutive
return at the learned deformation, never from a survey offset or an FE field.
"""
import csv
import json
from pathlib import Path

import numpy as np
import torch

from application_observations import forecast_from_recent_trend

CHANNELS = ("GD00", "SL01", "SL02", "SL03")
ROOT = Path(__file__).resolve().parents[1]


def discrepancy_rule(spec):
    # Archived protocols predate the explicit choice of where the rate acts.
    return spec.get("load_rule", "propagated" if "discrepancy_history_day" in spec else "held")


def read_observations(config):
    records = []
    with (ROOT/config["deformation_source"]).open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            records.append(dict(channel=row["channel_id"],
                time_day=float(row["elapsed_time_day"])+config["deformation_to_pressure_day"],
                value_mm=float(row["cumulative_deformation_mm"])))
    return sorted(records, key=lambda row: (row["time_day"], row["channel"]))


def observation_events(records):
    # Merge only roundoff-equivalent timestamps, not the staggered surveys.
    events = []
    for day in sorted({row["time_day"] for row in records}):
        if not events or day-events[-1] > 1e-9:
            events.append(day)
    return events


def monitoring_round(day):
    return int(np.floor(day+.5))


def survey_operator(coefficients, basis, points):
    """Absolute geometric readings; differences retain the deformed reference."""
    displacement = basis[:7] @ coefficients.T
    current = points[:7]+displacement
    pairs = current[1:].reshape(3, 2, 2)
    initial = points[1:7].reshape(3, 2, 2)
    closure = (initial[:, 1]-initial[:, 0]).norm(dim=-1)-(pairs[:, 1]-pairs[:, 0]).norm(dim=-1)
    return 1000*torch.cat((-displacement[0, 1:2], closure))


def survey_jacobian(coefficients, basis, points):
    coefficient = coefficients.detach().requires_grad_(True)
    readings = survey_operator(coefficient, basis, points)
    return torch.stack([torch.autograd.grad(value, coefficient, retain_graph=True)[0].ravel()
                        for value in readings]).detach().numpy()


def residual_allowance(matrix, scale, observation_jacobian, response_scales, allowed):
    """Set the weak-loss scale by its local displacement sensitivity.

    A unit normalized weak residual induces S = H (D^-1 K)^+ in observation
    space. The single allowance makes its typical channel response equal to
    the specified physical response scales. These are regularization scales,
    not estimated noise covariances or claims about instrument accuracy.
    """
    normalized = matrix/scale[:, None]
    column = np.linalg.norm(normalized, axis=0).clip(1e-12)
    inverse = np.linalg.pinv(normalized/column[None, :], rcond=1e-10)
    sensitivity = (observation_jacobian/column[None, :]) @ inverse
    magnitude = np.linalg.norm(sensitivity[:, allowed], axis=1)
    if np.any(magnitude <= 0) or not np.isfinite(magnitude).all():
        raise ValueError("The neural representation must respond at every survey channel")
    return float(np.median(np.asarray(response_scales)/magnitude))


def fit_coefficients(initial, evaluate, matrix_at, scale, discrepancy, observations, day,
                     allowed, core_tolerance):
    """Jointly learn the output layer, holding the previous material state fixed."""
    indices, expected, data_count = observations.analysis_targets(day, initial)
    if not data_count:
        return initial, discrepancy, dict(analysis_iterations=0, data_count=0)
    coefficients = initial.clone()
    residual, deformation, response = evaluate(coefficients, True)
    matrix = matrix_at(deformation, response)
    allowance = residual_allowance(matrix, scale,
        survey_jacobian(coefficients, observations.basis, observations.points),
        observations.spec["model_response_scales_mm"], allowed)
    weak_scale = scale[allowed]*allowance
    data_scale = observations.spec["observation_scale_mm"]

    def core_solve(matrix, rhs):
        block = matrix[np.ix_(~allowed, ~allowed)]/scale[~allowed, None]
        column = np.linalg.norm(block, axis=0).clip(1e-12)
        scaled_rhs = rhs/scale[~allowed].reshape((-1,)+(1,)*(rhs.ndim-1))
        result = np.linalg.lstsq(block/column[None, :], scaled_rhs, rcond=1e-10)[0]
        return result/column.reshape((-1,)+(1,)*(rhs.ndim-1))

    def project_core(candidate):
        # Eliminate core bubble equilibrium instead of adding a very stiff
        # penalty to the observation fit. The exterior coefficients stay fixed.
        candidate = candidate.clone()
        while True:
            r, f, material = evaluate(candidate, True)
            core = r.detach().numpy().ravel()[~allowed]
            normalized = core/scale[~allowed]
            if np.max(np.abs(normalized)) <= core_tolerance:
                return candidate
            matrix = matrix_at(f, material)
            direction = np.zeros(candidate.numel())
            direction[~allowed] = core_solve(matrix, -core)
            direction = torch.tensor(direction).reshape_as(candidate)
            for backtrack in range(16):
                trial = candidate+2.**(-backtrack)*direction
                try:
                    trial_r = evaluate(trial)[0].detach().numpy().ravel()[~allowed]/scale[~allowed]
                    if np.linalg.norm(trial_r) < np.linalg.norm(normalized):
                        candidate = trial
                        break
                except (ValueError, RuntimeError):
                    continue
            else:
                raise RuntimeError(f"Core equilibrium during observation learning stagnated at day {day}")

    def objective(coef, derivative=False):
        r, f, material = evaluate(coef, derivative)
        error = observations.raw(coef)[indices] - expected
        vector = np.concatenate(((r.detach().numpy().ravel()-discrepancy)[allowed]/weak_scale,
                                 error.detach().numpy()/data_scale))
        return vector, r, f, material

    def search_step(outer_direction, core_map, attempts):
        direction = np.zeros(coefficients.numel())
        direction[allowed], direction[~allowed] = outer_direction, -core_map @ outer_direction
        direction = torch.as_tensor(direction).reshape_as(coefficients)
        best_cost, invalid, last_error = float("inf"), 0, ""
        for backtrack in range(attempts):
            candidate = coefficients+2.**(-backtrack)*direction
            try:
                candidate = project_core(candidate)
                trial = objective(candidate)[0]
            except (ValueError, RuntimeError) as exc:
                invalid += 1
                last_error = str(exc)
                continue
            new_cost = float(trial @ trial)
            best_cost = min(best_cost, new_cost)
            if new_cost < cost:
                return candidate, new_cost, None
        return None, None, dict(best_trial_cost=best_cost if np.isfinite(best_cost) else None,
                                invalid_trials=invalid, last_error=last_error)

    iteration = 0
    while True:
        vector, residual, deformation, response = objective(coefficients, True)
        cost = float(vector @ vector)
        matrix = matrix_at(deformation, response)
        h = survey_jacobian(coefficients, observations.basis, observations.points)
        core_map = core_solve(matrix, matrix[np.ix_(~allowed, allowed)])
        condensed = matrix[np.ix_(allowed, allowed)]-matrix[np.ix_(allowed, ~allowed)] @ core_map
        h = h[:, allowed]-h[:, ~allowed] @ core_map
        jacobian = np.vstack((condensed/weak_scale[:, None],
                              h[indices]/data_scale))
        column = np.linalg.norm(jacobian, axis=0).clip(1e-12)
        scaled = jacobian/column[None, :]
        gradient = float(np.max(np.abs(scaled.T @ vector)))
        if gradient < 1e-7:
            break
        scaled_direction = np.linalg.lstsq(scaled, -vector, rcond=1e-10)[0]
        outer_direction = scaled_direction/column
        candidate, new_cost, rejected = search_step(outer_direction, core_map, 18)
        if candidate is None:
            # A least-squares direction can amplify nearly dependent features.
            # Test the attainable linearized decrease against the same loss
            # and survey resolutions used for an accepted step.
            linear_step = scaled @ scaled_direction
            linear_residual = vector+linear_step
            linear_gain = float(cost-linear_residual @ linear_residual)
            survey_step = float(np.max(np.abs(h @ outer_direction)))
            print(json.dumps(dict(event="joint_step_rejected", day=float(day), iteration=iteration,
                cost=cost, gradient=gradient, linear_gain=linear_gain,
                linear_survey_step_mm=survey_step, **rejected)), flush=True)
            if np.linalg.norm(linear_step) < 1e-7 or (linear_gain <= 1e-7*(1+cost) and survey_step < .001):
                break
            # Change the direction using the singular values, while retaining
            # the original objective, core projection and material checks.
            u, singular, vt = np.linalg.svd(scaled, full_matrices=False)
            rhs = -(u.T @ vector)
            for relative in (1e-7, 1e-5, 1e-3, .1, 1., 10.):
                damped = vt.T @ ((singular/(singular**2+(relative*singular[0])**2))*rhs)
                candidate, new_cost, _ = search_step(damped/column, core_map, 12)
                if candidate is not None:
                    print(json.dumps(dict(event="joint_damped_descent", day=float(day),
                        iteration=iteration, relative_damping=relative, cost=new_cost)), flush=True)
                    break
            else:
                raise RuntimeError(f"Joint neural observation solve stagnated at day {day}: "
                                   f"cost {cost}, linear gain {linear_gain}, search {rejected}")
        change = float((observations.raw(candidate)-observations.raw(coefficients)).abs().max())
        coefficients = candidate.detach()
        iteration += 1
        if rejected is None and cost-new_cost <= 1e-7*(1+cost) and change < .001:
            break
    vector, residual, _, _ = objective(coefficients)
    learned = residual.detach().numpy().ravel().copy()
    learned[~allowed] = 0.
    measured_error = observations.raw(coefficients)[indices[:data_count]] - expected[:data_count]
    return coefficients, learned, dict(analysis_iterations=iteration,
        data_count=data_count, joint_loss=float(vector @ vector),
        weak_allowance=allowance,
        data_max_error_mm=float(measured_error.abs().max()))


class SequentialObservations:
    def __init__(self, config, basis, points):
        self.spec = config["assimilation"]
        self.load_rule = discrepancy_rule(self.spec)
        self.records = read_observations(config)
        self.events = observation_events(self.records)
        self.basis, self.points = basis, points
        self.references = {}
        self.analysis, self.predictions = [], []
        self.series = {}
        for channel in CHANNELS:
            rows = [r for r in self.records if r["channel"] == channel]
            times = np.array([r["time_day"] for r in rows])
            values = np.array([r["value_mm"] for r in rows])
            self.series[channel] = (times, values-values[0])
        rounds = {}
        for day in self.events:
            rounds.setdefault(monitoring_round(day), []).append(day)
        groups = sorted(rounds.values(), key=lambda group: group[0])
        self.round_ends = {group[-1] for group in groups}
        self.discrepancy_samples = []
        self.discrepancy_rate = np.zeros(2*basis.shape[1])
        self.forecast_rounds = {}
        cutoff = self.spec["parameter_calibration_cutoff_day"]
        for previous, following in zip(groups[:-1], groups[1:]):
            # The initial parameter fit already used every reading <= cutoff.
            # A forecast is scored only if its entire target round is later.
            if following[0] > cutoff:
                self.forecast_rounds[previous[-1]] = following

    def raw(self, coefficients):
        return survey_operator(coefficients, self.basis, self.points)

    def at(self, day):
        return [r for r in self.records if abs(r["time_day"]-day) <= 1e-9]

    def analysis_targets(self, day, prior_coefficients):
        """New measurements and a correction penalty on earlier same-round channels."""
        indices, values = [], []
        for row in self.at(day):
            channel = row["channel"]
            if channel in self.references:
                indices.append(CHANNELS.index(channel))
                values.append(self.references[channel] + row["value_mm"] - self.first_value(channel))
        count = len(indices)
        if count:
            # Anchor only the analysis correction. The prior has already
            # advanced under the current pressure to this actual reading time.
            earlier = {row["channel"] for row in self.analysis
                       if monitoring_round(row["time_day"]) == monitoring_round(day)}
            prior = self.raw(prior_coefficients).detach()
            for index, channel in enumerate(CHANNELS):
                if channel in earlier and index not in indices:
                    indices.append(index)
                    values.append(float(prior[index]))
        return indices, prior_coefficients.new_tensor(values), count

    def first_value(self, channel):
        return next(r["value_mm"] for r in self.records if r["channel"] == channel)

    def commit(self, day, coefficients):
        values = self.raw(coefficients).detach().numpy()
        for row in self.at(day):
            channel = row["channel"]
            value = values[CHANNELS.index(channel)]
            if channel not in self.references:
                self.references[channel] = float(value)
            self.analysis.append(dict(channel=channel, time_day=row["time_day"],
                observed_mm=row["value_mm"]-self.first_value(channel),
                analysis_mm=float(value-self.references[channel])))

    def learn_discrepancy_rate(self, day, discrepancy):
        """Estimate a local force trend from completed, assimilated rounds."""
        window = self.spec.get("discrepancy_history_day")
        if self.load_rule == "held" or window is None or day not in self.round_ends:
            return
        self.discrepancy_samples.append((float(day), discrepancy.copy()))
        self.discrepancy_samples = [(time, value) for time, value in self.discrepancy_samples
                                    if time >= day-window-1e-9]
        if len(self.discrepancy_samples) < 2:
            self.discrepancy_rate.fill(0.)
            return
        times = np.array([time for time, _ in self.discrepancy_samples])
        values = np.array([value for _, value in self.discrepancy_samples])
        centered = times-times.mean()
        self.discrepancy_rate = centered @ (values-values.mean(axis=0))/(centered @ centered)

    def record_forecast(self, origin, day, coefficients):
        values = self.raw(coefficients).detach().numpy()
        for row in self.at(day):
            channel = row["channel"]
            times, measured = self.series[channel]
            past = times <= origin+1e-9
            anchor = np.flatnonzero(past)[-1]
            # Pass only the available observations to the baseline fitter.
            _, slope = forecast_from_recent_trend(times[past], measured[past], origin,
                                                   self.spec["trend_history_day"])
            self.predictions.append(dict(channel=channel, origin_day=origin,
                time_day=row["time_day"], horizon_day=row["time_day"]-origin,
                anchor_day=float(times[anchor]), anchor_mm=float(measured[anchor]),
                observed_mm=row["value_mm"]-self.first_value(channel),
                predicted_mm=float(values[CHANNELS.index(channel)]-self.references[channel]),
                persistence_mm=float(measured[anchor]),
                trend_mm=float(measured[anchor]+slope*(row["time_day"]-times[anchor]))))

    def restore(self, out, checkpoint):
        day = checkpoint["time"]

        def read_rows(name):
            with (out/name).open(newline="", encoding="utf-8") as stream:
                return [{k: v if k == "channel" else float(v) for k, v in row.items()}
                        for row in csv.DictReader(stream)]

        expected = sorted((r["channel"], r["time_day"], r["value_mm"]-self.first_value(r["channel"]))
                          for r in self.records if r["time_day"] <= day+1e-9)
        if expected:
            self.analysis = read_rows("analysis_observations.csv")
        if sorted((r["channel"], r["time_day"], r["observed_mm"]) for r in self.analysis) != expected:
            raise ValueError("The saved analyses do not match the checkpoint's observation prefix")
        self.references = checkpoint["observation_references"]
        if set(self.references) != {channel for channel, _, _ in expected}:
            raise ValueError("The saved first-reading references do not match the assimilated channels")
        self.discrepancy_rate = checkpoint["discrepancy_rate"].numpy()
        self.discrepancy_samples = [(t, value.numpy()) for t, value in checkpoint["discrepancy_samples"]]

        if (out/"next_round_predictions.csv").exists():
            self.predictions = read_rows("next_round_predictions.csv")
        keys = [(r["origin_day"], r["channel"], r["time_day"]) for r in self.predictions]
        targets = [(origin, r["channel"], r["time_day"]) for origin, group in self.forecast_rounds.items()
                   if origin <= day for event in group for r in self.at(event)]
        if sorted(k for k in keys if k[0] != day) != sorted(k for k in targets if k[0] < day):
            raise ValueError("The saved predictions do not cover the preceding forecast rounds")
        # A failure during forecasting can leave the latest round incomplete.
        # Reissue it from its own origin before assimilating any target.
        if sorted(k for k in keys if k[0] == day) != sorted(k for k in targets if k[0] == day):
            self.predictions = [r for r in self.predictions if r["origin_day"] != day]

    def save(self, out):
        for name, rows in [("analysis_observations.csv", self.analysis),
                           ("next_round_predictions.csv", self.predictions)]:
            if rows:
                with (out/name).open("w", encoding="utf-8", newline="") as stream:
                    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                    writer.writeheader()
                    writer.writerows(rows)


def summarize(out, physical_reference=None, round_ranges=()):
    """One next-round prediction per reading; fitted responses remain separate."""
    out = Path(out)
    with (out/"next_round_predictions.csv").open(newline="") as stream:
        predictions = [{key: value if key == "channel" else float(value)
                        for key, value in row.items()} for row in csv.DictReader(stream)]
    with (out/"analysis_observations.csv").open(newline="") as stream:
        analysis = [{key: value if key == "channel" else float(value)
                     for key, value in row.items()} for row in csv.DictReader(stream)]
    if physical_reference is not None:
        from calibrate_history_field import predict, read_fields
        fields = read_fields(physical_reference)
        for row in predictions:
            if row["time_day"] <= fields["times"][-1]+1e-9:
                index = CHANNELS.index(row["channel"])
                row["physical_anchored_mm"] = row["anchor_mm"]+float(
                    predict(fields, [row["time_day"]], row["anchor_day"])[0, index])
        with (out/"next_round_comparison.csv").open("w", encoding="utf-8", newline="") as stream:
            keys = list(predictions[0])
            writer = csv.DictWriter(stream, fieldnames=keys)
            writer.writeheader()
            writer.writerows(predictions)
    metrics = {}
    for channel in CHANNELS:
        fitted = [r for r in analysis if r["channel"] == channel]
        rows = [r for r in predictions if r["channel"] == channel]
        target = np.array([r["observed_mm"] for r in rows])
        movement = target-np.array([r["anchor_mm"] for r in rows])
        denominator = float(np.abs(movement).sum())
        fit_y = np.array([r["observed_mm"] for r in fitted])
        fit_pred = np.array([r["analysis_mm"] for r in fitted])
        item = dict(fitted_count=len(fitted), forecast_count=len(rows),
            mean_forecast_horizon_day=float(np.mean([r["horizon_day"] for r in rows])),
            mean_absolute_next_increment_mm=float(np.abs(movement).mean()),
            mean_absolute_forecast_error_mm=float(np.mean(np.abs(
                [r["predicted_mm"]-r["observed_mm"] for r in rows]))),
            analysis_cumulative_absolute_error_percent=float(100*np.abs(fit_pred-fit_y).sum()/np.abs(fit_y).sum()),
            final_observed_mm=float(target[-1]),
            final_predicted_mm=float(rows[-1]["predicted_mm"]),
            final_signed_error_percent=float(100*(rows[-1]["predicted_mm"]-target[-1])/target[-1]),
            next_increment_error_percent={})
        for key in ("predicted_mm", "persistence_mm", "trend_mm"):
            error = np.array([r[key] for r in rows])-target
            item["next_increment_error_percent"][key] = float(100*np.abs(error).sum()/denominator)
        if round_ranges:
            item["target_rounds"] = {}
            for first, last in round_ranges:
                group = [r for r in rows if first <= monitoring_round(r["time_day"]) <= last]
                amount = sum(abs(r["observed_mm"]-r["anchor_mm"]) for r in group)
                item["target_rounds"][f"{first}-{last}"] = dict(count=len(group),
                    next_increment_error_percent={key: (100*sum(abs(r[key]-r["observed_mm"])
                        for r in group)/amount if amount else None)
                        for key in ("predicted_mm", "persistence_mm", "trend_mm")})
        paired = [r for r in rows if "physical_anchored_mm" in r]
        if paired:
            paired_denominator = sum(abs(r["observed_mm"]-r["anchor_mm"]) for r in paired)
            item["physical_comparison"] = dict(count=len(paired),
                physics_error_percent=100*sum(abs(r["physical_anchored_mm"]-r["observed_mm"]) for r in paired)/paired_denominator,
                joint_error_percent=100*sum(abs(r["predicted_mm"]-r["observed_mm"]) for r in paired)/paired_denominator)
        metrics[channel] = item
    payload = dict(channels=metrics,
        primary_metric="100 sum absolute next-round prediction errors / sum absolute observed changes from each last available reading. Same times and denominator for all methods; persistence is 100 percent. No output re-anchoring of the learned PINN.",
        fitted_response="Analysis observations were assimilated and measure fit, not prediction.",
        pressure="Conditioned on the prescribed measured-pressure history.")
    (out/"assimilation_metrics.json").write_text(json.dumps(payload, indent=2)+"\n", encoding="utf-8")
    return payload
