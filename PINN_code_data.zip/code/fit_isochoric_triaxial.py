"""Compare nested viscous laws against complete, stress-controlled histories."""
import argparse
import csv
from dataclasses import asdict
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import least_squares

from fit_creep_hold_increments import load_curves, metrics
from history_isochoric import IsoMaterial
from isochoric_triaxial import predict

ROOT = Path(__file__).resolve().parents[1]


def unpack(theta, case):
    eta = float(np.exp(theta[0]))
    qstar = None if case["model"] == "M0" else float(np.exp(theta[1]))
    pressure_a = float(theta[2]) if case["model"] == "M2" else 0.
    return IsoMaterial.from_elastic(case["young"], case["nu"], case["fraction"],
                                   eta, qstar, pressure_a)


def observation(case):
    return {k: case[k] for k in ("convention", "gauge", "area")}


def run_case(case, config, curves):
    out = ROOT/config["output"]/case["name"]
    out.mkdir(parents=True, exist_ok=True)
    calibration = [c for c in curves if c["cp"] in (15, 25) and c["stage"] in (2, 3)]
    fit_histories = [c for c in curves if c["cp"] in (15, 25) and c["stage"] <= 3]
    count = {"M0": 1, "M1": 2, "M2": 3}[case["model"]]
    physical_bounds = case.get("bounds", config["bounds"])
    bounds = np.array(physical_bounds, dtype=float)[:, :count]
    bounds[:, :min(count, 2)] = np.log(bounds[:, :min(count, 2)])
    start = time.perf_counter()

    def residual(theta):
        estimates = predict(fit_histories, unpack(theta, case), **observation(case))
        return np.concatenate([(estimates[(c["cp"], c["stage"])]["increment"]-c["increment"])[1:]
                               for c in calibration])/.001

    fits, starts = [], []
    for guess in case["starts"]:
        theta = np.array(guess[:count], dtype=float)
        theta[:min(count, 2)] = np.log(theta[:min(count, 2)])
        fit = least_squares(residual, theta, bounds=bounds, diff_step=1e-4,
                            ftol=2e-8, xtol=2e-8, gtol=2e-7)
        if not fit.success:
            raise RuntimeError(f"{case['name']}: {fit.message}")
        fits.append(fit)
        item = dict(initial=guess, material=asdict(unpack(fit.x, case)),
                    scaled_sse=float(fit.fun @ fit.fun), nfev=fit.nfev)
        starts.append(item)
        print(json.dumps(dict(case=case["name"], **item)), flush=True)
    fit = min(fits, key=lambda f: float(f.fun @ f.fun))
    material = unpack(fit.x, case)
    estimates = predict(curves, material, **observation(case))
    result = dict(case=case, material=asdict(material), starts=starts, bounds=physical_bounds,
                  bound_activity=fit.active_mask.tolist(), elapsed_s=time.perf_counter()-start,
                  local_jacobian_singular_values=np.linalg.svd(fit.jac, compute_uv=False).tolist(),
                  curves=[])
    result["split"] = config["split"]
    result["assumptions"] = config["assumptions"]
    rows = []
    for curve in curves:
        est = estimates[(curve["cp"], curve["stage"])]
        result["curves"].append(metrics(curve, est["increment"]))
        for i, t in enumerate(curve["t"]):
            rows.append(dict(cp_MPa=curve["cp"], q_MPa=curve["q"], stage=curve["stage"],
                             time_h=t, measured_strain=curve["strain"][i],
                             measured_increment=curve["increment"][i],
                             increment_error=est["increment"][i]-curve["increment"][i],
                             strain_error=est["engineering_strain"][i]-curve["strain"][i],
                             **{key: value[i] for key, value in est.items()}))
    for name, selected in (("calibration", calibration), ("held_confinement",
            [c for c in curves if c["cp"] == 20 and c["stage"] in (2, 3)])):
        errors = np.concatenate([(estimates[(c["cp"], c["stage"])]["increment"]-c["increment"])[1:]
                                 for c in selected])
        result[name+"_rmse"] = float(np.sqrt(np.mean(errors**2)))
    (out/"fit.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n",
                                encoding="utf-8", newline="\n")
    with (out/"predictions.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, rows[0].keys(), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({k: result[k] for k in ("case", "material", "calibration_rmse",
                                           "held_confinement_rmse", "elapsed_s")}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/history_creep/isochoric_laboratory.json")
    parser.add_argument("--case", help="Run one named conditional fit")
    args = parser.parse_args()
    config = json.loads((ROOT/args.config).read_text(encoding="utf-8"))
    cases = config["cases"]
    if args.case:
        cases = [c for c in cases if c["name"] == args.case]
        if not cases:
            raise ValueError(f"Unknown case {args.case}")
    curves = load_curves()
    for case in cases:
        run_case({**config["base"], **case}, config, curves)


if __name__ == "__main__":
    main()
