"""Neural weak equilibrium with a retained, progressively excavated tunnel core.

The exterior and core share their neural displacement trace. Interior features
vanish on the final wall. Both regions use their own finite-strain material
histories. Excavation scales core stress and tangent; measured contact traction
is applied once at the final wall. No FE displacement or state is used.
"""
from dataclasses import asdict
import json
from pathlib import Path
import time

import numpy as np
import torch

from history_field import (FieldMesh, FieldNetwork, PressureHistory, head_basis, pointwise_basis,
    material_from_config, prestress, schedule, reporting_points, update)
from field_geometry import resolve_field_configuration
from mixed_geometry import cofactor_normal


def core_quadrature(c, mesh):
    """Core integration split at the actual wall arcs and excavation interfaces."""
    n = c.get("core_quadrature", 20)
    g, w = np.polynomial.legendre.leggauss(n)
    interface = c["progressive_release"]["interface_y_m"]
    points, weights, upper = [], [], []
    if mesh.section is not None:
        invert = c.get("invert_release", {}).get("interface_y_m")
        levels = [interface] if invert is None else [interface, invert]
        for wall, measure in mesh.section.core_rays(mesh.base.counts, levels,
                                                    c.get("core_angular_quadrature", 8)):
            for point, angular_weight in zip(wall, measure):
                cuts = [0., 1.]
                if abs(point[1]) > 1e-12:
                    cuts.extend(level/point[1] for level in levels if 0 < level/point[1] < 1)
                cuts.sort()
                for low, high in zip(cuts[:-1], cuts[1:]):
                    rho = (low+high)/2+(high-low)/2*g
                    points.append(rho[:, None]*point)
                    weights.append(angular_weight*rho*w*(high-low)/2)
                    upper.extend([bool(point[1]*(low+high)/2 >= interface)]*n)
        physical = torch.tensor(np.concatenate(points))
        reference = physical @ torch.linalg.inv(mesh.f0[:2, :2]).T
        return reference, torch.tensor(np.concatenate(weights))/torch.det(mesh.f0[:2, :2]), torch.tensor(upper)
    b, a = c["semiaxis_y"], c["radius"]**2/c["semiaxis_y"]
    intervals = [(-b, interface, False), (interface, b, True)]
    if "invert_release" in c:
        invert = c["invert_release"]["interface_y_m"]
        if not -b < invert < interface:
            raise ValueError("The invert interface must lie below the bench and inside the core")
        intervals = [(-b, invert, False), (invert, interface, False), (interface, b, True)]
    for low, high, flag in intervals:
        y = low+(g+1)*(high-low)/2
        xhalf = a*np.sqrt(1-(y/b)**2)
        xx, yy = xhalf[:, None]*g[None, :], np.broadcast_to(y[:, None], (n,n))
        points.append(np.stack((xx,yy), -1).reshape(-1,2))
        weights.append(((high-low)/2*w[:, None]*xhalf[:, None]*w[None, :]).flatten())
        upper.extend([flag]*(n*n))
    physical = torch.tensor(np.concatenate(points))
    weights = torch.tensor(np.concatenate(weights))/torch.det(mesh.f0[:2,:2])
    reference = physical @ torch.linalg.inv(mesh.f0[:2,:2]).T
    return reference, weights, torch.tensor(upper)


def core_basis(net, points, order, interface=None):
    levels = [] if interface is None else interface if isinstance(interface, list) else [interface]
    def values(x):
        base = x @ net.to_base.T
        radius = base.norm(dim=-1)
        wallr = net.section.ray_radius(base) if net.section is not None else net.length
        rho = radius/wallr
        direction = base/radius.clamp_min(torch.finfo(base.dtype).eps)[:, None]
        direction = torch.where((radius > 0)[:, None], direction, base.new_tensor([1., 0.]))
        wall = net.length*direction
        trace = net.scale*torch.cat((net.features(wall), torch.ones_like(rho[:,None])), -1)
        coupled = rho[:,None].square()*trace
        # Cartesian polynomials are regular at the origin and vanish on the wall.
        xx, yy = base[:,0]/net.length, base[:,1]/net.length
        inner = torch.stack([(1-rho.square())*xx.pow(i)*yy.pow(j)
            for degree in range(order+1) for i in range(degree+1) for j in [degree-i]], -1)*net.scale
        # Continuous displacement with an independent gradient across each interface.
        inner = torch.cat([inner, *[inner*(yy-level).clamp_min(0)[:,None]
                                   for level in levels]], -1)
        return torch.cat((coupled, inner), -1)
    basis, gradient = pointwise_basis(values, points)
    count = (order+1)*(order+2)//2*(1+len(levels))
    return basis, gradient, count


def release_fractions(c, day):
    stage = c["progressive_release"]
    upper_start = stage["upper_start_day"]
    if "stage_delay_day" in stage:
        if stage["stage_delay_day"] < 0:
            raise ValueError("The lower-stage onset must not precede the upper stage")
        lower_start = upper_start+stage["stage_delay_day"]
    else:
        lower_start = stage["lower_start_day"]
    values = []
    for name, start in [("upper", upper_start), ("lower", lower_start)]:
        s = max((day-start)/stage[name+"_duration_day"], 0.)
        if stage.get("profile") == "exponential_tail":
            # A smooth onset and asymptotic removal of face/core restraint.
            # The duration parameter is a time scale, not a completion date.
            values.append(float(1-(1+s)*np.exp(-s)))
        elif stage.get("profile") == "algebraic_tail":
            # An inverse-square remaining-restraint hypothesis. This is a
            # core-release history, not a measured longitudinal displacement.
            values.append(float(1-(1+s)**-2))
        else:
            s = min(s,1.)
            values.append(float(s*s*(3-2*s)))
    return values


def core_retention(c, day, upper, physical_y):
    qu, ql = release_fractions(c, day)
    retained = 1-torch.where(upper, qu, ql)
    if "invert_release" in c:
        stage = c["invert_release"]
        s = float(np.clip((day-stage["start_day"])/stage["duration_day"], 0., 1.))
        qi = s*s*(3-2*s)
        retained = torch.where(physical_y < stage["interface_y_m"], 1-qi, retained)
    return retained


def tangent(response, f):
    return torch.stack([torch.autograd.grad(response.piola[:,i,j].sum(), f,
        retain_graph=True)[0][:,:2,:2] for i in range(2) for j in range(2)], 1).reshape(-1,2,2,2,2).detach()


def run_core(c, specification, dt, out, seed=0, resume=False):
    started = time.perf_counter()
    out = Path(out)
    c = resolve_field_configuration(c)
    start_index = 0
    previous_elapsed = 0.
    if resume:
        prefix = json.loads((out/"summary.json").read_text(encoding="utf-8"))
        if prefix["complete"] or not prefix["steps"]:
            raise ValueError("Resume requires an incomplete history with an accepted step")
        start_index = len(prefix["steps"])
        previous_elapsed = prefix["elapsed_s"]
        checkpoint = torch.load(out/"states"/f"step_{start_index:03d}.pt", weights_only=True)
    material = material_from_config(c)
    f0, cv0, pinit = prestress(c, material)
    mesh = FieldMesh(c, f0, specification)
    net = FieldNetwork(c, seed, f0, pinit, mesh.transform)
    if resume:
        net.load_state_dict(checkpoint["network"])
    core_x, core_w, upper = core_quadrature(c, mesh)
    vertical_scale = net.length if mesh.section is not None else c["semiaxis_y"]
    interface = (c["progressive_release"]["interface_y_m"]/vertical_scale
                 if c.get("core_interface_enrichment") else None)
    if interface is not None and "invert_release" in c:
        interface = [interface, c["invert_release"]["interface_y_m"]/vertical_scale]
    _, gc, inner_count = core_basis(net, core_x, c.get("core_feature_order", 7), interface)
    _, go = head_basis(net, mesh.volume.x)
    bw, gw = head_basis(net, mesh.boundary.x)
    outer_count = go.shape[1]
    def pad(a):
        return torch.cat((a, torch.zeros(len(a), inner_count, *a.shape[2:])), 1)
    go, bw, gw = pad(go), pad(bw), pad(gw)
    gradient = torch.cat((go,gc))
    weights = torch.cat((mesh.volume.weight, core_w))
    outside = len(go)
    coefficients = torch.zeros(2, gradient.shape[1])
    initial_wall = mesh.boundary.normal[:,:2] @ pinit[:2,:2].T
    initial_load = torch.einsum("qi,qa,q->ia",initial_wall,bw,mesh.boundary.weight)
    cv = cv0.expand(len(gradient),3,3).clone()
    z0 = .5*f0[:,1].square().sum().log()
    z = z0.expand(len(gradient)).clone() if c.get("bedding_relaxes") else None
    pressure = PressureHistory(c)
    base_points, points = reporting_points(c, mesh)
    reference = base_points @ mesh.transform.T
    bp, gp = head_basis(net, reference)
    bp, gp = pad(bp), pad(gp)
    observations = None
    if "assimilation" in c:
        from field_assimilation import SequentialObservations, fit_coefficients
        observations = SequentialObservations(c, bp, points)
        c["extra_time_nodes"] = sorted(set(c.get("extra_time_nodes", [])+observations.events))
    discrepancy = np.zeros(coefficients.numel())
    discrepancy_mask = np.tile(np.arange(gradient.shape[1]) < outer_count, 2)
    cvp = cv0.expand(len(points),3,3).clone()
    zp = z0.expand(len(points)).clone() if z is not None else None
    times = schedule(c,dt)
    core_y = (core_x @ f0[:2,:2].T)[:, 1]
    values = [np.zeros((len(points),2))]
    fs = [f0.expand(len(points),3,3).numpy()]
    states = [cvp.numpy().copy()]
    stresses = [(pinit @ f0.T/torch.det(f0)).expand(len(points),3,3).numpy()]
    zs = [zp.numpy().copy()] if zp is not None else []
    rows = []
    if resume:
        if (prefix["configuration"] != c or prefix["mesh"] != specification or
                prefix["dt"] != dt or prefix["seed"] != seed):
            raise ValueError("The saved history requires its original configuration, mesh, time step and seed")
        rows = prefix["steps"]
        if checkpoint["time"] != times[start_index] or not np.array_equal(
                [r["time"] for r in rows], times[1:start_index+1]):
            raise ValueError("The checkpoint and accepted time grid do not agree")
        coefficients = torch.cat((net.head.weight.detach(), net.head.bias.detach()[:, None],
                                  checkpoint["core_coefficients"]), dim=1)
        cv, z = checkpoint["cv"], checkpoint["bedding_strain"]
        cvp, zp = checkpoint["cv_probe"], checkpoint["bedding_strain_probe"]
        discrepancy = checkpoint["discrepancy"].numpy()
        with np.load(out/"fields.npz") as fields:
            if not np.array_equal(fields["times"], times[:start_index+1]):
                raise ValueError("The saved probe history and checkpoint have different time grids")
            values, fs, states, stresses = (list(fields[key]) for key in ("u", "f", "cv", "sigma"))
            zs = list(fields["bedding_strain"]) if zp is not None else []
        if (not np.allclose(values[-1], (bp @ coefficients.T).numpy(), rtol=1e-12, atol=1e-12) or
                not np.array_equal(states[-1], cvp.numpy()) or
                (zp is not None and not np.array_equal(zs[-1], zp.numpy()))):
            raise ValueError("The saved network, deformation and material state do not share the same endpoint")
        if observations is not None:
            observations.restore(out, checkpoint)
    else:
        out.mkdir(parents=True, exist_ok=False)
        (out/"states").mkdir()
    if not resume and mesh.section is not None:
        physical_wall = mesh.base.boundary
        np.savez_compressed(out/"geometry.npz",
            nodes=(mesh.nodes @ f0[:2, :2].T).numpy(),
            wall_points=physical_wall.x.numpy(), wall_normals=physical_wall.normal.numpy(),
            wall_weights=physical_wall.weight.numpy(),
            core_points=(core_x @ f0[:2, :2].T).numpy(),
            core_weights=(core_w*torch.det(f0[:2, :2])).numpy(), core_upper=upper.numpy(),
            survey_points=points[:7].numpy(), evaluation_points=base_points[:7].numpy(),
            pressure_points=pressure.points.numpy(), pressure_arclength=pressure.locations,
            interfaces_y=np.array([c["progressive_release"]["interface_y_m"],
                                   c["invert_release"]["interface_y_m"]])
            if "invert_release" in c else np.array([c["progressive_release"]["interface_y_m"]]))
    # Variational tests are the same continuous neural features as displacement.
    scale = (weights[:,None,None]*gradient.square()).sum((0,2)).sqrt().clamp_min(1e-9)*c["p0"]
    def deformation(coef, g):
        f = f0.expand(len(g),3,3).clone()
        f[:,:2,:2] += torch.einsum("ia,qaj->qij",coef,g)
        return f
    def save(complete,error=None):
        summary = dict(method="condensed", representation=("continuous neural Galerkin core and exterior; observation-and-physics trained output layer"
            if observations is not None else "continuous neural Galerkin core and exterior; trained output layer"),
            configuration=c,material=asdict(material),mesh=specification,dt=dt,seed=seed,
            complete=complete,elapsed_s=previous_elapsed+time.perf_counter()-started,steps=rows,
            dofs=coefficients.numel(),f0=f0.tolist(),initial_piola=pinit.tolist())
        if resume and "reused_analysis_through_day" in prefix:
            summary["reused_analysis_through_day"] = prefix["reused_analysis_through_day"]
        if error:summary["error"]=error
        (out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
        arrays=dict(times=times[:len(values)],points=points.numpy(),reference_points=reference.numpy(),
                    evaluation_points=(base_points @ mesh.physical_map.T).numpy(),
                    u=np.array(values),f=np.array(fs),cv=np.array(states),sigma=np.array(stresses))
        if zs:arrays["bedding_strain"]=np.array(zs)
        np.savez_compressed(out/"fields.npz",**arrays)
        if observations is not None:
            observations.save(out)

    def advance(coef, old_cv, old_z, previous, day, target, assimilate=False):
        step = day-previous
        active = torch.cat((torch.ones(outside), core_retention(c, day, upper, core_y)))
        # The asymptotic tail can leave a nominally active bubble with no
        # resolvable stiffness. Exclude the excavated points from both weak
        # forms and the material return; their last state stays at retirement.
        points_in_solid = (active > c["core_retention_resolution"]
                           if "core_retention_resolution" in c else slice(None))
        grad, weight, active = gradient[points_in_solid], weights[points_in_solid], active[points_in_solid]
        cv_solid = old_cv[points_in_solid]
        z_solid = old_z[points_in_solid] if old_z is not None else None
        initial_stress = torch.zeros_like(cv_solid)
        initial_stress[:outside] = pinit
        load = pressure.boundary(day, mesh)

        def evaluate(candidate, derivative=False):
            if observations is not None:
                # Observation learning must also keep the probe history valid;
                # integration-point checks alone do not cover the wall traces.
                if bool((torch.linalg.det(deformation(candidate, gp)) <= 0).any()):
                    raise ValueError("The learned field must preserve orientation at reporting points")
            f = deformation(candidate, grad)
            f = torch.where((active > 0)[:, None, None], f, f0).requires_grad_(derivative)
            response = update(f, cv_solid, step, material, z_solid)
            p = active[:, None, None]*response.piola - initial_stress
            internal = torch.einsum("qij,qaj,q->ia", p[:, :2, :2], grad, weight)
            fw = deformation(candidate, gw)
            traction = load[:, None]*cofactor_normal(fw, mesh.boundary.normal)[:, :2]
            residual = internal+initial_load+torch.einsum("qi,qa,q->ia", traction, bw, mesh.boundary.weight)
            return residual, f, response

        def matrix_at(f, response):
            a = tangent(response, f)*active[:, None, None, None, None]
            matrix = torch.einsum("qaj,qijkl,qbl,q->iakb", grad, a, grad, weight)
            follower = torch.zeros(len(gw), 2, 2, 2)
            n = mesh.boundary.normal
            follower[:, 0, 1, 1], follower[:, 0, 1, 0] = n[:, 0], -n[:, 1]
            follower[:, 1, 0, 1], follower[:, 1, 0, 0] = -n[:, 0], n[:, 1]
            matrix += torch.einsum("qa,qikl,qbl,q->iakb", bw, follower, gw, load*mesh.boundary.weight)
            return matrix.reshape(coef.numel(), coef.numel()).numpy()

        iteration = 0
        while True:
            residual, f, response = evaluate(coef, True)
            r = residual.detach().numpy().ravel()-target
            normalized = r/np.tile(scale.numpy(), 2)
            norm, maximum = float(np.linalg.norm(normalized)), float(np.max(np.abs(normalized)))
            print(json.dumps(dict(event="core_newton", day=float(day), iteration=iteration,
                branch="analysis" if assimilate else "physical", weak_max=maximum,
                weak_rms=norm/np.sqrt(len(r)))), flush=True)
            if maximum <= c["equilibrium_tolerance"]:
                break
            matrix = matrix_at(f, response)
            scaling = np.sqrt(np.abs(np.diag(matrix))).clip(1e-6)
            direction = np.linalg.lstsq(matrix/scaling[:, None]/scaling[None, :],
                                       -r/scaling, rcond=1e-12)[0]/scaling
            direction = torch.tensor(direction).reshape_as(coef)
            for backtrack in range(16):
                candidate = coef+2.**(-backtrack)*direction
                try:
                    trial = (evaluate(candidate)[0].detach().numpy().ravel()-target)/np.tile(scale.numpy(), 2)
                    if float(np.linalg.norm(trial)) < norm:
                        coef = candidate
                        break
                except (ValueError, RuntimeError):
                    continue
            else:
                raise RuntimeError(f"Core/exterior neural equilibrium stagnated at day {day}, residual {maximum}")
            iteration += 1
        info = dict(iterations=iteration, weak_max=maximum, weak_rms=norm/np.sqrt(len(r)))
        if assimilate:
            coef, target, learned = fit_coefficients(coef, evaluate, matrix_at,
                np.tile(scale.numpy(), 2), target, observations, day,
                discrepancy_mask, c["equilibrium_tolerance"])
            info.update(learned)
            residual, _, response = evaluate(coef)
            info["physical_weak_rms"] = float(np.linalg.norm(
                residual.detach().numpy().ravel()/np.tile(scale.numpy(), 2))/np.sqrt(coef.numel()))
        # Every trial above uses the same old state. Only this final return is
        # accepted, including in the data-informed branch.
        next_cv = old_cv.clone()
        next_cv[points_in_solid] = response.cv.detach()
        next_z = None
        if old_z is not None:
            next_z = old_z.clone()
            next_z[points_in_solid] = response.bedding_strain.detach()
        return coef.detach(), next_cv, next_z, target, info

    def forecast_round(origin, coef, old_cv, old_z, target):
        following = observations.forecast_rounds.get(origin)
        if following is None:
            return
        rate = observations.discrepancy_rate.copy()
        previous = origin
        predicted_states = []
        for day in times[(times > origin) & (times <= following[-1])]:
            predicted_load = target+(day-origin)*rate
            coef, old_cv, old_z, _, _ = advance(coef, old_cv, old_z, previous, day, predicted_load)
            if any(abs(day-event) <= 1e-9 for event in following):
                predicted_states.append((day, coef))
            previous = day
        for day, coef in predicted_states:
            observations.record_forecast(origin, day, coef)
        observations.save(out)
        print(json.dumps(dict(event="next_round_forecast_saved", origin_day=float(origin),
                              end_day=float(following[-1]))), flush=True)

    if not resume:
        save(False)
    try:
        if resume:
            day = float(times[start_index])
            print(json.dumps(dict(event="resumed", step=start_index, day=day)), flush=True)
            if observations is not None and not any(r["origin_day"] == day for r in observations.predictions):
                forecast_round(day, coefficients, cv, z, discrepancy)
        for index in range(start_index+1, len(times)):
            previous, day = times[index-1:index+1]
            step=day-previous
            if observations is not None and observations.load_rule == "propagated":
                discrepancy = discrepancy+step*observations.discrepancy_rate
            coefficients, cv, z, discrepancy, info = advance(coefficients, cv, z,
                previous, day, discrepancy, assimilate=observations is not None)
            uq=(bp @ coefficients.T).detach()
            fq=deformation(coefficients,gp).detach()
            report=update(fq,cvp,step,material,zp)
            cvp=report.cv.detach()
            if zp is not None:
                zp=report.bedding_strain.detach();zs.append(zp.numpy().copy())
            values.append(uq.numpy());fs.append(fq.numpy());states.append(cvp.numpy().copy());stresses.append(report.cauchy.detach().numpy())
            rows.append(dict(time=float(day), **info))
            if observations is not None:
                observations.commit(day, coefficients)
                observations.learn_discrepancy_rate(day, discrepancy)
            with torch.no_grad():
                net.head.weight.copy_(coefficients[:,:outer_count-1]);net.head.bias.copy_(coefficients[:,outer_count-1])
            if c.get("save_checkpoints",True):
                checkpoint = dict(time=float(day),network=net.state_dict(),core_coefficients=coefficients[:,outer_count:],
                    cv=cv,bedding_strain=z,cv_probe=cvp,bedding_strain_probe=zp,
                    discrepancy=torch.from_numpy(discrepancy),
                    observation_references=observations.references if observations is not None else {})
                if observations is not None:
                    checkpoint["discrepancy_rate"] = torch.from_numpy(observations.discrepancy_rate)
                    checkpoint["discrepancy_samples"] = [
                        (time, torch.from_numpy(value)) for time, value in observations.discrepancy_samples]
                torch.save(checkpoint, out/"states"/f"step_{index:03d}.pt")
            save(False)
            print(json.dumps(rows[-1]),flush=True)
            if observations is not None:
                forecast_round(day, coefficients, cv, z, discrepancy)
        save(True)
    except Exception as exc:
        save(False,str(exc));raise
    print(json.dumps(dict(event="complete",elapsed_s=previous_elapsed+time.perf_counter()-started)),flush=True)
