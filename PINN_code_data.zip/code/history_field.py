"""Measured-traction conditional field histories with finite survey operators.

The source horseshoe or the retained reference ellipse is selected explicitly.
Parameters, unloading history and missing-boundary treatments are configured;
the displacement observations are read only by the separate comparison script.
"""
import argparse
import csv
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import root
from scipy.linalg import solve as dense_solve
from scipy.sparse.linalg import spsolve
import torch

from history_horseshoe import Network, fe_fields, relaxed_state, solve_fe, sparse_tangent
from history_horseshoe_linear import linear_tensor, strain
from history_isochoric import IsoMaterial, update as isotropic_update
from history_material import Response, elastic
from field_geometry import FieldSection, resolve_field_configuration
from horseshoe_geometry import HorseshoeWall
from mixed_geometry import CurvedMesh, Quadrature, cofactor_normal
from mixed_q2 import CurvedQ2Mesh
from mixed_reference_sampling import locate

ROOT = Path(__file__).resolve().parents[1]
torch.set_default_dtype(torch.float64)


@dataclass(frozen=True)
class FieldMaterial(IsoMaterial):
    bedding_stiffness: float = 0.
    bedding_relaxation_day: float | None = None


@dataclass
class FieldResponse(Response):
    bedding_strain: torch.Tensor | None = None


def bedding_response(f, stiffness):
    """Elastic reinforcement along the representative near-vertical bedding.

    W_b = k/8 (a.C.a - 1)^2, a=e_y. This objective directional addition
    describes an in-plane contrast, not measured unique joint constants.
    Its small-strain contribution is k/2 * epsilon_yy^2.
    """
    direction = f[..., :, 1]
    extension = direction.square().sum(-1)-1.
    piola = torch.zeros_like(f)
    piola[..., :, 1] = .5*stiffness*extension[..., None]*direction
    return piola, stiffness/8*extension.square()


def bedding_maxwell_response(f, old, dt, stiffness, relaxation):
    """Implicit directional Maxwell mode with logarithmic stretch and its state.

    W_b=k/2*(log(lambda_b)-z)^2, eta_b=k*T_b, z_dot=(log(lambda_b)-z)/T_b.
    The scalar state belongs to this material point and is committed only after
    equilibrium. Its relaxation time is prescribed explicitly by the model.
    """
    direction = f[..., :, 1]
    i4 = direction.square().sum(-1)
    strain = .5*i4.log()
    state = (old+(dt/relaxation)*strain)/(1+dt/relaxation)
    stress = stiffness*(strain-state)
    piola = torch.zeros_like(f)
    piola[..., :, 1] = (stress/i4)[..., None]*direction
    energy = .5*stiffness*(strain-state).square()
    return piola, energy, state, stress.square()/(stiffness*relaxation)


def update(f, cv_old, dt, material, bedding_old=None):
    response = isotropic_update(f, cv_old, dt, material)
    if getattr(material, "bedding_stiffness", 0.) == 0.:
        return response
    state, dissipation = None, 0.
    if material.bedding_relaxation_day is None:
        piola, energy = bedding_response(f, material.bedding_stiffness)
    else:
        if bedding_old is None or bedding_old.requires_grad:
            raise ValueError("A fixed old bedding state is required for the relaxing mode")
        piola, energy, state, dissipation = bedding_maxwell_response(
            f, bedding_old, dt, material.bedding_stiffness, material.bedding_relaxation_day)
    tau = piola @ f.transpose(-1, -2)
    return FieldResponse(response.piola+piola,
        response.cauchy+tau/torch.linalg.det(f)[..., None, None],
        response.kirchhoff+tau, response.cv, response.energy+energy,
        response.dissipation+dissipation, state)


def scenario_config(config, scenario):
    c = dict(config)
    overrides = c.pop("scenarios")
    c.update(overrides[scenario])
    c["scenario"] = scenario
    return c


def material_from_config(c):
    mu1 = (1-c["fraction"])*c["young"]/(2*(1+c["nu"]))
    base = IsoMaterial.from_elastic(c["young"], c["nu"], c["fraction"],
                                   mu1*c["relaxation_day"])
    stiffness = c["young"]*c.get("bedding_ratio", 0.)
    if "bedding_fraction" in c:
        if not 0 < c["bedding_fraction"] <= 1 or c["young"] >= c["bedding_young_cap"]:
            raise ValueError("The directional modulus must remain within its declared material family")
        stiffness = c["bedding_fraction"]*(c["bedding_young_cap"]-c["young"])
    if stiffness == 0.:
        return base
    if stiffness < 0:
        raise ValueError("The bedding stiffness addition must be nonnegative")
    return FieldMaterial(**asdict(base), bedding_stiffness=stiffness,
                         bedding_relaxation_day=c.get("bedding_relaxation_day", c["relaxation_day"])
                         if c.get("bedding_relaxes") else None)


def prestress(c, material):
    target = np.array([-c["kh"]*c["p0"], -c["p0"]])
    def residual(logs):
        f = torch.diag(torch.tensor([*np.exp(logs), 1.]))
        tau = elastic(f @ f.T, material.mu0, material.bulk)[0]
        if getattr(material, "bedding_stiffness", 0.) and material.bedding_relaxation_day is None:
            tau = tau+bedding_response(f, material.bedding_stiffness)[0] @ f.T
        return tau.diag()[:2].numpy()/float(torch.det(f))-target
    answer = root(residual, np.array([-.01, -.01]), tol=1e-11)
    if np.max(np.abs(residual(answer.x))) > 1e-8:
        raise RuntimeError(f"Initial anisotropic stress did not balance: {answer.message}")
    f0 = torch.diag(torch.tensor([*np.exp(answer.x), 1.]))
    cv0 = relaxed_state(f0)
    bedding0 = .5*f0[:, 1].square().sum().log()
    pinit = update(f0[None], cv0[None], 0., material, bedding0[None]).piola[0].detach()
    return f0, cv0, pinit


def transform_quad(q, transform):
    inv = torch.linalg.inv(transform)
    det = torch.det(transform)
    normal = None
    weight = q.weight*det
    if q.normal is not None:
        n = q.normal[:, :2] @ inv
        norm = n.norm(dim=-1)
        normal = torch.cat((n/norm[:, None], n[:, :1]*0), -1)
        weight = weight*norm
    return Quadrature(q.x @ transform.T, weight, q.shape, q.grad @ inv, q.conn, normal)


class FieldMesh:
    """Documented physical contour pulled back through the initial deformation."""
    def __init__(self, c, f0, specification):
        self.f0 = f0
        self.section = FieldSection(c["field_geometry"]) if "field_geometry" in c else None
        if self.section is not None:
            self.physical_map = torch.eye(2)
            wall = self.section.outer
        else:
            r, b = c["radius"], c["semiaxis_y"]
            a = r*r/b
            self.physical_map = torch.diag(torch.tensor([a/r, b/r]))
            wall = HorseshoeWall(torch.zeros(4, 2), torch.full((4,), r),
                torch.arange(4)*torch.pi/2, torch.full((4,), torch.pi/2))
        self.transform = torch.linalg.solve(f0[:2, :2], self.physical_map)
        spec = dict(specification)
        cls = {1: CurvedMesh, 2: CurvedQ2Mesh}[spec.pop("degree")]
        self.base = cls(wall, c["outer_radius"], **spec)
        self.conn, self.free = self.base.conn, self.base.free
        self.na, self.nr, self.nnode = self.base.na, self.base.nr, self.base.nnode
        self.nodes = self.base.nodes @ self.transform.T
        self.volume = transform_quad(self.base.volume, self.transform)
        self.boundary = transform_quad(self.base.boundary, self.transform)
        self.assemble = self.base.assemble
        v = self.volume
        support, norm = torch.zeros(self.nnode), torch.zeros(self.nnode)
        support.index_add_(0, v.conn.flatten(), v.weight[:, None].expand_as(v.shape).flatten())
        norm.index_add_(0, v.conn.flatten(), (v.weight[:, None]*v.grad.square().sum(-1)).flatten())
        self.test_scale = (support*norm).sqrt().clamp_min(1e-14)
        self.release = 1.

    def probe(self, base_points):
        return transform_quad(locate(self.base, base_points), self.transform)

    def weak(self, piola, fwall, pressure, p0, f0, initial_piola, *, subtract_initial=True):
        v, b = self.volume, self.boundary
        p = piola[:, :2, :2]-(initial_piola[:2, :2] if subtract_initial else 0.)
        internal = self.assemble(torch.einsum("qij,qaj,q->qai", p, v.grad, v.weight), v.conn)
        load = pressure[:, None]*cofactor_normal(fwall, b.normal)[:, :2]
        release = torch.as_tensor(self.release)
        if release.ndim:
            release = release[:, None]
        load = load+release*(b.normal[:, :2] @ initial_piola[:2, :2].T)
        boundary = self.assemble(b.shape[:, :, None]*load[:, None, :]*b.weight[:, None, None], b.conn)
        return (internal+boundary)[self.free]/(p0*self.test_scale[self.free, None])


class FieldNetwork(Network):
    def __init__(self, c, seed, f0, pinit, transform):
        super().__init__(dict(c, length_scale=c["radius"]), "condensed", seed, f0, pinit)
        self.length, self.radius = c["radius"], c["outer_radius"]
        self.section = FieldSection(c["field_geometry"]) if "field_geometry" in c else None
        self.register_buffer("to_base", torch.linalg.inv(transform))
        self.angular_order = c["field_angular_order"]
        self.radial_basis = c.get("field_radial_basis", "powers")
        self.radial_harmonics = [(n, p) for n in range(1, c.get("field_multipole_order", 0)+1)
                                for p in sorted(set([max(n-2, 0), n, n+2])) if p > 0]
        if "field_radial_order" in c:
            self.radial_harmonics = [(n, p) for n in range(c["field_multipole_order"]+1)
                                    for p in range(c["field_radial_order"]+1)
                                    if (p > 0 or n > self.angular_order)
                                    and not (self.radial_basis == "powers" and p == 2 and n in (1, 3))]
        self.head = torch.nn.Linear(c["network_width"]+2*self.angular_order+9+2*len(self.radial_harmonics), 2)
        torch.nn.init.zeros_(self.head.weight)
        torch.nn.init.zeros_(self.head.bias)

    def features(self, x):
        r = x.norm(dim=-1)
        angle = torch.atan2(x[:, 1], x[:, 0])
        c, s = x[:, 0]/r, x[:, 1]/r
        z = torch.stack((torch.log(r/self.length)/np.log(self.radius/self.length), c, s), -1)
        direct = [torch.ones_like(r)]
        for order in range(1, self.angular_order+1):
            direct.extend([(order*angle).cos(), (order*angle).sin()])
        decay = (self.length/r).square()
        direct.extend([decay*c, decay*s, decay*(3*angle).cos(), decay*(3*angle).sin()])
        growth = r/self.radius
        direct.extend([growth*c, growth*s, growth*(3*angle).cos(), growth*(3*angle).sin()])
        features = [self.body(z), torch.stack(direct, -1)]
        if self.radial_harmonics:
            orders, powers = x.new_tensor(self.radial_harmonics).T
            if self.radial_basis == "log_chebyshev":
                coordinate = 2*torch.log(r/self.length)/np.log(self.radius/self.length)-1
                polynomials = [torch.ones_like(coordinate), coordinate]
                for degree in range(2, int(powers.max())+1):
                    polynomials.append(2*coordinate*polynomials[-1]-polynomials[-2])
                radial = torch.stack(polynomials, -1)[:, powers.long()]
            else:
                radial = (self.length/r[:, None]).pow(powers[None, :])
            phase = angle[:, None]*orders[None, :]
            features.append(torch.stack((radial*phase.cos(), radial*phase.sin()), -1).flatten(1))
        return torch.cat(features, -1)

    def raw(self, x):
        return self.head(self.features(x))

    def feature_coordinates(self, base):
        if self.section is None:
            return base
        r = base.norm(dim=-1)
        wallr = self.section.ray_radius(base)
        radial = torch.log(r/wallr)/torch.log(self.radius/wallr)
        mapped = self.length*torch.exp(radial*np.log(self.radius/self.length))
        return base*(mapped/r)[:, None]

    def forward(self, x):
        return super().forward(self.feature_coordinates(x @ self.to_base.T))

def neural_jacobian(residual, parameters, batch=16):
    """Batched reverse-mode derivative of the same current-step weak equations."""
    result=[]
    count=residual.numel()
    for start in range(0,count,batch):
        end=min(start+batch,count)
        seeds=residual.new_zeros((end-start,count))
        seeds[torch.arange(end-start),torch.arange(start,end)]=1
        gradient=torch.autograd.grad(residual,parameters,grad_outputs=seeds,
                                      is_grads_batched=True,retain_graph=True)
        result.append(torch.cat([g.flatten(1) for g in gradient],1).detach().numpy())
    return np.concatenate(result)


def pointwise_basis(function, points):
    """Differentiate a pointwise spatial representation in two coordinate directions."""
    gradients = []
    for axis in range(2):
        direction = torch.zeros_like(points)
        direction[:, axis] = 1.
        with torch.no_grad():
            values, derivative = torch.func.jvp(function, (points,), (direction,))
        gradients.append(derivative)
    return values.detach(), torch.stack(gradients, -1).detach()


def head_basis(net, points):
    """Current neural features and their physical-coordinate gradients."""
    if net.symmetry:
        raise ValueError("The field head predictor requires the asymmetric representation")
    def values(x):
        base = net.feature_coordinates(x @ net.to_base.T)
        r = base.norm(dim=-1)
        envelope = net.scale*(net.length/r)*(1-r/net.radius)/(1-net.length/net.radius)
        features = net.features(base)
        return envelope[:, None]*torch.cat((features, torch.ones_like(features[:, :1])), -1)
    return pointwise_basis(values, points)


def head_equilibrium_predictor(mesh, net, cv, dt, load, f0, pinit, p0, material, tolerance, bedding_old):
    """Solve current-step equilibrium in the existing neural output layer first.

    This uses the constitutive tangent and analytic output-layer derivative.
    Hidden weights and old material states stay fixed. The all-weight solve
    follows whenever this smaller solve cannot meet the requested residual.
    """
    _, current_f, _ = net.fields(mesh.volume.x)
    _, current_fw, _ = net.fields(mesh.boundary.x)
    current = update(current_f, cv, dt, material, bedding_old)
    if float(mesh.weak(current.piola, current_fw, load, p0, f0, pinit).detach().abs().max()) <= tolerance:
        return
    del current_f, current_fw, current
    cache = getattr(net, "_field_head_basis", None)
    hidden = tuple(net.body.parameters())
    if cache is None or cache[0] != id(mesh) or any(
            not torch.equal(saved, current) for saved, current in zip(cache[1], hidden)):
        _, gradient = head_basis(net, mesh.volume.x)
        _, wall_gradient = head_basis(net, mesh.boundary.x)
        cache = (id(mesh), tuple(p.detach().clone() for p in hidden), gradient, wall_gradient)
        net._field_head_basis = cache
    gradient, wall_gradient = cache[2:]
    coefficients = torch.cat((net.head.weight.detach(), net.head.bias.detach()[:, None]), -1)
    v, b = mesh.volume, mesh.boundary
    def deformation(coeff, basis):
        f = f0.expand(len(basis), 3, 3).clone()
        f[:, :2, :2] += torch.einsum("ia,qaj->qij", coeff, basis)
        return f
    def evaluate(coeff, tangent=False):
        f = deformation(coeff, gradient).requires_grad_(tangent)
        fw = deformation(coeff, wall_gradient)
        response = update(f, cv, dt, material, bedding_old)
        residual = mesh.weak(response.piola, fw, load, p0, f0, pinit).flatten()
        return residual, f, response
    steps = 0
    while True:
        residual, f, response = evaluate(coefficients, True)
        r = residual.detach().numpy()
        if np.max(np.abs(r)) <= tolerance:
            break
        tangent = torch.stack([torch.autograd.grad(response.piola[:, i, j].sum(), f,
            retain_graph=True)[0][:, :2, :2] for i in range(2) for j in range(2)], 1).reshape(-1, 2, 2, 2, 2)
        local = torch.einsum("qbj,qijkl,qal,q->qbika", v.grad, tangent, gradient, v.weight)
        matrix = torch.zeros(mesh.nnode, 2, 2, coefficients.shape[1])
        matrix.index_add_(0, v.conn.flatten(), local.reshape(-1, 2, 2, coefficients.shape[1]))
        follower = torch.zeros(len(b.x), 2, 2, 2)
        follower[:, 0, 1, 1], follower[:, 0, 1, 0] = b.normal[:, 0], -b.normal[:, 1]
        follower[:, 1, 0, 1], follower[:, 1, 0, 0] = -b.normal[:, 0], b.normal[:, 1]
        local = torch.einsum("qb,qikl,qal,q->qbika", b.shape, follower, wall_gradient, b.weight*load)
        matrix.index_add_(0, b.conn.flatten(), local.reshape(-1, 2, 2, coefficients.shape[1]))
        jac = (matrix[mesh.free]/(p0*mesh.test_scale[mesh.free, None, None, None])).reshape(len(r), -1).numpy()
        scale = np.linalg.norm(jac, axis=0).clip(1e-10)
        direction = np.linalg.lstsq(jac/scale, -r, rcond=1e-9)[0]/scale
        direction = torch.tensor(direction).reshape_as(coefficients)
        norm = np.linalg.norm(r)
        for backtrack in range(16):
            candidate = coefficients+2.**(-backtrack)*direction
            try:
                trial = evaluate(candidate)[0].detach()
                trial_norm = float(trial.norm())
            except (ValueError, RuntimeError):
                continue
            if trial_norm < norm:
                coefficients = candidate
                steps += 1
                break
        else:
            break
        if trial_norm > .98*norm:
            break
    with torch.no_grad():
        net.head.weight.copy_(coefficients[:, :-1])
        net.head.bias.copy_(coefficients[:, -1])
    print(json.dumps(dict(event="head_equilibrium_predictor", iterations=steps,
        weak_max=float(evaluate(coefficients)[0].detach().abs().max()))), flush=True)


def solve_field_neural(mesh,net,cv,dt,load,f0,pinit,p0,material,controls,bedding_old=None):
    """Damped Gauss-Newton trains every weight using only weak equilibrium."""
    if controls.get("head_equilibrium_predictor"):
        head_equilibrium_predictor(mesh, net, cv, dt, load, f0, pinit, p0, material,
                                   controls["equilibrium_tolerance"], bedding_old)
    parameters=tuple(net.parameters())
    def pack():
        return torch.cat([p.detach().flatten() for p in parameters])
    def unpack(value):
        offset=0
        with torch.no_grad():
            for parameter in parameters:
                parameter.copy_(value[offset:offset+parameter.numel()].reshape_as(parameter))
                offset+=parameter.numel()
    def evaluate():
        _,f,_=net.fields(mesh.volume.x)
        _,fw,_=net.fields(mesh.boundary.x)
        response=update(f,cv,dt,material,bedding_old)
        residual=mesh.weak(response.piola,fw,load,p0,f0,pinit).flatten()
        return residual,response
    damping=controls["gauss_newton_damping"]
    evaluations,iterations=0,0
    while True:
        weak,response=evaluate()
        evaluations+=1
        r=weak.detach().numpy()
        maximum=float(np.max(np.abs(r)))
        print(json.dumps(dict(event="gauss_newton",iteration=iterations,weak_max=maximum,
                               weak_rms=float(np.linalg.norm(r)/np.sqrt(len(r))),damping=damping)),flush=True)
        if maximum<=controls["equilibrium_tolerance"]:
            return response,dict(evaluations=evaluations,iterations=iterations,weak_max=maximum,
                weak_rms=float(np.linalg.norm(r)/np.sqrt(len(r))),constitutive_rms=0.)
        jac=neural_jacobian(weak,parameters)
        scale=np.linalg.norm(jac,axis=0).clip(1e-8)
        normalized=jac/scale[None,:]
        values=pack()
        accepted=False
        while not accepted:
            system=normalized@normalized.T+damping*np.eye(len(r))
            direction=-normalized.T@dense_solve(system,r,assume_a="pos")/scale
            direction=torch.tensor(direction)
            for backtrack in range(12):
                unpack(values+2.**(-backtrack)*direction)
                try:
                    trial,_=evaluate()
                    evaluations+=1
                    norm=float(trial.detach().norm())
                except (ValueError,RuntimeError):
                    continue
                if norm<np.linalg.norm(r)*(1-1e-6):
                    accepted=True
                    damping=max(1e-8,damping*(.5 if backtrack==0 else 2.))
                    break
            if not accepted:
                unpack(values)
                damping*=10
                if damping>1e6:
                    raise RuntimeError("Field Gauss-Newton stagnated before equilibrium acceptance")
        iterations+=1


def survey_points(c):
    """Ground evaluation points for crown and the three monitoring lines."""
    if "field_geometry" in c:
        return FieldSection(c["field_geometry"]).survey(c["line_depths"])[1]
    r, b = c["radius"], c["semiaxis_y"]
    points = [[0., r]]
    for depth in c["line_depths"]:
        y = 1-depth/b
        if not -1 < y < 1:
            raise ValueError("The representative section must contain every survey line")
        x = np.sqrt(1-y*y)
        points.extend([[-r*x, r*y], [r*x, r*y]])
    return torch.tensor(points)


def reporting_points(c, mesh):
    angles = torch.arange(128)*2*torch.pi/128
    directions = torch.stack((angles.cos(), angles.sin()), -1)
    wall = (mesh.section.ray_radius(directions)[:, None]*directions
            if mesh.section is not None else c["radius"]*directions)
    base = torch.cat((survey_points(c), wall))
    physical = base @ mesh.physical_map.T
    if mesh.section is not None:
        physical[:7] = mesh.section.survey(c["line_depths"])[0]
    return base, physical


class PressureHistory:
    def __init__(self, c):
        self.c = c
        with (ROOT/c["pressure_source"]).open(encoding="utf-8-sig", newline="") as handle:
            data = list(csv.DictReader(handle))
        self.channels = {}
        for row in data:
            self.channels.setdefault(row["channel_id"], []).append(
                (float(row["elapsed_time_day"]), float(row["surrounding_rock_pressure_kPa"])))
        self.channels = {key: np.array(sorted(rows)) for key, rows in self.channels.items()}
        self.names = ["right_sidewall", "right_arch_foot", "crown", "left_arch_foot", "left_sidewall", "invert"]
        self.section = FieldSection(c["field_geometry"]) if "field_geometry" in c else None
        if self.section is not None:
            _, survey = self.section.survey(c["line_depths"])
            self.points = torch.cat((survey[[6, 4, 0, 3, 5]],
                                    torch.tensor([[0., self.section.invert]])))
            self.locations = self.section.arc_length(self.points).numpy()
            self.period = self.section.perimeter
        else:
            b = c["semiaxis_y"]
            foot = np.arcsin(1-c["line_depths"][1]/b)
            side = np.arcsin(1-c["line_depths"][2]/b)
            self.angles = np.array([side, foot, np.pi/2, np.pi-foot, np.pi-side, 1.5*np.pi])
            self.locations, self.period = self.angles, 2*np.pi

    def values(self, day):
        values, coverage = [], []
        for name in self.names:
            g = self.channels[name]
            t, p = g.T
            value = np.interp(day, t, p)
            if self.c.get("pressure_before_first") == "zero" and day < t[0]:
                value = 0.
            if self.c["missing_pressure"] == "stable" and not t[0] <= day <= t[-1]:
                # A contrasting extension for missing crown/invert intervals only.
                if name in ("crown", "invert"):
                    value = self.c["stable_pressure_kPa"][name]
            values.append(max(0., value)*1e-3)
            coverage.append(bool(t[0] <= day <= t[-1]))
        return np.array(values), coverage

    def boundary(self, day, mesh):
        values, _ = self.values(day)
        xb = mesh.base.boundary.x
        position = (self.section.arc_length(xb).numpy() if self.section is not None
                    else np.arctan2(xb[:, 1].numpy(), xb[:, 0].numpy()))
        value = np.interp(position, self.locations, values, period=self.period)
        if self.c["pressure_distribution"] == "mean":
            physical = transform_quad(mesh.base.boundary, mesh.physical_map)
            value[:] = np.average(value, weights=physical.weight.numpy())
        return torch.tensor(value)


def schedule(c, dt):
    events = list(c.get("release_stages", {}).get("event_days", []))
    if "progressive_release" in c:
        # A parameter-independent time grid avoids changing the integration
        # error when release durations are perturbed during calibration.
        start, end = c["release_start"], c["end_day"]
        nodes = [*np.arange(start, end, dt), end, 0.,
                 *c["comparison_interval"], *c.get("extra_time_nodes", [])]
        return np.array(sorted(set(t for t in nodes if start <= t <= end)))
    nodes = sorted(set([c["release_start"], c["release_end"], 0.,
                        *c["comparison_interval"], c["end_day"],
                        *c.get("extra_time_nodes", []), *events]))
    times = [nodes[0]]
    for start, end in zip(nodes[:-1], nodes[1:]):
        times.extend(np.linspace(start, end, int(np.ceil((end-start)/dt))+1)[1:])
        if end in events:
            # The first state is the left limit; the duplicate applies the
            # load jump at zero elapsed material time.
            times.append(end)
    return np.array(times)


def release_at(c, mesh, day, step):
    if "progressive_release" in c:
        stages = c["progressive_release"]
        def fraction(start, duration):
            s = float(np.clip((day-start)/duration, 0., 1.))
            return s*s*(3-2*s)
        upper = fraction(stages["upper_start_day"], stages["upper_duration_day"])
        lower = fraction(stages["lower_start_day"], stages["lower_duration_day"])
        y = (mesh.base.boundary.x @ mesh.physical_map.T)[:, 1]
        return torch.where(y >= stages["interface_y_m"], upper, lower)
    if "release_stages" not in c:
        return float(np.clip((day-c["release_start"])/(c["release_end"]-c["release_start"]), 0, 1))
    stages = c["release_stages"]
    upper_day, lower_day = stages["event_days"]
    def opened(event):
        return float(day > event or (day == event and step == 0.))
    y = (mesh.base.boundary.x @ mesh.physical_map.T)[:, 1]
    return torch.where(y >= stages["interface_y_m"], opened(upper_day), opened(lower_day))


def neural_initializations(directory):
    """Read neural weights only; histories and prestress are never transferred."""
    directory = Path(directory)
    source = json.loads((directory/"summary.json").read_text(encoding="utf-8"))
    if source["method"] != "condensed" or not source["complete"]:
        raise ValueError("Initialization requires a completed neural history")
    return [(row["time"], torch.load(directory/"states"/f"step_{i:03d}.pt",
             map_location="cpu", weights_only=True)["network"])
            for i, row in enumerate(source["steps"], 1)]


def initialize_weights(net, state):
    with torch.no_grad():
        for name, parameter in net.named_parameters():
            old = state[name]
            if name == "head.weight" and old.shape[1] < parameter.shape[1]:
                # Keep the shared original features. Enriched radial layouts
                # can reorder modes as their order changes, so reset those
                # coefficients when transferring to a larger representation.
                parameter.zero_()
                shared = min(old.shape[1],net.body[-2].out_features+2*net.angular_order+9)
                parameter[:, :shared].copy_(old[:, :shared])
            else:
                parameter.copy_(old)


def initialization_at(starts, day, step):
    """Match the side of an instantaneous load jump at a repeated time."""
    _, (_, weights) = min(enumerate(starts), key=lambda pair:
        (abs(pair[1][0]-day), -pair[0] if step == 0. else pair[0]))
    return weights


def scale_initial_head(net, residual):
    """Choose a load-amplitude predictor using the same physical residual.

    Only the initial neural weights change; no displacement target, constitutive
    history or accepted equilibrium is changed by this one-dimensional search.
    """
    weight, bias = net.head.weight.detach().clone(), net.head.bias.detach().clone()
    initial = residual()
    def at(scale):
        with torch.no_grad():
            net.head.weight.copy_(scale*weight)
            net.head.bias.copy_(scale*bias)
        return residual()
    zero = at(0.)
    slope = initial-zero
    denominator = float(slope.square().sum())
    best_scale, best_norm = 1., float(initial.norm())
    if denominator > 0:
        scale = -float((zero*slope).sum())/denominator
        try:
            trial = at(scale)
            if float(trial.norm()) < best_norm:
                best_scale = scale
        except (ValueError, RuntimeError):
            pass
    with torch.no_grad():
        net.head.weight.copy_(best_scale*weight)
        net.head.bias.copy_(best_scale*bias)


def run(c, method, specification, dt, out, seed=0, initial_networks=None):
    started = time.perf_counter()
    c = resolve_field_configuration(c)
    if (c.get("bedding_ratio", 0.) or c.get("bedding_fraction", 0.)) and method != "condensed":
        raise ValueError("The bedding field branch is implemented only for the PINN; independent FE inputs remain fixed")
    m = material_from_config(c)
    nonlinear = method in ("fe", "condensed")
    if nonlinear:
        f0, cv0, pinit = prestress(c, m)
    else:
        f0, cv0 = torch.eye(3), torch.eye(3)
        pinit = torch.diag(torch.tensor([-c["kh"]*c["p0"], -c["p0"], 0.]))
    mesh = FieldMesh(c, f0, specification)
    base_points, physical_points = reporting_points(c, mesh)
    probe = mesh.probe(base_points)
    cv = cv0.expand(len(mesh.volume.x), 3, 3).clone()
    cvp = cv0.expand(len(probe.x), 3, 3).clone()
    bedding_initial = .5*f0[:, 1].square().sum().log()
    bedding = bedding_initial.expand(len(mesh.volume.x)).clone() if c.get("bedding_relaxes") else None
    bedding_probe = bedding_initial.expand(len(probe.x)).clone() if c.get("bedding_relaxes") else None
    bedding_states = [bedding_probe.numpy().copy()] if bedding_probe is not None else []
    u = torch.zeros_like(mesh.nodes)
    history = torch.zeros_like(cv)
    devold = history.clone()
    hp, dp = torch.zeros_like(cvp), torch.zeros_like(cvp)
    net = FieldNetwork(c, seed, f0, pinit, mesh.transform) if method == "condensed" else None
    if initial_networks is not None and net is None:
        raise ValueError("Neural weight initialization is only available to the PINN")
    starts = neural_initializations(initial_networks) if initial_networks is not None else []
    pressure = PressureHistory(c)
    times = schedule(c, dt)
    out.mkdir(parents=True, exist_ok=False)
    (out/"states").mkdir()
    initial_sigma = pinit @ f0.T/torch.det(f0)
    values = [np.zeros((len(probe.x), 2))]
    fs = [f0.expand(len(probe.x), 3, 3).numpy()]
    states = [cvp.numpy()]
    stresses = [initial_sigma.expand(len(probe.x), 3, 3).numpy()]
    rows, boundary_rows = [], []

    def save(complete, error=None):
        summary = dict(method=method, configuration=c, material=asdict(m), mesh=specification,
            dt=dt, seed=seed, complete=complete, elapsed_s=time.perf_counter()-started,
            f0=f0.tolist(), initial_piola=pinit.tolist(), steps=rows,
            dofs=(sum(p.numel() for p in net.parameters()) if net else 2*len(mesh.free)))
        if error is not None:
            summary["error"] = error
        (out/"summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        arrays = dict(times=times[:len(values)], points=physical_points.numpy(),
                      reference_points=probe.x.numpy(), u=np.array(values),
                      evaluation_points=(base_points @ mesh.physical_map.T).numpy())
        if nonlinear:
            arrays.update(f=np.array(fs), cv=np.array(states), sigma=np.array(stresses))
            if bedding_states:
                arrays["bedding_strain"] = np.array(bedding_states)
        else:
            arrays["incremental_stress"] = np.array(stresses)-initial_sigma.numpy()
        np.savez_compressed(out/"fields.npz", **arrays)
        if boundary_rows:
            with (out/"boundary_inputs.csv").open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(boundary_rows[0]))
                writer.writeheader()
                writer.writerows(boundary_rows)

    save(False)
    try:
        for index, (previous, t) in enumerate(zip(times[:-1], times[1:]), 1):
            step = t-previous
            mesh.release = release_at(c, mesh, t, step)
            pressure_day = t if c.get("contact_pressure_independent") else max(0., t)
            load = pressure.boundary(pressure_day, mesh)
            if not c.get("contact_pressure_independent"):
                load = load*mesh.release
            channel, coverage = pressure.values(pressure_day)
            boundary_rows.append(dict(time=t, pressure_evaluation_day=pressure_day,
                release_fraction=float(torch.as_tensor(mesh.release).mean()),
                **{name+"_MPa":float(v) for name,v in zip(pressure.names, channel)},
                **{name+"_observed":bool(t>=0 and v) for name,v in zip(pressure.names, coverage)}))
            if method == "fe":
                u, response, info = solve_fe(mesh, u, cv, step, load, f0, pinit, c["p0"], m)
                cv = response.cv.detach()
                uq, fq = fe_fields(u, probe, f0)
            elif method == "condensed":
                if starts and t <= starts[-1][0]+1e-10:
                    weights = initialization_at(starts, max(t, 0.) if c.get("scale_initial_head") else t,
                                                0. if c.get("scale_initial_head") and t <= 0. else step)
                    def initial_residual():
                        _, fi, _ = net.fields(mesh.volume.x)
                        _, fwi, _ = net.fields(mesh.boundary.x)
                        ri = update(fi, cv, step, m, bedding)
                        return mesh.weak(ri.piola, fwi, load, c["p0"], f0, pinit).detach()
                    if c.get("scale_initial_head"):
                        scale_initial_head(net, initial_residual)
                    previous_weights = {name:parameter.detach().clone() for name,parameter in net.named_parameters()}
                    previous_norm = float(initial_residual().norm())
                    initialize_weights(net, weights)
                    try:
                        if c.get("scale_initial_head"):
                            scale_initial_head(net, initial_residual)
                        warm_norm = float(initial_residual().norm())
                    except ValueError:
                        warm_norm = float("inf")
                    if warm_norm > previous_norm:
                        initialize_weights(net, previous_weights)
                response, info = solve_field_neural(mesh, net, cv, step, load, f0, pinit, c["p0"], m, c, bedding)
                cv = response.cv.detach()
                if bedding is not None:
                    bedding = response.bedding_strain.detach()
                uq, fq, _ = net.fields(probe.x, create_graph=False)
                uq, fq = uq.detach(), fq.detach()
            else:
                alpha = 1/(1+step*m.mu1/m.eta)
                shear = m.mu0+(alpha*m.mu1 if method == "history" else
                    m.mu1*np.exp(-(t-c["release_start"])*m.mu1/m.eta))
                offset = alpha*(history-2*m.mu1*devold) if method == "history" else torch.zeros_like(history)
                fw = f0.expand(len(mesh.boundary.x), 3, 3)
                residual = mesh.weak(offset, fw, load, c["p0"], f0, pinit, subtract_initial=False)
                tangent = linear_tensor(m.bulk, shear).expand(len(mesh.volume.x), 2, 2, 2, 2)
                matrix = sparse_tangent(mesh, tangent, 0., c["p0"])
                u[mesh.free] = torch.tensor(spsolve(matrix, -residual.flatten().numpy())).reshape(-1, 2)
                tr, dev = strain(u, mesh.volume)
                sigma = m.bulk*tr[:, None, None]*f0+2*shear*dev+offset
                residual = mesh.weak(sigma, fw, load, c["p0"], f0, pinit, subtract_initial=False)
                if residual.abs().max() > 1e-9:
                    raise RuntimeError("Linear field equilibrium failed")
                tp, devp = strain(u, probe)
                if method == "history":
                    history = alpha*(history+2*m.mu1*(dev-devold))
                    devold = dev
                    hp = alpha*(hp+2*m.mu1*(devp-dp))
                    dp = devp
                    stressp = m.bulk*tp[:, None, None]*f0+2*m.mu0*devp+hp+pinit
                else:
                    stressp = m.bulk*tp[:, None, None]*f0+2*shear*devp+pinit
                uq, fq = fe_fields(u, probe, f0)
                info = dict(weak_max=float(residual.abs().max()))
            if nonlinear:
                report = update(fq, cvp, step, m, bedding_probe)
                cvp, stressp = report.cv.detach(), report.cauchy.detach()
                if bedding_probe is not None:
                    bedding_probe = report.bedding_strain.detach()
                    bedding_states.append(bedding_probe.numpy().copy())
            record = dict(time=float(t), **info)
            rows.append(record)
            values.append(uq.numpy()); fs.append(fq.numpy())
            states.append(cvp.numpy().copy()); stresses.append(stressp.numpy())
            payload = dict(time=float(t))
            if net is None:
                payload["u"] = u
            if nonlinear:
                payload.update(cv=cv, cv_probe=cvp)
                if bedding is not None:
                    payload.update(bedding_strain=bedding, bedding_strain_probe=bedding_probe)
            elif method == "history":
                payload.update(history=history, devold=devold, history_probe=hp, devold_probe=dp)
            if net is not None:
                payload["network"] = net.state_dict()
            torch.save(payload, out/"states"/f"step_{index:03d}.pt")
            save(False)
            print(json.dumps(dict(method=method, scenario=c["scenario"], **record)), flush=True)
        save(True)
    except Exception as exc:
        save(False, str(exc))
        raise
    print(json.dumps(dict(event="complete", method=method, scenario=c["scenario"],
                         elapsed_s=time.perf_counter()-started)), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/history_creep/field.json")
    parser.add_argument("--scenario", default="baseline")
    parser.add_argument("--method", choices=("fe", "condensed", "history", "elapsed_modulus"), required=True)
    parser.add_argument("--angular", type=int)
    parser.add_argument("--radial", type=int)
    parser.add_argument("--dt", type=float)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    c = scenario_config(json.loads((ROOT/args.config).read_text(encoding="utf-8")), args.scenario)
    spec = dict(c["train_mesh" if args.method == "condensed" else "fe_mesh"])
    if args.angular is not None:
        spec["angular"] = args.angular
    if args.radial is not None:
        spec["radial"] = args.radial
    run(c, args.method, spec, args.dt or c["dt"], ROOT/args.out, args.seed)
