"""Compare independently computed field histories with unchanged observations.

This script performs no fitting or parameter selection. Run metadata distinguishes
fixed-input references from the separately calibrated PINN.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from application_observations import forecast_from_last_reading, forecast_from_recent_trend, line_closure

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/"results/history_creep/field"
DATA = ROOT/"data"
CHANNELS = ["GD00", "SL01", "SL02", "SL03"]


def interpolate(times, value, query):
    flat = value.reshape(len(times), -1)
    return np.stack([np.interp(query, times, column) for column in flat.T], -1).reshape(
        (*np.asarray(query).shape, *value.shape[1:]))


def observables(fields, query, reference):
    times, points = fields["times"], fields["points"][:7]
    displacement = fields["u"][:, :7]
    uref = interpolate(times, displacement, reference)
    uq = interpolate(times, displacement, query)
    settlement = -(uq[..., 0, 1]-uref[0, 1])
    closure = line_closure((points+uref)[1:].reshape(3, 2, 2),
        (points+uq)[..., 1:, :].reshape(*np.asarray(query).shape, 3, 2, 2))
    return 1000*np.concatenate((settlement[..., None], closure), -1)


def measured_curves(config):
    data = pd.read_csv(ROOT/config["deformation_source"])
    data["pressure_day"] = data.elapsed_time_day+config["deformation_to_pressure_day"]
    return {key:g.sort_values("pressure_day") for key,g in data.groupby("channel_id")}


def validation_window(times, observed, predicted, origin, end, trend_days):
    """Score the same future readings with fixed physical and past-only baselines."""
    forecast, anchor = forecast_from_last_reading(times, observed, predicted, origin)
    trend, slope = forecast_from_recent_trend(times, observed, origin, trend_days)
    future = (times > origin) & (times <= end)
    if not future.any():
        raise ValueError("No observations in the requested forecast window")
    target = observed[future]
    outputs = dict(cumulative=predicted[future], conditional=forecast[future],
                   persistence=np.full(len(target), observed[anchor]), trend=trend[future])
    metrics = dict(origin_day=float(origin), window_end_day=float(end),
        anchor_day=float(times[anchor]), anchor_age_day=float(origin-times[anchor]),
        last_evaluation_day=float(times[future][-1]), count=int(future.sum()),
        observed_growth_mm=float(target[-1]-observed[anchor]),
        predicted_growth_mm=float(predicted[future][-1]-predicted[anchor]),
        mean_absolute_observed_mm=float(np.abs(target).mean()),
        mean_absolute_increment_mm=float(np.abs(target-observed[anchor]).mean()),
        trend_slope_mm_per_day=slope)
    for name, values in outputs.items():
        metrics[name+"_rmse_mm"] = float(np.mean((values-target)**2)**.5)
        metrics[name+"_mae_mm"] = float(np.abs(values-target).mean())
    rows = [dict(time_day=float(t), observed_mm=float(y),
                 **{name+"_mm":float(values[j]) for name,values in outputs.items()})
            for j,(t,y) in enumerate(zip(times[future],target))]
    return metrics, rows


def summarize_validation(specification, out):
    """Evaluate fixed parameters without rerunning calibration or field equilibrium."""
    spec = json.loads(Path(specification).read_text(encoding="utf-8"))
    run = ROOT/spec["calibrated_run"]
    protocol = json.loads((run/"protocol.json").read_text(encoding="utf-8"))
    summary = json.loads((run/"prediction/summary.json").read_text(encoding="utf-8"))
    if not summary["complete"]:
        raise ValueError("The conditional field history must be complete")
    config = summary["configuration"]
    cutoff = protocol["calibration_interval_day"][1]
    last = protocol["test_interval_day"][1]
    curves = {k:g.loc[g.pressure_day <= last] for k,g in measured_curves(config).items()}
    common_end = min(curves[k].pressure_day.max() for k in CHANNELS)
    first_origin, step, horizon = (spec[k] for k in
        ("first_origin_day", "origin_spacing_day", "horizon_day"))
    if first_origin < cutoff or step <= 0 or horizon <= 0:
        raise ValueError("Forecast origins must follow calibration with positive spacing and horizon")
    origins = np.arange(first_origin, common_end-horizon+1e-10, step)
    if not len(origins):
        raise ValueError("The records do not cover a complete forecast window")
    with np.load(run/"prediction/fields.npz") as loaded:
        fields = dict(loaded)
    if fields["times"][-1] < common_end:
        raise ValueError("The saved history does not cover the evaluation records")
    main, windows, predictions, aggregates = [], [], [], []
    for i,key in enumerate(CHANNELS):
        g = curves[key]
        times = g.pressure_day.to_numpy()
        observed = g.cumulative_deformation_mm.to_numpy()-g.cumulative_deformation_mm.iloc[0]
        predicted = observables(fields, times, times[0])[:,i]
        early = times <= cutoff
        metrics, _ = validation_window(times, observed, predicted, cutoff, last,
                                       spec["trend_history_day"])
        metrics.update(channel=key, reference_day=float(times[0]),
            calibration_count=int(early.sum()),
            calibration_rmse_mm=float(np.mean((predicted[early]-observed[early])**2)**.5),
            calibration_error_percent=float(100*np.abs(predicted[early]-observed[early]).sum()/np.abs(observed[early]).sum()),
            later_error_percent=float(100*metrics["cumulative_mae_mm"]/metrics["mean_absolute_observed_mm"]),
            last_observed_mm=float(observed[-1]), last_predicted_mm=float(predicted[-1]),
            terminal_signed_error_percent=float(100*(predicted[-1]-observed[-1])/observed[-1]))
        main.append(metrics)
        channel_windows = []
        for origin in origins:
            metrics, rows = validation_window(times, observed, predicted, origin, origin+horizon,
                                              spec["trend_history_day"])
            metrics["channel"] = key
            channel_windows.append(metrics)
            predictions.extend(dict(channel=key,origin_day=float(origin),**row) for row in rows)
        windows.extend(channel_windows)
        aggregate = dict(channel=key, origins=len(origins),
            forecast_observation_pairs=sum(row["count"] for row in channel_windows),
            mean_absolute_increment_mm=float(np.mean([row["mean_absolute_increment_mm"] for row in channel_windows])),
            mean_absolute_observed_mm=float(np.mean([row["mean_absolute_observed_mm"] for row in channel_windows])),
            observed_terminal_growth_range_mm=[min(row["observed_growth_mm"] for row in channel_windows),
                                               max(row["observed_growth_mm"] for row in channel_windows)])
        for name in ("cumulative", "conditional", "persistence", "trend"):
            aggregate[name+"_rmse_mm"] = float(np.mean(
                [row[name+"_rmse_mm"]**2 for row in channel_windows])**.5)
            aggregate[name+"_mae_mm"] = float(np.mean([row[name+"_mae_mm"] for row in channel_windows]))
            denominator = aggregate["mean_absolute_observed_mm" if name == "cumulative"
                                    else "mean_absolute_increment_mm"]
            aggregate[name+"_error_percent"] = 100*aggregate[name+"_mae_mm"]/denominator
        for baseline in ("persistence", "trend"):
            aggregate["rmse_reduction_vs_"+baseline+"_percent"] = (
                100*(1-aggregate["conditional_rmse_mm"]/aggregate[baseline+"_rmse_mm"]))
            aggregate["absolute_error_reduction_vs_"+baseline+"_percent"] = (
                100*(1-aggregate["conditional_mae_mm"]/aggregate[baseline+"_mae_mm"]))
        aggregates.append(aggregate)
    result = dict(specification=spec, calibration_cutoff_day=cutoff,
        common_record_end_day=float(common_end), origins_day=origins.tolist(),
        percentage_error_definition={
            "cumulative": "100 times mean absolute prediction error divided by mean absolute observed displacement from the channel's first reading, within the stated calibration or later period.",
            "five_day": "100 times the equally weighted mean of within-window absolute errors divided by the equally weighted mean absolute measured increments from each last-reading anchor. The same denominator applies to the physical model, persistence and recent trend; persistence is 100 percent.",
            "terminal": "100 times (predicted minus observed) divided by observed, at the channel's final reading; negative values indicate underprediction."},
        main_cutoff=main, repeated_forecast=aggregates)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    (out/"metrics.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n",encoding="utf-8")
    pd.DataFrame(windows).to_csv(out/"window_metrics.csv",index=False)
    pd.DataFrame(predictions).to_csv(out/"predictions.csv",index=False)
    print(pd.DataFrame(aggregates)[["channel", "conditional_error_percent",
        "persistence_error_percent", "trend_error_percent"]].to_string(index=False))
    return result


def evidence_constraints():
    snapshot = DATA
    stress = pd.read_csv(snapshot/"stress/field_principal_stress_vs_depth.csv")
    local = stress.loc[stress.depth_m.between(250,350)]
    fit = np.polyfit(stress.depth_m, stress.max_principal_stress_MPa, 1)
    field = dict(n=len(stress), depth_range_m=[float(stress.depth_m.min()),float(stress.depth_m.max())],
        neighborhood_m=[250,350], neighborhood_count=len(local),
        neighborhood_max_principal_range_MPa=[float(local.max_principal_stress_MPa.min()),float(local.max_principal_stress_MPa.max())],
        trend_at_290m_MPa=float(np.polyval(fit,290)),
        use="Stress-scale constraint; maximum principal stress is distinct from the report's p0=5.8 MPa.")
    stress = pd.read_csv(snapshot/"stress/principal_stress_vs_depth_yaan_luding.csv")
    trends = {}
    rows = []
    for key,g in stress.groupby("series"):
        slope, intercept = np.polyfit(g.depth_m,g.principal_stress_MPa,1)
        prediction = slope*290+intercept
        trends[key] = float(prediction)
        rows.append(dict(series=key,n=len(g),min_depth_m=g.depth_m.min(),max_depth_m=g.depth_m.max(),
            slope_MPa_per_m=slope,intercept_MPa=intercept,trend_at_290m_MPa=prediction))
    pd.DataFrame(rows).to_csv(OUT/"regional_stress_trends.csv",index=False)
    regional = dict(stress_at_290m_MPa=trends,SH_over_Sv=trends["S_H"]/trends["S_v"],
        Sh_over_Sv=trends["S_h"]/trends["S_v"],
        use="Separate component depth trends constrain the regional stress interpretation; digitized scattered points are not paired into a measured +860 tensor.")

    pressure_rows = []
    pressures = {}
    sides = ["left_sidewall","left_arch_foot","right_arch_foot","right_sidewall"]
    for section,filename in [("860","x4dk0p860_surrounding_rock_pressure_timehistory.csv"),
                              ("933","x4dk0933_surrounding_rock_pressure_timehistory.csv")]:
        frame = pd.read_csv(DATA/"field"/filename)
        groups = {k:g.sort_values("elapsed_time_day") for k,g in frame.groupby("channel_id")}
        common_start = max(groups[k].elapsed_time_day.min() for k in sides)
        common_end = min(groups[k].elapsed_time_day.max() for k in sides)
        latest = {k:float(np.interp(common_end,groups[k].elapsed_time_day,groups[k].surrounding_rock_pressure_kPa)) for k in sides}
        pressures[section] = dict(four_wall_common_interval_day=[common_start,common_end],
            pressures_at_common_end_kPa=latest,wall_spread_kPa=max(latest.values())-min(latest.values()),
            max_to_min=max(latest.values())/min(latest.values()),
            use="Spatial/time boundary constraint; this section is not paired with a different section's displacement.")
        for key,g in groups.items():
            pressure_rows.append(dict(section=section,channel=key,n=len(g),
                first_day=g.elapsed_time_day.iloc[0],last_day=g.elapsed_time_day.iloc[-1],
                first_kPa=g.surrounding_rock_pressure_kPa.iloc[0],last_kPa=g.surrounding_rock_pressure_kPa.iloc[-1],
                min_kPa=g.surrounding_rock_pressure_kPa.min(),max_kPa=g.surrounding_rock_pressure_kPa.max()))
    pd.DataFrame(pressure_rows).to_csv(OUT/"measured_pressure_summary.csv",index=False)

    frame = pd.read_csv(snapshot/"field/dk0p900_cumulative_deformation_vs_time.csv")
    groups = {k:g.sort_values("days_d") for k,g in frame.groupby("series")}
    start = max(g.days_d.min() for g in groups.values())
    end = min(g.days_d.max() for g in groups.values())
    increments = {key:float(np.interp(end,g.days_d,g.cumulative_deformation_mm)-
        np.interp(start,g.days_d,g.cumulative_deformation_mm)) for key,g in groups.items()}
    # These construction-aligned quantities are explicitly reported in the monitoring-platform test report
    # section 3.1.3(2), not inferred from uncalibrated curve-day origins.
    construction = [dict(stage="installation_to_primary_invert_closure",duration_day=8.,increment_mm=199.3,rate_mm_per_day=24.9),
        dict(stage="primary_closure_to_invert_concreting",duration_day=17.,increment_mm=95.5,rate_mm_per_day=5.6),
        dict(stage="invert_concreting",duration_day=None,increment_mm=14.9,rate_mm_per_day=.9)]
    total = sum(s["increment_mm"] for s in construction)
    for row in construction:
        row["fraction_of_reported_increment"] = row["increment_mm"]/total
    monitored = dict(common_curve_interval_day=[start,end],increments_mm=increments,
        construction_relative_stages=construction,
        rate_ratios=[24.9/5.6,5.6/.9],
        use="Unequal directional increments require separate survey operators; construction-related rate changes require explicit release/prehistory, not a single invariant boundary. Stage durations are relative to installation and are not assigned to digitized curve-day zero or transferred to +860.")
    return dict(field_stress=field,regional_stress=regional,contact_pressures=pressures,section_900=monitored)


def main():
    config = json.loads((ROOT/"config/history_creep/field.json").read_text())
    first,last = config["comparison_interval"]
    curves = measured_curves(config)
    measured = {key:float(np.interp(last,g.pressure_day,g.cumulative_deformation_mm)-
        np.interp(first,g.pressure_day,g.cumulative_deformation_mm)) for key,g in curves.items()}
    models, rows, predicted = {}, [], []
    forecast_metrics, forecast_rows, registered_rows = [], [], []
    incomplete = [path.parent.name for path in OUT.glob("*/protocol.json")
                  if not (path.parent/"prediction/summary.json").exists()]
    paths = sorted([*OUT.glob("*/summary.json"), *OUT.glob("*/prediction/summary.json")])
    for summary_path in paths:
        summary = json.loads(summary_path.read_text())
        name = summary_path.parent.parent.name if summary_path.parent.name == "prediction" else summary_path.parent.name
        if not summary["complete"]:
            incomplete.append(name)
            continue
        with np.load(summary_path.parent/"fields.npz") as loaded:
            fields = dict(loaded)
        if fields["times"][0] > first or fields["times"][-1] < last:
            raise ValueError(f"Incomplete observation interval in {name}")
        endpoints = observables(fields,last,first)
        models[name] = fields
        protocol = (json.loads((summary_path.parent.parent/"protocol.json").read_text())
                    if summary_path.parent.name == "prediction" else None)
        for i,key in enumerate(CHANNELS):
            g = curves[key]
            g = g.loc[g.pressure_day.between(first,last)]
            reference = np.interp(first,curves[key].pressure_day,curves[key].cumulative_deformation_mm)
            observed = g.cumulative_deformation_mm.to_numpy()-reference
            output = observables(fields,g.pressure_day.to_numpy(),first)[:,i]
            if protocol is not None:
                times = g.pressure_day.to_numpy()
                cutoff = protocol["calibration_interval_day"][1]
                registered = curves[key].loc[curves[key].pressure_day <= last]
                registered_times = registered.pressure_day.to_numpy()
                registered_reference = float(registered_times[0])
                registered_observed = (registered.cumulative_deformation_mm.to_numpy()
                                       -registered.cumulative_deformation_mm.iloc[0])
                registered_output = observables(fields, registered_times, registered_reference)[:,i]
                registered_error = registered_output-registered_observed
                registered_early = registered_times <= cutoff
                registered_rows.extend(dict(run=name,channel=key,time_day=float(t),
                    reference_day=registered_reference,split="calibration" if t<=cutoff else "test",
                    observed_increment_mm=float(y),predicted_increment_mm=float(p))
                    for t,y,p in zip(registered_times,registered_observed,registered_output))
                forecast, anchor = forecast_from_last_reading(times, observed, output, cutoff)
                test = times > cutoff
                five_day = test & (times <= cutoff+5.)
                error = forecast[test]-observed[test]
                forecast_metrics.append(dict(run=name,channel=key,anchor_day=float(times[anchor]),
                    cutoff_day=cutoff,calibration_reference_mode=protocol.get("reference_mode","common_start"),
                    registered_reference_day=registered_reference,
                    registered_calibration_rmse_mm=float(np.mean(registered_error[registered_early]**2)**.5),
                    registered_test_rmse_mm=float(np.mean(registered_error[~registered_early]**2)**.5),
                    anchor_observed_increment_mm=float(observed[anchor]),
                    observation_offset_mm=float(observed[anchor]-output[anchor]),
                    last_day=float(times[test][-1]),horizon_day=float(times[test][-1]-times[anchor]),
                    count=int(test.sum()),raw_test_rmse_mm=float(np.mean((output[test]-observed[test])**2)**.5),
                    common_calibration_rmse_mm=float(np.mean((output[~test]-observed[~test])**2)**.5),
                    anchored_test_rmse_mm=float(np.mean(error**2)**.5),
                    anchored_test_mae_mm=float(np.mean(np.abs(error))),
                    persistence_test_rmse_mm=float(np.mean((observed[test]-observed[anchor])**2)**.5),
                    five_day_after_cutoff_count=int(five_day.sum()),
                    five_day_after_cutoff_rmse_mm=float(np.mean((forecast[five_day]-observed[five_day])**2)**.5),
                    five_day_persistence_rmse_mm=float(np.mean((observed[five_day]-observed[anchor])**2)**.5),
                    final_observed_growth_mm=float(observed[test][-1]-observed[anchor]),
                    final_predicted_growth_mm=float(output[test][-1]-output[anchor]),
                    final_forecast_error_mm=float(error[-1])))
                forecast_rows.extend(dict(run=name,channel=key,time_day=float(t),
                    observed_increment_mm=float(y),raw_predicted_increment_mm=float(raw),
                    forecast_from_last_reading_mm=float(anchored)) for t,y,raw,anchored in
                    zip(times[test],observed[test],output[test],forecast[test]))
            rows.append(dict(run=name,scenario=summary["configuration"]["scenario"],method=summary["method"],
                channel=key,dt=summary["dt"],angular=summary["mesh"]["angular"],radial=summary["mesh"]["radial"],
                young_MPa=summary["configuration"]["young"],fraction=summary["configuration"]["fraction"],
                relaxation_day=summary["configuration"]["relaxation_day"],
                elapsed_s=summary["elapsed_s"],increment_mm=float(endpoints[i]),
                measured_increment_mm=measured[key],endpoint_bias_percent=100*(float(endpoints[i])/measured[key]-1),
                rmse_mm=float(np.mean((output-observed)**2)**.5)))
            predicted.extend(dict(run=name,channel=key,time_day=float(t),measured_increment_mm=float(o),
                predicted_increment_mm=float(p)) for t,o,p in zip(g.pressure_day,observed,output))
    pd.DataFrame(rows).to_csv(OUT/"scenario_observations.csv",index=False)
    pd.DataFrame(predicted).to_csv(OUT/"predicted_at_observations.csv",index=False)
    if forecast_metrics:
        pd.DataFrame(forecast_rows).to_csv(OUT/"forecast_from_last_reading.csv",index=False)
        pd.DataFrame(registered_rows).to_csv(OUT/"registered_at_observations.csv",index=False)
        (OUT/"forecast_metrics.json").write_text(json.dumps(forecast_metrics,indent=2)+"\n",encoding="utf-8")
    comparisons = {}
    pairs = [("baseline_fe","baseline_condensed"),
             ("baseline_condensed","material_e143_condensed"),
             ("material_e143_fe","material_e143_condensed"),
             ("slate_lab169_fe","slate_lab169_condensed")]
    for left,right in pairs:
        if left not in models or right not in models:
            continue
        a,b = models[left],models[right]
        t0 = max(a["times"][0],b["times"][0])
        query = np.unique(np.r_[a["times"],b["times"]])
        query = query[(query>=t0)&(query<=min(a["times"][-1],b["times"][-1]))]
        ua,ub = interpolate(a["times"],a["u"],query),interpolate(b["times"],b["u"],query)
        monitor_query = np.linspace(first,last,201)
        delta = observables(b,monitor_query,first)-observables(a,monitor_query,first)
        same_points = np.allclose(a["points"], b["points"], rtol=0, atol=1e-10)
        comparisons[left+"__"+right] = dict(reference=left,comparison=right,
            max_wall_displacement_difference_mm=(float(np.linalg.norm(ua[:,7:]-ub[:,7:],axis=-1).max()*1000)
                                                 if same_points else None),
            reference_wall_peak_mm=float(np.linalg.norm(ua[:,7:],axis=-1).max()*1000),
            max_observable_increment_difference_mm=dict(zip(CHANNELS,np.abs(delta).max(0).tolist())),
            endpoint_increment_difference_mm=dict(zip(CHANNELS,delta[-1].tolist())))
    result = dict(comparison_interval_pressure_day=[first,last],measured_increment_mm=measured,
        comparisons=comparisons,incomplete=incomplete,
        interpretation="Independent FE references are not displacement-fitted. Each calibrated PINN has its own prefix cutoff and protocol. Common-origin cumulative, actual-first-reading cumulative and last-reading forecast errors are separate readouts of the same physical history. Previously viewed later observations informed revised model development; rolling-prefix comparisons are retrospective and conditional on measured pressure.")
    (OUT/"comparison.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    (OUT/"field_constraints.json").write_text(json.dumps(evidence_constraints(),indent=2),encoding="utf-8")
    print(pd.DataFrame(rows).pivot(index="run",columns="channel",values="increment_mm").round(3).to_string())
    print("Incomplete:",incomplete)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation", help="Evaluate the declared fixed-parameter forecast protocol only")
    parser.add_argument("--out", default="results/history_creep/field/validation")
    args = parser.parse_args()
    if args.validation:
        summarize_validation(ROOT/args.validation, ROOT/args.out)
    else:
        main()
