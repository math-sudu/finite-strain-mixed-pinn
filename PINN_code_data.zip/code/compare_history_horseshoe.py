"""Compare independently advanced non-circular histories without plotting."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def read(directory):
    directory = Path(directory)
    summary = json.loads((directory/"summary.json").read_text(encoding="utf-8"))
    if not summary["complete"]:
        raise ValueError(f"Incomplete path: {directory}")
    return summary, dict(np.load(directory/"fields.npz"))


def aligned(reference, query):
    indices = []
    for t in query["times"]:
        found = np.flatnonzero(np.isclose(reference["times"], t, atol=1e-9, rtol=0))
        if len(found) != 1:
            raise ValueError("Reference must contain every requested physical time")
        indices.append(found[0])
    if not np.allclose(reference["points"], query["points"], atol=1e-10, rtol=0):
        raise ValueError("Reporting points differ")
    return {key: value[indices] if key in ("times", "u", "f", "sigma", "cv", "energy", "dissipation") else value
            for key, value in reference.items()}


def metrics(summary, actual, reference):
    nv = int(actual["volume_count"])
    weight = actual["weights"]
    wall_ref, wall = reference["u"][:, nv:], actual["u"][:, nv:]
    wall_delta = np.linalg.norm(wall-wall_ref, axis=-1)
    wall_peak = np.linalg.norm(wall_ref, axis=-1).max()
    p0 = summary["configuration"]["p0"]
    result = dict(wall_max_absolute_m=float(wall_delta.max()),
        wall_max_over_reference_peak=float(wall_delta.max()/wall_peak),
        reference_wall_peak_m=float(wall_peak))

    def rms(value, w):
        summed = value.reshape(value.shape[0], value.shape[1], -1)
        return np.sqrt((summed**2*w[None, :, None]).sum()/(value.shape[0]*w.sum()))

    near = np.linalg.norm(actual["points"][:nv], axis=1) < 2*summary["configuration"]["length_scale"]
    for region, selected in (("domain", np.ones(nv, dtype=bool)), ("near_wall", near)):
        w = weight[selected]
        for key in ("u", "sigma", "cv"):
            difference = actual[key][:, :nv][:, selected]-reference[key][:, :nv][:, selected]
            ref = reference[key][:, :nv][:, selected]
            if key == "cv":
                ref = ref-np.array(summary["initial_Cv"])
            numerator, denominator = rms(difference, w), rms(ref, w)
            result[f"{region}_{key}_relative_l2"] = float(numerator/denominator)
            if key == "sigma":
                result[f"{region}_stress_rms_over_p0"] = float(numerator/p0)
    result["wall_stress_max_over_p0"] = float(np.linalg.norm(actual["sigma"][:, nv:]-reference["sigma"][:, nv:], axis=(-2, -1)).max()/p0)
    for key in ("energy", "dissipation"):
        a = (actual[key][:, :nv]*weight).sum(1)
        b = (reference[key][:, :nv]*weight).sum(1)
        result[f"{key}_integral_max_absolute"] = float(abs(a-b).max())
        result[f"{key}_integral_max_over_reference_peak"] = float(abs(a-b).max()/abs(b).max())
    return result


def compare(reference_dir, directories, output):
    rs, ref = read(reference_dir)
    result = dict(reference=str(reference_dir), reference_dt=rs["dt"],
        interpretation="Differences between independent complete histories at common physical times. FE shares the separately verified material kernel. Spatial/time refinement differences are not neural errors.",
        comparisons={})
    rows = []
    for directory in directories:
        summary, fields = read(directory)
        if summary["case"] != rs["case"]:
            raise ValueError("Material cases must match")
        selected = aligned(ref, fields)
        item = metrics(summary, fields, selected)
        item.update(method=summary["method"], seed=summary["seed"], dt=summary["dt"],
            mesh=summary["mesh"], parameters=summary["parameters"],
            elapsed_s=summary["elapsed_s"], solve_s=summary["solve_s"], report_s=summary["report_s"],
            peak_process_bytes=summary["peak_process_bytes"],
            accepted_step_evaluations=sum(x["evaluations"] for x in summary["steps"]),
            cost_record_complete=summary.get("cost_record_complete", True),
            complete=summary["complete"])
        result["comparisons"][str(directory)] = item
        nv = int(fields["volume_count"])
        for i, t in enumerate(fields["times"]):
            rows.append(dict(run=Path(directory).name, time=t,
                pressure=summary["steps"][i]["pressure"],
                max_wall_displacement=np.linalg.norm(fields["u"][i, nv:], axis=-1).max(),
                max_wall_vector_error=np.linalg.norm(fields["u"][i, nv:]-selected["u"][i, nv:], axis=-1).max(),
                j_min=summary["steps"][i]["j_min"], j_max=summary["steps"][i]["j_max"]))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    with output.with_suffix(".csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(result, indent=2))


def compare_m0_models(directories, output, linear_refined=None):
    finite_summary, finite = read(directories[0])
    others = [dict(np.load(Path(path)/"fields.npz")) for path in directories[1:]]
    linear, elapsed = others
    physical_points = finite["points"] @ np.array(finite_summary["initial_F"])[:2, :2].T
    if not np.allclose(physical_points, linear["points"], atol=1e-9, rtol=0):
        raise ValueError("Initial physical reporting positions must match")
    if any(not np.array_equal(data["times"], linear["times"]) for data in (finite, elapsed)):
        raise ValueError("Physical output times must match")
    nv = int(linear["volume_count"])
    reference = linear["u"]
    peak = np.linalg.norm(reference[:, nv:], axis=-1).max()
    weight = linear["weights"]
    result = dict(reference=str(directories[1]),
        scope="M0 at identical material parameters and physical load/time points. The finite versus small-strain comparison includes the constitutive linearization, initial prestress and follower pressure; it does not isolate a geometry-only effect.", comparisons={})
    if linear_refined:
        fine = dict(np.load(Path(linear_refined)/"fields.npz"))
        indices = [np.flatnonzero(np.isclose(fine["times"], t, atol=1e-9, rtol=0))[0] for t in linear["times"]]
        error = np.linalg.norm(fine["u"][indices, nv:]-reference[:, nv:], axis=-1).max()
        result["linear_history_time_refinement"] = dict(source=str(linear_refined),
            wall_max_absolute_m=float(error), wall_max_over_reference_peak=float(error/peak))
    rows = []
    for name, data in (("finite_history", finite), ("elapsed_modulus", elapsed)):
        difference = data["u"]-reference
        wall_delta = np.linalg.norm(difference[:, nv:], axis=-1)
        relative = np.sqrt((difference[:, :nv]**2*weight[None, :, None]).sum()/
                           (reference[:, :nv]**2*weight[None, :, None]).sum())
        result["comparisons"][name] = dict(wall_max_absolute_m=float(wall_delta.max()),
            wall_max_over_linear_history_peak=float(wall_delta.max()/peak),
            domain_u_relative_l2=float(relative),
            final_max_wall_displacement_m=float(np.linalg.norm(data["u"][-1, nv:], axis=-1).max()))
    for i, t in enumerate(linear["times"]):
        rows.append(dict(time=float(t),
            finite_history_max_wall_m=float(np.linalg.norm(finite["u"][i, nv:], axis=-1).max()),
            linear_history_max_wall_m=float(np.linalg.norm(reference[i, nv:], axis=-1).max()),
            elapsed_modulus_max_wall_m=float(np.linalg.norm(elapsed["u"][i, nv:], axis=-1).max()),
            history_omission_max_wall_error_m=float(np.linalg.norm(elapsed["u"][i, nv:]-reference[i, nv:], axis=-1).max())))
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    with output.with_suffix(".csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference")
    parser.add_argument("--runs", nargs="+")
    parser.add_argument("--m0-models", nargs=3, metavar=("FINITE", "LINEAR", "ELAPSED"))
    parser.add_argument("--linear-refined")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    if args.m0_models:
        compare_m0_models(args.m0_models, ROOT/args.out, args.linear_refined)
    elif args.reference and args.runs:
        compare(args.reference, args.runs, ROOT/args.out)
    else:
        parser.error("Provide --reference and --runs, or --m0-models")
