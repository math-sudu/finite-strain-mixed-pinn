"""Intersect monitoring lines with the documented circular arcs."""
import math

def horizontal_intersections(arcs, y):
    hits=[]
    for arc in arcs:
        cx,cy=arc["center"];r=arc["radius"];value=(y-cy)/r
        if abs(value)>1:continue
        angle=math.asin(value)
        for a in (angle,math.pi-angle):
            relative=(a-arc["start_rad"])%(2*math.pi)
            if relative<=arc["sweep_rad"]+1e-12:
                hits.append((cx+r*math.cos(a), math.degrees(a)))
    if len(hits)!=2:
        raise ValueError(f"Expected two wall intersections at y={y}, got {hits}")
    return sorted(hits)
