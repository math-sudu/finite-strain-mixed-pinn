"""Non-circular full-history weak PINN and independent displacement Q2 FEM.

The solvers share the verified constitutive kernel, geometry and prescribed
loads, but no displacement labels, initial guesses or material histories.
Reporting points carry their own replayed history through every accepted step.
"""
import argparse
from dataclasses import asdict
import json
import platform
from pathlib import Path
import time

import numpy as np
import psutil
from scipy.optimize import brentq
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
import torch

from history_isochoric import IsoMaterial, update
from history_material import elastic
from horseshoe_geometry import HorseshoeWall
from mixed_geometry import CurvedMesh
from mixed_q2 import CurvedQ2Mesh
from mixed_reference_sampling import locate

ROOT = Path(__file__).resolve().parents[1]
torch.set_default_dtype(torch.float64)


def embed(a):
    f = a.new_zeros((*a.shape[:-2], 3, 3))
    f[..., :2, :2], f[..., 2, 2] = a, 1.
    return f


def relaxed_state(f):
    """The isochoric viscous branch is relaxed, including in plane strain."""
    return (f.transpose(-1, -2) @ f)*torch.linalg.det(f)[..., None, None].pow(-2/3)


def initial_state(material, p0, device="cpu"):
    def balance(s):
        f = torch.diag(torch.tensor([s, s, 1.]))
        tau = elastic(f @ f.T, material.mu0, material.bulk)[0]
        return float(tau[0, 0]/s**2)+p0
    s = brentq(balance, .2, 1., xtol=1e-14)
    f0 = torch.diag(torch.tensor([s, s, 1.], device=device))
    cv0 = relaxed_state(f0)
    pinit = update(f0[None], cv0[None], 0., material).piola[0].detach()
    return f0, cv0, pinit


def make_mesh(config, f0, specification):
    wall = HorseshoeWall.from_json(ROOT/config["geometry"], device=f0.device,
                                   scale=1/float(f0[0, 0]))
    spec = dict(specification)
    degree = spec.pop("degree")
    cls = {1: CurvedMesh, 2: CurvedQ2Mesh}[degree]
    return cls(wall, config["outer_radius"]/float(f0[0, 0]), **spec)


def fe_fields(u, quad, f0):
    value = (u[quad.conn]*quad.shape[:, :, None]).sum(1)
    f = embed(f0[:2, :2]+torch.einsum("qai,qaj->qij", u[quad.conn], quad.grad))
    return value, f


def sparse_tangent(mesh, tangent, pressure, p0):
    """Assemble the unsymmetric material and follower-pressure derivatives."""
    v, b = mesh.volume, mesh.boundary
    nd = 2*mesh.conn.shape[1]
    ke = torch.einsum("qaj,qijkl,qbl,q->qaibk", v.grad, tangent, v.grad, v.weight)
    ke = ke.reshape(len(mesh.conn), -1, nd, nd).sum(1)
    follower = tangent.new_zeros((len(b.x), 2, 2, 2))
    n = b.normal
    follower[:, 0, 1, 1], follower[:, 0, 1, 0] = n[:, 0], -n[:, 1]
    follower[:, 1, 0, 1], follower[:, 1, 0, 0] = -n[:, 0], n[:, 1]
    kw = torch.einsum("qa,qikl,qbl,q->qaibk", b.shape, follower, b.grad, b.weight*pressure)
    ke[:mesh.na] += kw.reshape(mesh.na, -1, nd, nd).sum(1)
    dofs = (2*mesh.conn[:, :, None]+torch.arange(2, device=tangent.device)).reshape(-1, nd)
    rows = dofs[:, :, None].expand_as(ke).flatten().cpu().numpy()
    cols = dofs[:, None, :].expand_as(ke).flatten().cpu().numpy()
    nf = 2*len(mesh.free)
    keep = (rows < nf) & (cols < nf)
    scale = (p0*mesh.test_scale[mesh.free]).repeat_interleave(2).cpu().numpy()
    values = ke.detach().flatten().cpu().numpy()[keep]/scale[rows[keep]]
    return coo_matrix((values, (rows[keep], cols[keep])), shape=(nf, nf)).tocsc()


def solve_fe(mesh, u, cv, dt, pressure, f0, pinit, p0, material):
    def evaluate(value):
        _, f = fe_fields(value, mesh.volume, f0)
        _, fw = fe_fields(value, mesh.boundary, f0)
        response = update(f, cv, dt, material)
        r = mesh.weak(response.piola, fw, pressure, p0, f0, pinit)
        return r, response
    evaluations = 0
    for iteration in range(40):
        _, f = fe_fields(u, mesh.volume, f0)
        f = f.detach().requires_grad_(True)
        _, fw = fe_fields(u, mesh.boundary, f0)
        response = update(f, cv, dt, material)
        residual = mesh.weak(response.piola, fw, pressure, p0, f0, pinit)
        evaluations += 1
        if float(residual.detach().abs().max()) < 2e-9:
            return u.detach(), response, dict(evaluations=evaluations, iterations=iteration,
                weak_max=float(residual.detach().abs().max()),
                weak_rms=float(residual.detach().square().mean().sqrt()), constitutive_rms=0.)
        tangent = torch.stack([torch.autograd.grad(response.piola[:, i, j].sum(), f,
            retain_graph=True)[0][:, :2, :2] for i in range(2) for j in range(2)], 1).reshape(-1, 2, 2, 2, 2)
        matrix = sparse_tangent(mesh, tangent, pressure, p0)
        direction = torch.as_tensor(spsolve(matrix, -residual.detach().flatten().cpu().numpy()),
                                    device=u.device).reshape(-1, 2)
        if not bool(torch.isfinite(direction).all()):
            raise RuntimeError("Nonfinite FE Newton direction")
        for backtrack in range(20):
            candidate = u.clone()
            candidate[mesh.free] += 2.**(-backtrack)*direction
            try:
                rr, _ = evaluate(candidate)
                evaluations += 1
                if float(rr.norm()) < float(residual.detach().norm()):
                    u = candidate
                    break
            except (ValueError, RuntimeError):
                if backtrack == 19:
                    raise
        else:
            raise RuntimeError("FE equilibrium line search failed")
    raise RuntimeError("FE equilibrium did not converge")


class Network(torch.nn.Module):
    def __init__(self, config, kind, seed, f0, pinit):
        super().__init__()
        torch.manual_seed(seed)
        self.kind = kind
        self.length = config["length_scale"]/float(f0[0, 0])
        self.radius = config["outer_radius"]/float(f0[0, 0])
        self.scale, self.p0 = config["displacement_scale"], config["p0"]
        self.symmetry = config["symmetry_x"]
        self.register_buffer("f0", f0.clone())
        self.register_buffer("pinit", pinit.clone())
        width = config["network_width"]
        self.body = torch.nn.Sequential(torch.nn.Linear(3, width), torch.nn.Tanh(),
            torch.nn.Linear(width, width), torch.nn.Tanh())
        self.head = torch.nn.Linear(width+5, 2 if kind == "condensed" else 6)
        torch.nn.init.zeros_(self.head.weight)
        torch.nn.init.zeros_(self.head.bias)
        self.to(device=f0.device, dtype=f0.dtype)

    def raw(self, x):
        r = x.norm(dim=-1)
        c, s = x[:, 0]/r, x[:, 1]/r
        z = torch.stack((torch.log(r/self.length)/np.log(self.radius/self.length), c, s), -1)
        direct = torch.stack((c, s, c.square()-s.square(), 2*c*s, torch.ones_like(c)), -1)
        return self.head(torch.cat((self.body(z), direct), -1))

    def forward(self, x):
        raw = self.raw(x)
        if self.symmetry:
            reflected = self.raw(x*x.new_tensor([-1., 1.]))
            parity = x.new_tensor([-1., 1.] if self.kind == "condensed" else [-1., 1., 1., -1., -1., 1.])
            raw = .5*(raw+parity*reflected)
        r = x.norm(dim=-1)
        envelope = (self.length/r)*(1-r/self.radius)/(1-self.length/self.radius)
        u = self.scale*envelope[:, None]*raw[:, :2]
        head = (self.pinit[:2, :2]+self.p0*(self.length/r)[:, None, None].square()*
                raw[:, 2:].reshape(-1, 2, 2)) if self.kind == "mixed" else None
        return u, head

    def fields(self, x, create_graph=True):
        xx = x.detach().requires_grad_(True)
        u, head = self(xx)
        grad = torch.stack([torch.autograd.grad(u[:, i].sum(), xx, create_graph=create_graph,
                            retain_graph=True)[0] for i in range(2)], 1)
        return u, embed(self.f0[:2, :2]+grad), head


def solve_neural(mesh, net, cv, dt, pressure, f0, pinit, p0, material, controls):
    def evaluate():
        _, f, head = net.fields(mesh.volume.x)
        _, fw, _ = net.fields(mesh.boundary.x)
        response = update(f, cv, dt, material)
        weak = mesh.weak(response.piola if net.kind == "condensed" else embed(head),
                         fw, pressure, p0, f0, pinit)
        constitutive = ((head-response.piola[:, :2, :2])/p0 if net.kind == "mixed"
                        else weak.new_zeros(1))
        loss = weak.square().mean()+constitutive.square().mean()
        return loss, weak, constitutive, response
    optimizer = torch.optim.LBFGS(net.parameters(), lr=controls.get("learning_rate", 1.), max_iter=controls["iterations"],
        max_eval=2*controls["iterations"], tolerance_grad=1e-12, tolerance_change=1e-16,
        history_size=80, line_search_fn="strong_wolfe")
    evaluations, blocks, previous = 0, 0, float("inf")

    def closure():
        nonlocal evaluations
        optimizer.zero_grad()
        loss = evaluate()[0]
        objective = controls.get("loss_scale", 1.)*loss
        objective.backward()
        evaluations += 1
        return objective

    while True:
        optimizer.step(closure)
        loss, weak, constitutive, response = evaluate()
        blocks += 1
        info = dict(evaluations=evaluations, blocks=blocks, loss=float(loss.detach()),
            weak_max=float(weak.detach().abs().max()), weak_rms=float(weak.detach().square().mean().sqrt()),
            constitutive_rms=float(constitutive.detach().square().mean().sqrt()),
            constitutive_max=float(constitutive.detach().abs().max()))
        print(json.dumps(dict(event="optimization", method=net.kind, dt=dt, pressure=pressure, **info)), flush=True)
        if info["weak_max"] <= controls["equilibrium_tolerance"] and info["constitutive_rms"] <= controls["constitutive_tolerance"]:
            return response, info
        if info["loss"] >= previous*(1-1e-4):
            raise RuntimeError("Neural optimization stagnated before equilibrium acceptance")
        previous = info["loss"]


def schedule(config, dt):
    times = []
    for start, end in zip(config["load_times"][:-1], config["load_times"][1:]):
        times.extend(np.linspace(start, end, int(np.ceil((end-start)/dt))+1)[1:])
    times = np.array(times)
    return times, np.interp(times, config["load_times"], config["pressure_ratios"])*config["p0"]


def report_grid(config, f0):
    mesh = make_mesh(config, f0, config["report_mesh"])
    # These fixed wall points resolve angular variation and the curvature joins.
    ids = torch.arange(6, device=f0.device).repeat_interleave(16)
    fraction = torch.arange(16, device=f0.device).repeat(6)/16
    wall, _ = mesh.wall.sample(ids, fraction)
    return torch.cat((mesh.volume.x, wall)), mesh.volume.weight, len(mesh.volume.x)


def run(config, case, kind, seed, specification, dt, out, device="cpu", stop_time=None, resume_from=None):
    process = psutil.Process()
    start, cpu_start = time.perf_counter(), time.process_time()
    fit = json.loads((ROOT/config["cases"][case]).read_text(encoding="utf-8"))
    material = IsoMaterial(**fit["material"])
    f0, cv0, pinit = initial_state(material, config["p0"], device)
    mesh = make_mesh(config, f0, specification)
    cv = cv0.expand(len(mesh.volume.x), 3, 3).clone()
    u = torch.zeros_like(mesh.nodes)
    net = None if kind == "fe" else Network(config, kind, seed, f0, pinit)
    points, weights, nv = report_grid(config, f0)
    interpolation = locate(mesh, points) if kind == "fe" else None
    report_cv = cv0.expand(len(points), 3, 3).clone()
    times, pressures = schedule(config, dt)
    summary = dict(configuration=config, case=case, material_source=config["cases"][case],
        material=asdict(material), method=kind, seed=seed, mesh=specification, actual_angular=mesh.na,
        dt=dt, initial_F=f0.cpu().tolist(), initial_Cv=cv0.cpu().tolist(),
        hardware=platform.processor(), torch_version=torch.__version__, device=device,
        device_name=torch.cuda.get_device_name(device) if device.startswith("cuda") else platform.processor(),
        threads=torch.get_num_threads(), parameters=sum(p.numel() for p in net.parameters()) if net else 2*len(mesh.free),
        volume_points=len(mesh.volume.x), steps=[], complete=False)
    states, arrays = [], {key: [] for key in ("u", "f", "sigma", "cv", "energy", "dissipation")}
    previous, report_s, solve_s = 0., 0., 0.
    prior_elapsed, prior_cpu, prior_peak = 0., 0., 0
    prior_cost_complete = True
    if resume_from is not None:
        saved = json.loads((resume_from/"summary.json").read_text(encoding="utf-8"))
        # Numerical optimizer controls may change; the physical problem may not.
        scientific = lambda c: {key: value for key, value in c.items()
                               if key not in ("learning_rate", "loss_scale")}
        if saved["complete"] or scientific(saved["configuration"]) != scientific(config):
            raise ValueError("Resume requires an incomplete path with unchanged problem inputs")
        if any(saved[key] != summary[key] for key in ("case", "material", "method", "seed", "mesh", "dt")):
            raise ValueError("Resume cannot change material, method, mesh, seed or time discretization")
        checkpoint = torch.load(resume_from/"accepted_states.pt", weights_only=False, map_location=device)
        with np.load(resume_from/"fields.npz") as stored:
            if not np.allclose(stored["points"], points.cpu().numpy(), rtol=0, atol=1e-12):
                raise ValueError("Resume report points differ")
            arrays = {key: list(stored[key]) for key in arrays}
        states, cv, previous = checkpoint["states"], checkpoint["cv"], checkpoint["previous_time"]
        if previous != saved["steps"][-1]["time"] or len(states) != len(saved["steps"]):
            raise ValueError("Accepted checkpoint and saved path disagree")
        if net is None:
            u = states[-1].to(device)
        else:
            net.load_state_dict(states[-1])
        report_cv = torch.tensor(arrays["cv"][-1], device=device)
        summary["steps"] = saved["steps"]
        summary["resumed_from"] = str(resume_from)
        summary["prior_failure"] = saved.get("failure")
        prior_elapsed, prior_cpu = saved["elapsed_s"], saved["cpu_s"]
        prior_peak = saved["peak_process_bytes"]
        report_s, solve_s = saved["report_s"], saved["solve_s"]
        prior_cost_complete = saved.get("cost_record_complete", True)

    def save_progress(final=False):
        memory = process.memory_info()
        summary.update(elapsed_s=prior_elapsed+time.perf_counter()-start,
            cpu_s=prior_cpu+time.process_time()-cpu_start, solve_s=solve_s, report_s=report_s,
            peak_process_bytes=max(prior_peak, getattr(memory, "peak_wset", memory.rss)),
            peak_cuda_bytes=torch.cuda.max_memory_allocated(device) if device.startswith("cuda") else 0,
            cost_record_complete=final and prior_cost_complete)
        (out/"summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        np.savez_compressed(out/"fields.npz", points=points.cpu().numpy(), weights=weights.cpu().numpy(),
            volume_count=nv, times=np.array([r["time"] for r in summary["steps"]]),
            **{key: np.array(value) for key, value in arrays.items()})

    out.mkdir(parents=True, exist_ok=False)
    try:
        for t, pressure in zip(times, pressures):
            if t <= previous+1e-10:
                continue
            if stop_time is not None and t > stop_time+1e-10:
                break
            increment = float(t-previous)
            tick = time.perf_counter()
            if kind == "fe":
                u, response, info = solve_fe(mesh, u, cv, increment, float(pressure), f0, pinit,
                                             config["p0"], material)
                states.append(u.detach().cpu().clone())
            else:
                response, info = solve_neural(mesh, net, cv, increment, float(pressure), f0, pinit,
                                              config["p0"], material, config)
                states.append({key: value.detach().cpu().clone() for key, value in net.state_dict().items()})
            step_s = time.perf_counter()-tick
            solve_s += step_s
            cv = response.cv.detach()
            tick = time.perf_counter()
            if kind == "fe":
                uq, f = fe_fields(u, interpolation, f0)
            else:
                uq, f, _ = net.fields(points, create_graph=False)
            uq, f = uq.detach(), f.detach()
            report = update(f, report_cv, increment, material)
            report_cv = report.cv.detach()
            values = (uq, f, report.cauchy, report_cv, report.energy, report.dissipation)
            for key, value in zip(arrays, values):
                arrays[key].append(value.detach().cpu().numpy())
            report_s += time.perf_counter()-tick
            singular = torch.linalg.svdvals(f)
            row = dict(time=float(t), pressure=float(pressure), dt=increment, solve_s=step_s,
                max_wall_displacement=float(uq[nv:].norm(dim=-1).max()),
                j_min=float(torch.linalg.det(f).min()), j_max=float(torch.linalg.det(f).max()),
                stretch_min=float(singular.min()), stretch_max=float(singular.max()), **info)
            summary["steps"].append(row)
            previous = float(t)
            print(json.dumps(dict(event="accepted", method=kind, case=case, seed=seed, **row)), flush=True)
            # Preserve actual accepted networks and their active integration state.
            torch.save(dict(states=states, cv=cv.cpu(), previous_time=previous), out/"accepted_states.pt")
            save_progress()
        summary["complete"] = abs(previous-config["load_times"][-1]) < 1e-9
    except Exception as exc:
        summary["failure"] = str(exc)
        raise
    finally:
        save_progress(final=True)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/history_creep/horseshoe.json")
    parser.add_argument("--case", default="m2_r010")
    parser.add_argument("--method", choices=("fe", "condensed", "mixed"), required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--angular", type=int)
    parser.add_argument("--radial", type=int)
    parser.add_argument("--dt", type=float)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--stop-time", type=float)
    parser.add_argument("--learning-rate", type=float)
    parser.add_argument("--loss-scale", type=float)
    parser.add_argument("--resume-from")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    config = json.loads((ROOT/args.config).read_text(encoding="utf-8"))
    if args.learning_rate is not None:
        config["learning_rate"] = args.learning_rate
    if args.loss_scale is not None:
        config["loss_scale"] = args.loss_scale
    spec = dict(config["fe_mesh" if args.method == "fe" else "train_mesh"])
    if args.angular is not None:
        spec["angular"] = args.angular
    if args.radial is not None:
        spec["radial"] = args.radial
    run(config, args.case, args.method, args.seed, spec, args.dt or config["dt"],
        ROOT/args.out, args.device, args.stop_time, ROOT/args.resume_from if args.resume_from else None)


if __name__ == "__main__":
    main()
