"""Summarize measured/predicted shapes and loading jumps from saved histories."""
import csv
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    config = json.loads((ROOT/"config/history_creep/isochoric_laboratory.json").read_text())
    folder = ROOT/config["output"]
    summary = {"shape_definition": "Early fraction is the increment at one quarter of the sampled hold window divided by its endpoint increment; late rate is the secant over the latter half-window. Both use linear interpolation of saved samples.",
               "percentage_error_definition": "100 times the sum of absolute hold-increment errors divided by the sum of absolute measured hold increments. Use the same stages, confinement split and exclusion of the initial hold reference sample as the fitted objective.",
               "jump_definition": "Current first recorded strain minus the last preceding-stage sample at or before24h, for both measured and predicted values. This apparent jump is not an independently observed instantaneous elastic tangent.",
               "absolute_strain_scope": "Absolute predicted engineering strains follow each case's explicit gauge assumption; no specimen or stage offsets are fitted. The source gauge and area conventions remain unspecified.",
               "cases": []}
    for case in config["cases"]:
        fit = json.loads((folder/case["name"]/"fit.json").read_text())
        with (folder/case["name"]/"predictions.csv").open() as stream:
            rows = [{k: float(v) for k, v in r.items()} for r in csv.DictReader(stream)]
        groups = {}
        for r in rows:
            groups.setdefault((int(r["cp_MPa"]), int(r["stage"])), []).append(r)
        result = {k: fit[k] for k in ("case", "material", "bound_activity", "calibration_rmse", "held_confinement_rmse")}
        result.update(curves=[], apparent_jumps=[], stage3_over_stage2=[])
        for split, confinements in (("calibration", (15, 25)), ("held_confinement", (20,))):
            selected = [r for (cp, stage), rr in groups.items()
                        if cp in confinements and stage in (2, 3) for r in rr[1:]]
            measured = np.array([r["measured_increment"] for r in selected])
            predicted = np.array([r["increment"] for r in selected])
            result[split+"_error_percent"] = float(100*np.abs(predicted-measured).sum()/np.abs(measured).sum())
        for (cp, stage), rr in groups.items():
            t = np.array([r["time_h"] for r in rr])
            measured = np.array([r["measured_increment"] for r in rr])
            predicted = np.array([r["increment"] for r in rr])
            absolute_error = np.array([r["engineering_strain"]-r["measured_strain"] for r in rr])
            entry = dict(cp_MPa=cp, stage=stage, measured_endpoint=float(measured[-1]),
                         predicted_endpoint=float(predicted[-1]),
                         absolute_strain_rmse=float(np.sqrt(np.mean(absolute_error**2))))
            if stage in (2,3):
                for label, values in (("measured",measured),("predicted",predicted)):
                    quarter = t[0]+.25*(t[-1]-t[0])
                    middle = .5*(t[-1]+t[0])
                    entry[label+"_early_fraction"] = float(np.interp(quarter,t,values)/values[-1])
                    entry[label+"_late_rate_per_h"] = float((values[-1]-np.interp(middle,t,values))/(t[-1]-middle))
            result["curves"].append(entry)
            if stage > 1:
                previous = [r for r in groups[(cp,stage-1)] if r["time_h"]<=24][-1]
                result["apparent_jumps"].append(dict(cp_MPa=cp, stage=stage,
                    prior_sample_time_h=previous["time_h"], current_sample_time_h=rr[0]["time_h"],
                    measured=rr[0]["measured_strain"]-previous["measured_strain"],
                    predicted=rr[0]["engineering_strain"]-previous["engineering_strain"]))
        for cp in (15,20,25):
            first, second = groups[(cp,2)][-1], groups[(cp,3)][-1]
            result["stage3_over_stage2"].append(dict(cp_MPa=cp,
                measured=second["measured_increment"]/first["measured_increment"],
                predicted=second["increment"]/first["increment"]))
        result["cross_confinement_15_stage3_over_25_stage2"] = {
            "measured": groups[(15,3)][-1]["measured_increment"]/groups[(25,2)][-1]["measured_increment"],
            "predicted": groups[(15,3)][-1]["increment"]/groups[(25,2)][-1]["increment"]}
        summary["cases"].append(result)
        m = fit["material"]
        print(f"{case['name']:24s} calibration={result['calibration_error_percent']:.4g}% held={result['held_confinement_error_percent']:.4g}% "
              f"eta={m['eta']:.6g} qstar={m['qstar']} a={m['pressure_a']:.6g}")
    (folder/"comparison.json").write_text(json.dumps(summary, indent=2, allow_nan=False)+"\n",
                                          encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
