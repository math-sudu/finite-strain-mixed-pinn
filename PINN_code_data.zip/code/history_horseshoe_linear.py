"""Strain and elasticity helpers used by the field solver."""
import torch

def strain(u, quad):
    grad = torch.einsum("qai,qaj->qij", u[quad.conn], quad.grad)
    eps = u.new_zeros((len(quad.x), 3, 3))
    eps[:, :2, :2] = .5*(grad+grad.transpose(-1, -2))
    trace = eps.diagonal(dim1=-2, dim2=-1).sum(-1)
    dev = eps-trace[:, None, None]*torch.eye(3)/3
    return trace, dev


def linear_tensor(bulk, shear):
    eye = torch.eye(2)
    return (bulk-2*shear/3)*torch.einsum("ij,kl->ijkl", eye, eye)+shear*(
        torch.einsum("ik,jl->ijkl", eye, eye)+torch.einsum("il,jk->ijkl", eye, eye))
