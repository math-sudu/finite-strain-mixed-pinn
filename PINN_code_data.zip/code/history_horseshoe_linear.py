"""Matched M0 small-strain history and elapsed-time-modulus cavity models.

The same elastic bulk and two shear moduli are used. The history model uses
backward Euler at every physical step; the comparison evaluates the total load
against mu0 + mu1 exp(-t mu1/eta), with no hereditary stress. Neither uses neural
or finite-strain solution fields. The initial documented contour is the common
geometry for reporting displacements.
"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.sparse.linalg import spsolve
import torch

from history_isochoric import IsoMaterial
from history_horseshoe import make_mesh, report_grid, schedule, sparse_tangent, fe_fields
from mixed_reference_sampling import locate

ROOT = Path(__file__).resolve().parents[1]


def strain(u, quad):
    grad = torch.einsum("qai,qaj->qij", u[quad.conn], quad.grad)
    eps = u.new_zeros((len(quad.x), 3, 3))
    eps[:, :2, :2] = .5*(grad+grad.transpose(-1, -2))
    trace = eps.diagonal(dim1=-2, dim2=-1).sum(-1)
    dev = eps-trace[:, None, None]*torch.eye(3)/3
    return trace, dev


def linear_tensor(bulk, shear):
    eye = torch.eye(2)
    return (bulk-2*shear/3)*torch.einsum("ij,kl->ijkl", eye, eye)+shear*(
        torch.einsum("ik,jl->ijkl", eye, eye)+torch.einsum("il,jk->ijkl", eye, eye))


def run(config, kind, angular, radial, dt, out):
    fit = json.loads((ROOT/config["cases"]["m0_r010"]).read_text(encoding="utf-8"))
    m = IsoMaterial(**fit["material"])
    if m.qstar is not None:
        raise ValueError("This linear comparison is the constant-mobility M0 model")
    spec = dict(config["fe_mesh"], angular=angular, radial=radial)
    f0 = torch.eye(3)
    mesh = make_mesh(config, f0, spec)
    points, weights, nv = report_grid(config, f0)
    probe = locate(mesh, points)
    u = torch.zeros_like(mesh.nodes)
    history = torch.zeros((len(mesh.volume.x), 3, 3))
    devold = history.clone()
    history_probe = torch.zeros((len(points), 3, 3))
    devold_probe = history_probe.clone()
    times, pressures = schedule(config, dt)
    values, stresses, rows = [], [], []
    previous, start = 0., time.perf_counter()
    for t, pressure in zip(times, pressures):
        step = t-previous
        alpha = 1/(1+step*m.mu1/m.eta)
        shear = m.mu0+(alpha*m.mu1 if kind == "history" else m.mu1*np.exp(-t*m.mu1/m.eta))
        offset = alpha*(history-2*m.mu1*devold) if kind == "history" else torch.zeros_like(history)
        fw = f0.expand(len(mesh.boundary.x), 3, 3)
        r0 = mesh.weak(offset, fw, float(pressure-config["p0"]), config["p0"], f0, f0*0,
                        subtract_initial=False)
        tangent = linear_tensor(m.bulk, shear).expand(len(mesh.volume.x), 2, 2, 2, 2)
        matrix = sparse_tangent(mesh, tangent, 0., config["p0"])
        u[mesh.free] = torch.tensor(spsolve(matrix, -r0.flatten().numpy())).reshape(-1, 2)
        trace, dev = strain(u, mesh.volume)
        sigma = m.bulk*trace[:, None, None]*f0+2*shear*dev+offset
        residual = mesh.weak(sigma, fw, float(pressure-config["p0"]), config["p0"], f0, f0*0,
                             subtract_initial=False)
        if residual.abs().max() > 1e-9:
            raise RuntimeError("Linear equilibrium failed")
        history = alpha*(history+2*m.mu1*(dev-devold))
        devold = dev
        tracep, devp = strain(u, probe)
        history_probe = alpha*(history_probe+2*m.mu1*(devp-devold_probe))
        devold_probe = devp
        sigmap = m.bulk*tracep[:, None, None]*f0+2*m.mu0*devp+history_probe
        if kind == "elapsed_modulus":
            sigmap = m.bulk*tracep[:, None, None]*f0+2*shear*devp
        uq = fe_fields(u, probe, f0)[0]
        values.append(uq.numpy())
        stresses.append(sigmap.numpy())
        rows.append(dict(time=float(t), pressure=float(pressure),
            max_wall_displacement=float(uq[nv:].norm(dim=-1).max())))
        previous = t
    out.mkdir(parents=True, exist_ok=False)
    (out/"summary.json").write_text(json.dumps(dict(method=kind, case="m0_r010", configuration=config,
        mesh=spec, dt=dt, elapsed_s=time.perf_counter()-start, steps=rows), indent=2), encoding="utf-8")
    np.savez_compressed(out/"fields.npz", points=points.numpy(), weights=weights.numpy(), volume_count=nv,
        times=times, u=np.array(values), incremental_stress=np.array(stresses))
    print(json.dumps(dict(method=kind, dt=dt, elapsed_s=time.perf_counter()-start, final=rows[-1])))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/history_creep/horseshoe.json")
    parser.add_argument("--method", choices=("history", "elapsed_modulus"), required=True)
    parser.add_argument("--angular", type=int, default=48)
    parser.add_argument("--radial", type=int, default=12)
    parser.add_argument("--dt", type=float, default=3.)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    config = json.loads((ROOT/args.config).read_text(encoding="utf-8"))
    run(config, args.method, args.angular, args.radial, args.dt, ROOT/args.out)
