"""Calibrate selected physical inputs using field displacement prefixes.

Every objective evaluation retrains a neural equilibrium history from its own
initial material state. Only neural weights can warm-start a new evaluation.
Each fit excludes readings beyond its cutoff. Model development may already
have used those readings; the protocol records this distinction explicitly.
"""
import argparse
import contextlib
from concurrent.futures import ProcessPoolExecutor, as_completed
from copy import deepcopy
import csv
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit, logit
import torch
from threadpoolctl import threadpool_limits

from application_observations import forecast_from_last_reading, line_closure
from history_field import run, scenario_config

ROOT = Path(__file__).resolve().parents[1]


def encode(young, fraction, relaxation):
    return np.array([np.log(young), logit(fraction), np.log(relaxation)])


def decode(x):
    return dict(young=float(np.exp(x[0])), fraction=float(expit(x[1])),
                relaxation_day=float(np.exp(x[2])))


def observation_data(config, first, cutoff):
    """Filter before forming targets, reference zeros, counts or loss scales."""
    groups = {}
    with (ROOT/config["deformation_source"]).open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            day = float(row["elapsed_time_day"])+config["deformation_to_pressure_day"]
            if day <= cutoff:
                groups.setdefault(row["channel_id"], []).append(
                    (day, float(row["cumulative_deformation_mm"])))
    result = {}
    for channel, rows in groups.items():
        values = np.array(sorted(rows))
        t, y = values.T
        reference_day = t[0] if first is None else first
        if t[0] > reference_day or t[-1] < reference_day:
            raise ValueError(f"No observed reference-time bracket for {channel}")
        reference = np.interp(reference_day, t, y)
        select = t >= reference_day
        result[channel] = dict(time=t[select], value=y[select]-reference,
                               reference_day=float(reference_day))
    return result


class Parameters:
    """Only the explicitly selected physical parameters enter optimization."""
    def __init__(self, protocol):
        self.definitions = protocol.get("parameters") or {
            "young": dict(bounds=protocol["young_bounds_MPa"], initial=protocol["initial_young_MPa"],
                          transform="log", step=protocol["finite_difference_log_steps"][0], scale=.2),
            "fraction": dict(bounds=protocol["fraction_bounds"], initial=protocol["initial_fraction"],
                             transform="logit", step=protocol["finite_difference_log_steps"][1]),
            "relaxation_day": dict(bounds=protocol["relaxation_bounds_day"], initial=protocol["initial_relaxation_day"],
                                   transform="log", step=protocol["finite_difference_log_steps"][2])}
        forward = {"log":np.log, "logit":logit, "linear":lambda x:x}
        self.lower = np.array([forward[d["transform"]](d["bounds"][0]) for d in self.definitions.values()])
        self.upper = np.array([forward[d["transform"]](d["bounds"][1]) for d in self.definitions.values()])
        self.initial = np.array([forward[d["transform"]](d["initial"]) for d in self.definitions.values()])
        self.steps = np.array([d["step"] for d in self.definitions.values()])
        self.scales = np.array([d.get("scale", 1.) for d in self.definitions.values()])

    def decode(self, x):
        inverse = {"log":np.exp, "logit":expit, "linear":lambda x:x}
        return {key:float(inverse[d["transform"]](v)) for (key,d),v in zip(self.definitions.items(), x)}

    def apply(self, base, values):
        c = deepcopy(base)
        for key, value in values.items():
            path = self.definitions[key].get("path", key).split(".")
            target = c
            for part in path[:-1]:
                target = target[part]
            target[path[-1]] = value
        return c


def predict(fields, query, reference):
    query = np.atleast_1d(query)
    times, points = fields["times"], fields["points"][:7]
    flat = fields["u"][:, :7].reshape(len(times), -1)
    uq = np.stack([np.interp(query, times, col) for col in flat.T], -1).reshape(-1, 7, 2)
    uref = np.array([np.interp(reference, times, col) for col in flat.T]).reshape(7, 2)
    settlement = -(uq[:, 0, 1]-uref[0, 1])
    closure = line_closure((points+uref)[1:].reshape(3, 2, 2),
                           (points+uq)[:, 1:].reshape(-1, 3, 2, 2))
    return 1000*np.concatenate((settlement[:, None], closure), -1)


def read_fields(directory):
    with np.load(Path(directory)/"fields.npz") as source:
        return dict(source)


def solve_candidate(config, target, warm):
    torch.set_num_threads(1)
    with threadpool_limits(limits=1), target.with_suffix(".log").open("w", encoding="utf-8") as log, contextlib.redirect_stdout(log):
        if config.get("retain_core"):
            from history_field_core import run_core
            run_core(config, config["train_mesh"], config["dt"], target,
                     seed=config.get("network_seed", 0))
        else:
            run(config, "condensed", config["train_mesh"], config["dt"], target, initial_networks=warm)


def fit(protocol_path, out, initial_networks, resume=False, workers=None):
    protocol = json.loads(Path(protocol_path).read_text(encoding="utf-8"))
    base = scenario_config(json.loads((ROOT/protocol["base_config"]).read_text(encoding="utf-8")), "baseline")
    base.update(protocol.get("field_overrides", {}))
    first, cutoff = protocol["calibration_interval_day"]
    last = protocol["test_interval_day"][1]
    if protocol["test_interval_day"][0] != cutoff or base["comparison_interval"] != [first, last]:
        raise ValueError("Calibration and test must partition the configured comparison interval")
    data = observation_data(base, None if protocol.get("reference_mode") == "first_reading" else first, cutoff)
    channels = protocol["channels"]
    scales = protocol.get("channel_scales_mm") or {k:float(np.max(np.abs(data[k]["value"]))) for k in channels}
    if any(v <= 0 for v in scales.values()):
        raise ValueError("Every calibration channel must contain a nonzero increment")
    if resume:
        if json.loads((out/"protocol.json").read_text(encoding="utf-8")) != protocol:
            raise ValueError("Cannot resume with a different calibration protocol")
    else:
        out.mkdir(parents=True, exist_ok=False)
        (out/"protocol.json").write_text(json.dumps(protocol, indent=2)+"\n", encoding="utf-8")
        np.savez(out/"calibration_targets.npz", **{
            k+"_"+field:value for k in channels for field,value in data[k].items()})
    parameters = Parameters(protocol)
    lower, upper, x0 = parameters.lower, parameters.upper, parameters.initial
    records = json.loads((out/"evaluations.json").read_text()) if resume else []
    cache = {}
    started = time.perf_counter()
    previous_elapsed = max((r["elapsed_s"] for r in records), default=0.)

    def errors(fields):
        pieces, rmse = [], {}
        for i,k in enumerate(channels):
            difference = predict(fields, data[k]["time"], data[k]["reference_day"])[:, i]-data[k]["value"]
            pieces.append(difference/(scales[k]*np.sqrt(len(difference))))
            rmse[k] = float(np.sqrt(np.mean(difference**2)))
        return np.concatenate(pieces), rmse

    for row in records:
        cache[tuple(row["x"])] = errors(read_fields(out/row["run"]))[0]

    def job_config(x):
        c = dict(parameters.apply(base, parameters.decode(x)), scenario="early_data_calibration",
                 comparison_interval=[first, cutoff], end_day=cutoff,
                 extra_time_nodes=[cutoff], equilibrium_tolerance=protocol["equilibrium_tolerance"])
        c["role"] = "PINN physical-model calibration using the declared displacement prefix"
        c["rheology_source"] = "Effective field parameters fitted only to the declared prefix"
        c["scenario_basis"] = protocol["protocol"]
        c["young_source"] = protocol["young_bounds_source"]
        if c.get("retain_core"):
            # Core candidates solve from their own initial states and do not
            # use checkpoint warm starts; retain their observation histories.
            c["save_checkpoints"] = False
        return c

    def warm_path(x):
        if records:
            nearest = min(records, key=lambda row:np.linalg.norm(np.asarray(row["x"])-x))
            return out/nearest["run"]
        return initial_networks

    def collect(x, name):
        values, rmse = errors(read_fields(out/name))
        row = dict(run=name, x=x.tolist(), parameters=parameters.decode(x),
                   channel_rmse_mm=rmse, normalized_loss=float(values@values/len(channels)),
                   elapsed_s=previous_elapsed+time.perf_counter()-started)
        records.append(row)
        cache[tuple(x)] = values
        (out/"evaluations.json").write_text(json.dumps(records, indent=2)+"\n", encoding="utf-8")
        print(json.dumps(dict(event="parameter_evaluation_complete", **row)), flush=True)

    def evaluate_candidates(candidates):
        missing = [x for x in candidates if tuple(x) not in cache]
        index = max((int(row["run"].split("_")[-1]) for row in records), default=-1)+1
        jobs = [(x, f"evaluation_{index+i:03d}", warm_path(x)) for i,x in enumerate(missing)]
        for x,name,_ in jobs:
            print(json.dumps(dict(event="parameter_evaluation_start", run=name, **parameters.decode(x))), flush=True)
        if len(jobs) == 1:
            x,name,warm = jobs[0]
            solve_candidate(job_config(x), out/name, warm)
            collect(x,name)
        elif jobs:
            with ProcessPoolExecutor(max_workers=min(len(jobs), workers or protocol.get("workers", 3))) as pool:
                futures = {pool.submit(solve_candidate, job_config(x), out/name, warm):(x,name)
                           for x,name,warm in jobs}
                for future in as_completed(futures):
                    future.result()
                    x,name = futures[future]
                    collect(x,name)
        return [cache[tuple(x)] for x in candidates]

    def residual(x):
        return evaluate_candidates([x])[0]

    def jacobian(x):
        center = residual(x)
        candidates, stencils = [], []
        for i, step in enumerate(parameters.steps):
            if protocol.get("central_differences") and lower[i]+step <= x[i] <= upper[i]-step:
                start = len(candidates)
                for sign in (1., -1.):
                    perturbed = x.copy()
                    perturbed[i] += sign*step
                    candidates.append(perturbed)
                stencils.append((start, start+1, 2*step))
                continue
            delta = step if x[i]+step <= upper[i] else -step
            perturbed = x.copy()
            perturbed[i] += delta
            stencils.append((len(candidates), None, delta))
            candidates.append(perturbed)
        values = evaluate_candidates(candidates)
        return np.stack([(values[a]-(center if b is None else values[b]))/delta
                         for a,b,delta in stencils], -1)

    answer = least_squares(residual, x0, jac=jacobian, bounds=(lower, upper),
        x_scale=parameters.scales, ftol=protocol["optimizer_ftol"],
        xtol=protocol["optimizer_xtol"], gtol=protocol["optimizer_gtol"], verbose=2)
    selected = next(row for row in records if np.array_equal(row["x"], answer.x))
    frozen = dict(parameters=parameters.decode(answer.x), calibration_run=selected["run"],
        calibration_channel_scale_mm=scales, calibration_count={k:len(data[k]["time"]) for k in channels},
        calibration_reference_day={k:data[k]["reference_day"] for k in channels},
        optimizer_status=int(answer.status), optimizer_message=answer.message,
        optimality=float(answer.optimality), active_mask=answer.active_mask.tolist(),
        normalized_loss=selected["normalized_loss"],
        interpretation=protocol["protocol"])
    (out/"frozen_parameters.json").write_text(json.dumps(frozen, indent=2)+"\n", encoding="utf-8")
    if not answer.success:
        raise RuntimeError(f"Parameter calibration did not converge: {answer.message}")
    c = dict(parameters.apply(base, frozen["parameters"]), scenario="early_data_calibrated_forecast",
             extra_time_nodes=[cutoff], equilibrium_tolerance=protocol["equilibrium_tolerance"])
    c["role"] = "Frozen early-data calibration; later conditional prediction without displacement updates"
    c["scenario_basis"] = protocol["protocol"]
    c["rheology_source"] = "frozen_parameters.json: calibrated from early field displacement"
    c["young_source"] = protocol["young_bounds_source"]
    solve_candidate(c, out/"prediction", out/selected["run"])
    fields = read_fields(out/"prediction")
    full_data = observation_data(base, first, last)
    metrics, rows, forecasts = [], [], []
    for i,k in enumerate(channels):
        t, y = full_data[k]["time"], full_data[k]["value"]
        prediction = predict(fields, t, first)[:,i]
        forecast, anchor = forecast_from_last_reading(t, y, prediction, cutoff)
        later = t > cutoff
        forecasts.append(dict(channel=k,anchor_day=float(t[anchor]),
            count=int(later.sum()),rmse_mm=float(np.sqrt(np.mean((forecast[later]-y[later])**2))),
            observed_growth_mm=float(y[-1]-y[anchor]),
            predicted_growth_mm=float(prediction[-1]-prediction[anchor]),
            final_error_mm=float(forecast[-1]-y[-1])))
        for label, mask in [("calibration", t<=cutoff), ("test", t>cutoff)]:
            error = prediction[mask]-y[mask]
            metrics.append(dict(channel=k, split=label, count=int(mask.sum()),
                rmse_mm=float(np.sqrt(np.mean(error**2))), mae_mm=float(np.mean(np.abs(error))),
                mean_error_mm=float(np.mean(error)),
                last_time_day=float(t[mask][-1]), last_observed_increment_mm=float(y[mask][-1]),
                last_predicted_increment_mm=float(prediction[mask][-1])))
        rows.extend(dict(channel=k, time_day=float(tt), split="calibration" if tt<=cutoff else "test",
            observed_increment_mm=float(yy), predicted_increment_mm=float(pp)) for tt,yy,pp in zip(t,y,prediction))
    (out/"metrics.json").write_text(json.dumps(metrics, indent=2)+"\n", encoding="utf-8")
    (out/"forecast_metrics.json").write_text(json.dumps(forecasts, indent=2)+"\n", encoding="utf-8")
    if protocol.get("reference_mode") == "first_reading":
        registered = observation_data(base, None, last)
        registration_metrics, registration_rows = [], []
        for i,k in enumerate(channels):
            t, y = registered[k]["time"], registered[k]["value"]
            prediction = predict(fields, t, registered[k]["reference_day"])[:,i]
            for label, mask in [("calibration", t<=cutoff), ("test", t>cutoff)]:
                error = prediction[mask]-y[mask]
                registration_metrics.append(dict(channel=k, split=label,
                    reference_day=registered[k]["reference_day"], count=int(mask.sum()),
                    rmse_mm=float(np.sqrt(np.mean(error**2))), mean_error_mm=float(np.mean(error))))
            registration_rows.extend(dict(channel=k, time_day=float(tt),
                reference_day=registered[k]["reference_day"],
                split="calibration" if tt<=cutoff else "test",
                observed_increment_mm=float(yy), predicted_increment_mm=float(pp))
                for tt,yy,pp in zip(t,y,prediction))
        (out/"registration_metrics.json").write_text(json.dumps(registration_metrics, indent=2)+"\n")
        with (out/"registered_observations.csv").open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(registration_rows[0]))
            writer.writeheader(); writer.writerows(registration_rows)
    with (out/"predicted_observations.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps(dict(event="complete", frozen=frozen, metrics=metrics)), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", default="config/history_creep/field_calibration_horseshoe.json")
    parser.add_argument("--out", required=True)
    parser.add_argument("--initial-networks", help="Optional completed physics-only PINN history; FE histories are rejected")
    parser.add_argument("--resume", action="store_true", help="Reuse completed evaluations under the unchanged protocol")
    parser.add_argument("--workers", type=int, help="Override concurrent physical solves without changing the calibration protocol")
    parser.add_argument("--validation", help="After prediction, evaluate this forecast protocol into the run's validation directory")
    args = parser.parse_args()
    if args.validation:
        validation = json.loads((ROOT/args.validation).read_text(encoding="utf-8"))
        if (ROOT/validation["calibrated_run"]).resolve() != (ROOT/args.out).resolve():
            raise ValueError("The forecast protocol must refer to this calibration output")
    torch.set_num_threads(1)
    fit(ROOT/args.protocol, ROOT/args.out, ROOT/args.initial_networks if args.initial_networks else None,
        args.resume, args.workers)
    if args.validation:
        from summarize_history_field import summarize_validation
        summarize_validation(ROOT/args.validation, ROOT/args.out/"validation")
