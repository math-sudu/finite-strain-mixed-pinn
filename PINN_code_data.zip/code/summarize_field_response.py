"""Summarize cumulative field response at each instrument's actual reading times."""
import argparse
import csv
import json
from pathlib import Path


def summarize(run):
    run = Path(run)
    protocol = json.loads((run / "protocol.json").read_text(encoding="utf-8"))
    if protocol["reference_mode"] != "first_reading":
        raise ValueError("Cumulative response requires each instrument's first-reading reference")
    with (run / "registered_observations.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    result = []
    for channel in protocol["channels"]:
        readings = sorted((row for row in rows if row["channel"] == channel),
                          key=lambda row: float(row["time_day"]))
        item = {"channel": channel,
                "reference_day": float(readings[0]["reference_day"]),
                "last_evaluation_day": float(readings[-1]["time_day"]),
                "last_observed_mm": float(readings[-1]["observed_increment_mm"]),
                "last_predicted_mm": float(readings[-1]["predicted_increment_mm"])}
        for split, name in (("calibration", "calibration"), ("test", "later")):
            selected = [row for row in readings if row["split"] == split]
            measured = [float(row["observed_increment_mm"]) for row in selected]
            calculated = [float(row["predicted_increment_mm"]) for row in selected]
            item[name + "_count"] = len(selected)
            item[name + "_error_percent"] = (
                100 * sum(abs(a - b) for a, b in zip(calculated, measured))
                / sum(abs(value) for value in measured))
        result.append(item)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, help="Completed field-calibration directory")
    args = parser.parse_args()
    result = summarize(args.run)
    output = Path(args.run) / "cumulative_response.json"
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    for row in result:
        print(f"{row['channel']}: calibration {row['calibration_error_percent']:.1f}%, "
              f"later {row['later_error_percent']:.1f}%")
