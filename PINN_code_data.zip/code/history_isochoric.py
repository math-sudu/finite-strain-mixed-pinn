"""Compressible solid with isochoric RG history and invariant rate dependence.

M0 has constant mobility, M1 a sinh(q/q*)/q multiplier, and M2 also a
pressure multiplier. These are nested constitutive candidates, not identified
rock mechanisms. The backward differentiates both the trial isochoric metric
and explicit log(J) dependence. Only current-step first derivatives are exposed.
"""
from dataclasses import dataclass
import math

import torch

from history_material import Response, elastic, principal_law


@dataclass(frozen=True)
class IsoMaterial:
    bulk: float
    mu0: float
    mu1: float
    eta: float
    qstar: float | None = None
    pressure_a: float = 0.
    pressure_ref: float = 20.

    def __post_init__(self):
        if any(not math.isfinite(v) or v <= 0 for v in
               (self.bulk, self.mu0, self.mu1, self.eta, self.pressure_ref)):
            raise ValueError("Elastic moduli, viscosity and pressure scale must be positive")
        if self.qstar is not None and (not math.isfinite(self.qstar) or self.qstar <= 0):
            raise ValueError("Nonlinear stress scale must be positive")
        if not math.isfinite(self.pressure_a) or self.pressure_a < 0:
            raise ValueError("This candidate family restricts pressure_a to nonnegative values")
        if self.qstar is None and self.pressure_a != 0:
            raise ValueError("M0 is the constant-mobility member")

    @classmethod
    def from_elastic(cls, young, nu, fraction, eta, qstar=None, pressure_a=0.):
        if not -1 < nu < .5 or not 0 < fraction < 1:
            raise ValueError("Invalid elastic Poisson ratio or equilibrium shear fraction")
        shear = young/(2*(1+nu))
        return cls(young/(3*(1-2*nu)), fraction*shear, (1-fraction)*shear,
                   eta, qstar, pressure_a)


def mobility(s, logj, material):
    """Return g, dg/ds (three principal components), and dg/dlogJ."""
    pressure = -material.bulk*torch.sinh(logj)
    prefactor = torch.exp(-material.pressure_a*(pressure-material.pressure_ref)/material.pressure_ref)/(2*material.eta)
    if material.qstar is None:
        return prefactor, torch.zeros_like(s), torch.zeros_like(logj)
    z = 1.5*s.square().sum(-1)/material.qstar**2
    small = z < 1e-6
    x = torch.sqrt(torch.where(small, torch.ones_like(z), z))
    h = torch.where(small, 1+z/6+z.square()/120+z.pow(3)/5040, torch.sinh(x)/x)
    hz = torch.where(small, 1/6+z/60+z.square()/1680,
                      (x*torch.cosh(x)-torch.sinh(x))/(2*x.pow(3)))
    g = prefactor*h
    gs = prefactor[..., None]*hz[..., None]*3*s/material.qstar**2
    gj = g*material.pressure_a*material.bulk*torch.cosh(logj)/material.pressure_ref
    return g, gs, gj


def constrained_solve(jac, rhs):
    """Solve the deviatoric block while preserving the analytic volumetric mode."""
    basis = jac.new_tensor([[1/math.sqrt(2), 1/math.sqrt(6)],
                            [-1/math.sqrt(2), 1/math.sqrt(6)], [0., -2/math.sqrt(6)]])
    projected = basis.T @ jac @ basis
    return basis @ torch.linalg.solve(projected, basis.T @ rhs)+rhs.mean(-2, keepdim=True)


def local_update(etrial, logj, dt, material, tolerance=2e-12, max_iterations=60):
    if not math.isfinite(dt) or dt < 0:
        raise ValueError("Time increment must be finite and nonnegative")
    eye = torch.eye(3, dtype=etrial.dtype, device=etrial.device)

    def evaluate(e):
        s, _, h, _, _ = principal_law(e, material.mu1, 0.)
        g, gs, gj = mobility(s, logj, material)
        ge = torch.einsum("...i,...ij->...j", gs, h)
        jac = eye+dt*(g[..., None, None]*h+s[..., :, None]*ge[..., None, :])
        residual = e-etrial+dt*g[..., None]*s
        return residual, jac, s, h, gj

    # A linear-mobility predictor reduces stiffness without changing the law.
    pressure = -material.bulk*torch.sinh(logj)
    factor = torch.exp(-material.pressure_a*(pressure-material.pressure_ref)/material.pressure_ref)
    mean = etrial.mean(-1, keepdim=True)
    e = mean+(etrial-mean)/(1+dt*factor[..., None]*material.mu1/material.eta)
    # Reduce only the initial guess if the nonlinear trial flow is excessive.
    # The accepted root and constitutive law are not capped or linearized.
    if material.qstar is not None and dt > 0:
        scale = (etrial-mean).abs().amax(-1)
        for _ in range(60):
            stress = principal_law(e, material.mu1, 0.)[0]
            flow = dt*mobility(stress, logj, material)[0][..., None]*stress
            excessive = flow.abs().amax(-1) > scale
            if not bool(excessive.any()):
                break
            e = mean+(e-mean)*torch.where(excessive, .5, 1.)[..., None]
        else:
            raise RuntimeError("Could not initialize the nonlinear local solve")
    for _ in range(max_iterations):
        r, jac, s, h, gj = evaluate(e)
        if not bool(torch.isfinite(r).all()):
            raise RuntimeError("Nonfinite local flow; reduce the trial deformation or time increment")
        if float(r.abs().max()) <= tolerance:
            return e, s, h, jac, gj
        delta = constrained_solve(jac, r[..., None]).squeeze(-1)
        norm = r.abs().amax(-1)
        step = torch.ones_like(norm)
        for _ in range(30):
            candidate = e-step[..., None]*delta
            rr = evaluate(candidate)[0].abs().amax(-1)
            good = (rr <= norm) | (norm <= tolerance)
            if bool(good.all()):
                e = candidate
                break
            step = torch.where(good, step, step/2)
        else:
            raise RuntimeError("Isochoric local line search failed")
    raise RuntimeError("Isochoric local Newton did not converge")


class _IsoBranch(torch.autograd.Function):
    @staticmethod
    def forward(ctx, barred_trial, logj, dt, material):
        values, q = torch.linalg.eigh(barred_trial)
        if bool((values <= 0).any()):
            raise ValueError("Trial metric must be positive definite")
        e, s, h, jac, gj = local_update(.5*values.log(), logj, dt, material)
        inv_action = constrained_solve(jac, torch.eye(3, device=q.device, dtype=q.dtype).expand_as(jac))
        derivative = (h @ inv_action)/(2*values[..., None, :])
        pressure_derivative = -torch.einsum("...ij,...j->...i", h,
            constrained_solve(jac, (dt*gj[..., None]*s)[..., None]).squeeze(-1))
        gap = values[..., :, None]-values[..., None, :]
        close = gap.abs() <= 1e-7*values.abs().amax(-1)[..., None, None]
        diagonal = derivative.diagonal(dim1=-2, dim2=-1)
        limit = .5*(diagonal[..., :, None]+diagonal[..., None, :]-derivative-derivative.transpose(-1,-2))
        divided = torch.where(close, limit,
            (s[..., :, None]-s[..., None, :])/torch.where(close, torch.ones_like(gap), gap))
        divided -= torch.diag_embed(divided.diagonal(dim1=-2, dim2=-1))
        ctx.save_for_backward(q, derivative, divided, pressure_derivative)
        stress = (q*s[..., None, :]) @ q.transpose(-1,-2)
        barred = (q*torch.exp(2*e)[..., None, :]) @ q.transpose(-1,-2)
        ctx.mark_non_differentiable(barred)
        return stress, barred

    @staticmethod
    @torch.autograd.function.once_differentiable
    def backward(ctx, gradient, ignored):
        q, derivative, divided, pressure_derivative = ctx.saved_tensors
        g = q.transpose(-1,-2) @ gradient @ q
        g = .5*(g+g.transpose(-1,-2))
        gd = g.diagonal(dim1=-2, dim2=-1)
        diag = (gd.unsqueeze(-2) @ derivative).squeeze(-2)
        metric_gradient = q @ (divided*g+torch.diag_embed(diag)) @ q.transpose(-1,-2)
        logj_gradient = (gd*pressure_derivative).sum(-1)
        return metric_gradient, logj_gradient, None, None


def update(f, cv_old, dt, material):
    if f.shape[-2:] != (3,3) or cv_old.shape != f.shape or cv_old.requires_grad:
        raise ValueError("Expected matching 3D F and fixed Cv history")
    j = torch.linalg.det(f)
    if not bool(torch.isfinite(j).all()) or bool((j <= 0).any()):
        raise ValueError("F must preserve orientation")
    if float(torch.linalg.slogdet(cv_old)[1].abs().max()) > 1e-7:
        raise ValueError("Isochoric history requires det(Cv)=1; use its compatible initial state")
    logj = j.log()
    trial = f @ torch.linalg.solve(cv_old, f.transpose(-1,-2))
    s, barred = _IsoBranch.apply(trial*j[...,None,None].pow(-2/3), logj, dt, material)
    tau0, w0 = elastic(f @ f.transpose(-1,-2), material.mu0, material.bulk)
    tau = tau0+s
    piola = torch.linalg.solve(f, tau.transpose(-1,-2)).transpose(-1,-2)
    with torch.no_grad():
        be = barred*j[...,None,None].pow(2/3)
        cv = f.transpose(-1,-2) @ torch.linalg.solve(be, f)
        cv = .5*(cv+cv.transpose(-1,-2))
        w1 = material.mu1/2*(barred.diagonal(dim1=-2,dim2=-1).sum(-1)-3)
        principal_s = torch.linalg.eigvalsh(s)
        g = mobility(principal_s, logj, material)[0]
        dissipation = g*s.square().sum((-2,-1))
    return Response(piola, tau/j[...,None,None], tau, cv, w0+w1, dissipation)
