"""Run complete specimen or spatial histories from initial states."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def commands(group):
    runs = []
    def add(script, *arguments):
        runs.append([sys.executable, "-B", "code/" + script + ".py", *map(str, arguments)])

    if group == "laboratory":
        add("fit_isochoric_triaxial")
        add("summarize_isochoric_laboratory")
    elif group == "horseshoe":
        base = "results/history_creep/horseshoe/"
        def solve(case, method, name, *options):
            add("history_horseshoe", "--case", case, "--method", method,
                "--out", base + name, *options)
        for case, resolutions in [
            ("m2_r010", [(24,6,6), (48,12,6), (72,18,6), (48,12,3), (48,12,1.5)]),
            ("m2_r045", [(48,12,6), (72,18,6), (48,12,3)]),
            ("m0_r010", [(48,12,6), (48,12,3)])]:
            for angular, radial, dt in resolutions:
                solve(case, "fe", f"{case}_fe_a{angular}_r{radial}_dt{dt:g}",
                    "--angular", angular, "--radial", radial, "--dt", dt)
        paired = []
        for method in ("condensed", "mixed"):
            for seed in (0, 1):
                name = f"m2_r010_{method}_s{seed}"
                paired.append(base + name)
                solve("m2_r010", method, name, "--seed", seed)
        prefixes = ["m2_r045_condensed_s0_t6", "m2_r045_condensed_s0_t48",
                    "m2_r045_condensed_s0_t54", "m2_r045_condensed_s0"]
        solve("m2_r045", "condensed", prefixes[0], "--stop-time", 6)
        solve("m2_r045", "condensed", prefixes[1], "--resume-from", base + prefixes[0],
              "--learning-rate", .1, "--stop-time", 48)
        solve("m2_r045", "condensed", prefixes[2], "--resume-from", base + prefixes[1],
              "--learning-rate", 1, "--stop-time", 54)
        solve("m2_r045", "condensed", prefixes[3], "--resume-from", base + prefixes[2],
              "--learning-rate", 1, "--loss-scale", 1000)
        add("compare_history_horseshoe", "--reference", base + "m2_r010_fe_a72_r18_dt6",
            "--runs", *paired, base + "m2_r010_fe_a24_r6_dt6", base + "m2_r010_fe_a48_r12_dt6",
            "--out", base + "m2_r010_comparison.json")
        add("compare_history_horseshoe", "--reference", base + "m2_r045_fe_a72_r18_dt6",
            "--runs", base + prefixes[3], base + "m2_r045_fe_a48_r12_dt6",
            "--out", base + "m2_r045_comparison.json")
        add("compare_history_horseshoe", "--reference", base + "m2_r010_fe_a48_r12_dt1.5",
            "--runs", base + "m2_r010_fe_a48_r12_dt3", base + "m2_r010_fe_a48_r12_dt6",
            "--out", base + "m2_r010_time_comparison.json")
        for method, dt, name in [("history", 3, "linear_history_dt3"),
                                  ("history", 1.5, "linear_history_dt1.5"),
                                  ("elapsed_modulus", 3, "elapsed_modulus_dt3")]:
            add("history_horseshoe_linear", "--method", method, "--dt", dt,
                "--out", base + "m0_r010_" + name)
        add("compare_history_horseshoe", "--m0-models", base + "m0_r010_fe_a48_r12_dt3",
            base + "m0_r010_linear_history_dt3", base + "m0_r010_elapsed_modulus_dt3",
            "--linear-refined", base + "m0_r010_linear_history_dt1.5",
            "--out", base + "m0_physical_comparison.json")
    elif group == "field":
        base = "results/history_creep/field/"
        add("calibrate_history_field", "--protocol", "config/history_creep/field_calibration_horseshoe.json",
            "--out", base + "pinn_horseshoe", "--validation", "config/history_creep/field_validation_horseshoe.json")
    elif group == "field-validation":
        add("summarize_history_field", "--validation", "config/history_creep/field_validation_horseshoe.json",
            "--out", "results/history_creep/field/pinn_horseshoe/validation")
    else:
        raise ValueError(group)
    return runs


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("group", choices=("laboratory", "horseshoe", "field", "field-validation"))
    parser.add_argument("--list", action="store_true", help="Print commands without executing them")
    args = parser.parse_args()
    for command in commands(args.group):
        print(subprocess.list2cmdline(command), flush=True)
        if not args.list:
            subprocess.run(command, cwd=ROOT, check=True)
