"""Run complete specimen or spatial histories from initial states."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def commands(group):
    runs = []
    def add(script, *arguments):
        runs.append([sys.executable, "-B", "code/" + script + ".py", *map(str, arguments)])

    if group == "laboratory":
        add("fit_isochoric_triaxial", "--case", "m2_r010")
    elif group == "horseshoe":
        base = "results/history_creep/horseshoe/"
        def solve(case, method, name, *options):
            add("history_horseshoe", "--case", case, "--method", method,
                "--out", base + name, *options)
        for angular, radial, dt in [(24,6,6), (48,12,6), (72,18,6), (48,12,3), (48,12,1.5)]:
            solve("m2_r010", "fe", f"m2_r010_fe_a{angular}_r{radial}_dt{dt:g}",
                "--angular", angular, "--radial", radial, "--dt", dt)
        paired = []
        for method in ("condensed", "mixed"):
            for seed in (0, 1):
                name = f"m2_r010_{method}_s{seed}"
                paired.append(base + name)
                solve("m2_r010", method, name, "--seed", seed)
        add("compare_history_horseshoe", "--reference", base + "m2_r010_fe_a72_r18_dt6",
            "--runs", *paired, base + "m2_r010_fe_a24_r6_dt6", base + "m2_r010_fe_a48_r12_dt6",
            "--out", base + "m2_r010_comparison.json")
        add("compare_history_horseshoe", "--reference", base + "m2_r010_fe_a48_r12_dt1.5",
            "--runs", base + "m2_r010_fe_a48_r12_dt3", base + "m2_r010_fe_a48_r12_dt6",
            "--out", base + "m2_r010_time_comparison.json")
    elif group == "field":
        base = "results/history_creep/field/"
        add("calibrate_history_field", "--protocol", "config/history_creep/field_calibration_horseshoe.json",
            "--out", base + "pinn_horseshoe")
        add("summarize_field_response", "--run", base + "pinn_horseshoe")
    elif group == "field-response":
        add("summarize_field_response", "--run", "results/history_creep/field/pinn_horseshoe")
    else:
        raise ValueError(group)
    return runs


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("group", choices=("laboratory", "horseshoe", "field", "field-response"))
    parser.add_argument("--list", action="store_true", help="Print commands without executing them")
    args = parser.parse_args()
    for command in commands(args.group):
        print(subprocess.list2cmdline(command), flush=True)
        if not args.list:
            subprocess.run(command, cwd=ROOT, check=True)
