"""Render field-led manuscript figures from frozen and reconciled NumPy evidence.

python -B figures/pinn_mechanism_endpoints_01/render.py [figure_id ...]
All numerical sources are checked by their existing provenance hashes.
"""
from __future__ import annotations
import os
for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, LogNorm, Normalize
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, Rectangle

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
from tools import origin_figures as fs

SPEC = json.loads((OUT / "figure_spec.json").read_text(encoding="utf-8"))
L = json.loads((OUT / "labels.json").read_text(encoding="utf-8"))
P = [.7125, .7000, .6875, .6750]
NV, NA, NR = 70656, 736, 96
FONT = 7.5


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def csv_rows(name):
    with (OUT / name).open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for key, value in row.items():
            try:
                row[key] = float(value)
            except ValueError:
                pass
    return rows


def setup(figure_id):
    spec = next(s for s in SPEC["figures"] if s["id"] == figure_id)
    fig = fs.figure(*spec["size_mm"])
    plt.rcParams.update({"font.size": FONT, "axes.labelsize": FONT, "axes.titlesize": FONT,
                         "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
                         "lines.linewidth": .95, "axes.titlepad": 4,
                         "xtick.major.size": 3, "ytick.major.size": 3,
                         "xtick.minor.size": 1.5, "ytick.minor.size": 1.5})
    return fig


def axes(fig, rect, title, xlabel=None, ylabel=None):
    ax = fig.add_axes(rect)
    fs.style_axes(ax)
    ax.set_title(title, loc="left", fontsize=FONT)
    if xlabel:
        ax.set_xlabel(xlabel, labelpad=2)
    if ylabel:
        ax.set_ylabel(ylabel, labelpad=2)
    return ax


def edges(values, low, high):
    return np.r_[low, (values[:-1] + values[1:]) / 2, high]


def knee_grid(data, knee):
    idx = np.flatnonzero(data["angular_arc_index"] == knee)
    length = data["wall_weights_m"][idx].sum()
    frac = data["arc_fraction"][NV + idx]
    s = (frac if knee == 2 else 1 - frac) * length
    order = np.argsort(s)
    idx, s = idx[order], s[order]
    depth = data["radial_distances_natural_m"]
    de = edges(depth, 0, 1 / data["f0"][0, 0])
    return idx, s, edges(s, 0, length), depth, de


def bar(fig, meshes, rect, label, ticks=None, log=False):
    cax = fig.add_axes(rect)
    cb = fig.colorbar(meshes[0], cax=cax, orientation="horizontal", ticks=ticks)
    cb.ax.tick_params(labelsize=7, pad=2, length=2)
    cb.set_label(label, fontsize=FONT, labelpad=2)
    for mesh in meshes:
        mesh.colorbar = cb
    if log:
        cb.ax.minorticks_off()
        cb.set_ticklabels([f"1e{int(np.log10(t))}" for t in ticks])
    return cb


def field_cmap(signed=False, reverse=False):
    """Quantize colour only; preserve the field values and shared physical limits."""
    policy = SPEC["color_policy"]
    if signed:
        cmap = LinearSegmentedColormap.from_list(
            "signed_multihue", policy["signed_stops"], N=policy["bands"])
    else:
        cmap = plt.get_cmap(policy["spectrum"]).resampled(policy["bands"])
    if reverse:
        cmap = cmap.reversed()
    cmap.set_bad("#eeeeee")
    return cmap


def plastic_cmap():
    cmap = field_cmap()
    cmap.set_bad("#eeeeee")
    cmap.set_under("#eeeeee")
    return cmap


def architecture(data, rows, profiles):
    """Adapt the shared editable reference to the implemented mixed-field graph."""
    from tools import architecture_primitives as ref
    # Retain the template's vector primitives and route grammar, with the
    # project's blue/red field coding and no DDCM convolution operations.
    ref.GREEN, ref.YELLOW = "#79a9bd", "#edcd76"
    fig = setup("architecture")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, 134), ylim=(0, 166), aspect="equal")
    ax.set_axis_off()

    def text(x, y, label, gid, **kw):
        artist = ax.text(x, y, label, ha=kw.pop("ha", "center"), va="center",
                         fontsize=kw.pop("fontsize", FONT), linespacing=1.22,
                         zorder=8, **kw)
        artist.set_gid(gid)

    def box(x, y, w, h, label, gid, color=fs.BLACK, fill="white", dashed=False):
        patch = Rectangle((x, y), w, h, ec=color, fc=fill, lw=.65,
                          linestyle=(0, (3, 2)) if dashed else "-", zorder=3)
        patch.set_gid(gid)
        ax.add_patch(patch)
        if label:
            text(x + w / 2, y + h / 2, label, gid + "-label")

    def arrow(points, gid, color=fs.BLACK, dashed=False, **kw):
        ref.arrow(ax, points, gid=gid, color=color, dashed=dashed, **kw)

    def stack(x, y, gid, colors, size=(9, 7), shape=(3, 3)):
        return ref.stack(ax, (x, y), size, shape, colors, gid=gid, offset=(.8, -.8))

    blue = ["#e5d7ef", "#b7dce7", "#82b7d0"]
    red = ["#ece1bd", "#e8bdad", "#c9857a"]
    text(67, 161, L["arch_heading"], "architecture-title", fontsize=9)
    text(36, 154, L["arch_trunk"], "trunk-caption")
    layers = [(9, [135, 142], None)]
    layers += [(x, [127, 134, 141, 148], None) for x in [23, 32, 41, 50]]
    ref.network(ax, layers, gid="shared-network", radius=1.65)
    # Two input coordinates are distinguished from the hidden neurons.
    for i, name in enumerate([r"$z_2$", r"$z_1$"]):
        ax.findobj(match=lambda a: a.get_gid() == f"shared-network-node-0-{i}")[0].set_facecolor(ref.YELLOW)
        text(9, [135, 142][i], name, f"input-coordinate-{i}", fontsize=7)
    text(8, 149, r"$Z/L_*$", "normalized-input")
    arrow([(52, 137.5), (63, 137.5)], "trunk-to-head")
    ref.grid(ax, (64, 127), (4, 21), (1, 10), "#e3be75", gid="linear-ten-output-head",
             accents=[(0, 8, 1, 2, "#a9d5e2"), (0, 4, 1, 4, "#c7add6")])
    text(66, 153, L["arch_head"], "head-caption")
    arrow([(9, 132.5), (9, 119), (66, 119), (66, 126)], "direct-feature-skip")
    text(36, 115.5, L["arch_features"], "direct-features")
    text(36, 110.5, L["arch_coordinates"], "coordinate-evaluations", fontsize=7)
    for x in [23, 32, 41, 50]:
        text(x, 123, "64", f"hidden-width-{x}", fontsize=7)

    stack(86, 145, "displacement-output", blue[:2], size=(9, 6), shape=(4, 3))
    stack(86, 131, "wall-stress-output", ["#f2e5c5", "#d8c1e4", *red[1:]], size=(9, 6), shape=(4, 3))
    stack(111, 131, "outer-stress-output", ["#f2e5c5", "#d8c1e4", *red[1:]], size=(9, 6), shape=(4, 3))
    text(112, 149, r"$v_\theta(Y_n)$: 2", "displacement-output-caption", color=fs.BLUE)
    text(93, 141, r"$h^w_\theta(X)$: 4", "wall-stress-output-caption", color=fs.RED)
    text(118, 141, r"$h^o_\theta(X)$: 4", "outer-stress-output-caption", color=fs.RED)
    arrow([(68.5, 146), (78, 146), (78, 148), (85, 148)], "head-to-displacement", fs.BLUE)
    arrow([(68.5, 137), (78, 137), (78, 134), (85, 134)], "head-to-wall-stress", fs.RED)
    arrow([(68.5, 130), (103, 130), (103, 134), (110, 134)], "head-to-outer-stress", fs.RED)

    box(5, 87, 58, 18, L["arch_complete"], "compatible-displacement", fs.BLUE, "#f5f8fb")
    box(73, 87, 57, 18, L["arch_projection"], "current-traction-projection", fs.RED, "#fcf7f4")
    arrow([(97, 147), (131, 147), (131, 108), (34, 108), (34, 105.5)], "raw-to-complete-displacement", fs.BLUE)
    arrow([(94, 127.5), (94, 112), (104, 112), (104, 105.5)], "wall-head-to-blend", fs.RED)
    arrow([(119, 127.5), (119, 112), (104, 112)], "outer-head-to-blend", fs.RED, tip=False)
    stack(48, 77, "compatible-gradient", blue[:2])
    text(39, 81, r"$F$", "gradient-caption", color=fs.BLUE)
    arrow([(34, 87), (34, 84.5), (53, 84.5), (53, 84)], "displacement-gradient", fs.BLUE)
    text(91, 81, L["arch_normal"], "candidate-normal", color=fs.BLUE)
    arrow([(59, 80), (69, 80), (69, 96), (72.5, 96)], "gradient-to-current-normal", fs.BLUE)

    box(7, 52, 22, 25, None, "accepted-parent", dashed=True)
    stack(12, 66, "accepted-parent-state", ["#e4d9b6", "#a6b897"], size=(8, 7))
    text(18, 58.5, L["arch_fixed"], "accepted-parent-caption", fontsize=7)
    text(18, 80.5, L["arch_state"], "accepted-parent-quantities", fontsize=7)
    arrow([(6.5, 71), (5, 71), (5, 85), (15, 85), (15, 86.5)], "parent-to-complete-field", dashed=True)
    box(41, 57, 31, 13, L["arch_return"], "constitutive-return", fs.BLUE)
    arrow([(53, 75.5), (53, 70.5)], "gradient-to-return", fs.BLUE)
    arrow([(29.5, 65), (40.5, 65)], "committed-history-to-return", dashed=True)
    stack(82, 61, "returned-stress", blue)
    stack(111, 61, "network-stress", red)
    text(88, 73, r"$\sigma^{R}$", "returned-stress-caption", color=fs.BLUE, fontsize=9)
    text(117, 73, r"$\sigma^{N}$", "network-stress-caption", color=fs.RED, fontsize=9)
    arrow([(72.5, 64), (81, 64)], "return-to-stress", fs.BLUE)
    arrow([(117, 87), (117, 77)], "projection-to-stress", fs.RED)

    text(96, 45, L["arch_physics"], "physical-operations", fontsize=7)
    arrow([(88, 58.5), (88, 49)], "returned-stress-to-physics", fs.BLUE)
    arrow([(117, 58.5), (117, 49)], "network-stress-to-physics", fs.RED)
    stack(80, 34, "network-work-residuals", red[1:], size=(2, 6), shape=(1, 5))
    stack(86, 34, "returned-work-residuals", blue[1:], size=(2, 6), shape=(1, 5))
    stack(111, 34, "mixed-consistency", ["#e6d4ba", "#c1abd3"], size=(7, 6))
    arrow([(84, 42), (84, 40.5)], "physics-to-work")
    arrow([(115, 42), (115, 40.5)], "physics-to-consistency")
    text(85, 27, L["arch_work"], "work-residual-caption", fontsize=7)
    text(115, 27, L["arch_consistency"], "mixed-consistency-caption", fontsize=7)
    arrow([(109, 37), (94, 37), (94, 21.5), (68, 21.5), (68, 32)], "consistency-to-objective")
    arrow([(79, 37), (70, 37)], "work-to-objective")
    ref.brace(ax, 67, 31, 42, gid="objective-branches", opening="right", depth=1.3)
    arrow([(64.5, 36.5), (54, 36.5)], "residuals-to-objective")
    node = Circle((49, 36.5), 4.1, facecolor="#edcd76", edgecolor=fs.BLACK, lw=.65, zorder=5)
    node.set_gid("physical-objective")
    ax.add_patch(node)
    text(49, 36.5, r"$\mathcal{J}(\theta)$", "objective-symbol", fontsize=9)
    text(49, 28.5, L["arch_objective"], "objective-caption", fontsize=7)
    text(25, 42.5, L["arch_optimizer"], "optimizer-caption", fontsize=7)
    arrow([(44.5, 36.5), (3, 36.5), (3, 157), (18, 157), (18, 148), (20.5, 148)], "parameter-update-loop")
    box(53, 5, 77, 13, L["arch_accept"], "acceptance-and-commit")
    arrow([(53, 34.5), (58, 34.5), (58, 18.5)], "objective-to-acceptance")
    arrow([(72, 4.5), (72, 2), (5, 2), (5, 50), (18, 50), (18, 51.5)],
          "accepted-state-feedback", dashed=True)
    return fig



# All quantitative maps below use true natural coordinates and equal aspect.
# Mesh edges are display cells; integration always uses the archived weights.
EXPANDED = None
KNEE_LIMITS = {2: (-7.1, -4.45, -4.15, -1.50), 4: (4.45, 7.1, -4.15, -1.50)}


def closed_wall(data):
    wall = data["x_natural_m"][NV:]
    return np.vstack((wall, wall[0]))


def field_axes(fig, rect, title, limits, labels=False):
    ax = axes(fig, rect, title)
    ax.set(xlim=limits[:2], ylim=limits[2:], aspect="equal")
    if labels:
        ax.set_xlabel(r"$X_1$ (m)", labelpad=1)
        ax.set_ylabel(r"$X_2$ (m)", labelpad=1)
    ax.tick_params(labelsize=7, pad=1)
    return ax


def map_field(ax, data, value, cmap, norm, expanded=False):
    if expanded:
        depth = EXPANDED["radial_distances_natural_m"]
        de = np.r_[edges(data["radial_distances_natural_m"], 0, 1/data["f0"][0, 0]),
                   EXPANDED["outer_radial_edges_m"][1:]]
        na, nr = EXPANDED["volume_shape"]
    else:
        depth = data["radial_distances_natural_m"]
        de = edges(depth, 0, 1/data["f0"][0, 0])
        na, nr = NA, NR
    wall = data["x_natural_m"][NV:]
    normal = data["reference_normal"][NV:, :2]
    we = .5*(np.roll(wall, 1, axis=0)+wall)
    ne = np.roll(normal, 1, axis=0)+normal
    ne /= np.linalg.norm(ne, axis=1)[:, None]
    we, ne = np.vstack((we, we[0])), np.vstack((ne, ne[0]))
    xy = we[:, None, :]-de[None, :, None]*ne[:, None, :]
    mesh = ax.pcolormesh(xy[..., 0], xy[..., 1], value[:na*nr].reshape(na, nr),
                        cmap=cmap, norm=norm, shading="flat", rasterized=True, zorder=1)
    wall = closed_wall(data)
    ax.fill(wall[:, 0], wall[:, 1], facecolor="white", edgecolor="black", lw=.6, zorder=4)
    return mesh


def support(ax, data, values, color="black", style="-", lw=.7):
    # Contours show the sampled threshold, not a resolved material front.
    xy = data["x_natural_m"][:NV].reshape(NA, NR, 2)
    v = values[:NV].reshape(NA, NR)
    if v.max() > 1e-7 and v.min() < 1e-7:
        contour = ax.contour(xy[..., 0], xy[..., 1], v, levels=[1e-7], colors=[color],
                             linestyles=[style], linewidths=[lw], zorder=5)
        contour.set_array(None)  # One labelled threshold guide, not a scalar colour field.


def signed_norm(values):
    limit = max(float(np.nanmax(np.abs(v))) for v in values)
    return Normalize(-limit, limit)


def sequential_norm(values, zero=True):
    lo = 0. if zero else min(float(np.nanmin(v)) for v in values)
    hi = max(float(np.nanmax(v)) for v in values)
    return Normalize(lo, hi)


def knee_map(fig, rect, label, data, knee, value, cmap, norm, old=None, labels=False):
    ax = field_axes(fig, rect, label, KNEE_LIMITS[knee], labels)
    mesh = map_field(ax, data, value, cmap, norm)
    ax.set_xticks([-7, -6, -5] if knee == 2 else [5, 6, 7])
    ax.set_yticks([-4, -3, -2])
    if old is not None:
        support(ax, data, old)
    return ax, mesh


def locator(fig, rect, data, title="Natural geometry"):
    ax = fig.add_axes(rect)
    ax.set_aspect("equal")
    wall = closed_wall(data)
    ax.plot(*wall.T, color="black", lw=.8)
    for k, color in ((2, fs.RED), (4, fs.BLUE)):
        a, b, c, d = KNEE_LIMITS[k]
        ax.add_patch(Rectangle((a, c), b-a, d-c, fill=False, ec=color, lw=.8))
        ax.text((a+b)/2, c-.5, "L" if k == 2 else "R", color=color, ha="center", fontsize=7)
    ax.set(xlim=(-9, 9), ylim=(-6, 9))
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_axis_off()
    ax.set_title(title, fontsize=7, pad=0)
    return ax


def problem(data, rows, profiles):
    fig = setup("problem")
    wall = closed_wall(data)
    s0 = data["f0"][0, 0]
    ax = field_axes(fig, [.08, .60, .38, .35], "(a) Precompressed domain", (-118, 118, -118, 118), True)
    ax.add_patch(Circle((0, 0), 107.68, fc="#f1f1f1", ec="black", lw=.8))
    ax.fill(*(wall*s0).T, color="white", ec="black", lw=.5)
    ax.add_patch(Rectangle((-20*s0, -18*s0), 40*s0, 38*s0, fill=False, ec=fs.BLUE, lw=.8))
    ax.annotate(r"$u_1=u_2=0$", (80, 72), (0, 72), ha="center",
                arrowprops=dict(arrowstyle="->", lw=.7))
    ax.set_xlabel(r"$x_{01}$ (m)")
    ax.set_ylabel(r"$x_{02}$ (m)")
    ax.text(0, -85, r"$R_0=8W=107.68$ m", ha="center", fontsize=7)
    ax = field_axes(fig, [.57, .60, .36, .35], "(b) Cavity and rock band", (-8.5, 8.5, -6, 8), True)
    mesh = map_field(ax, data, np.ones(len(data["x_natural_m"])), ListedColormap(["#dbe5eb"]), Normalize(0, 1))
    mesh.set_array(None)
    mesh.set_facecolor("#e5e5e5")
    ax.text(0, 1, "Cavity", ha="center", fontsize=8, zorder=8)
    ax.text(0, -1, r"$p_w/p_0\downarrow$", ha="center", fontsize=8, zorder=8)
    for i in [25, 120, 224, 325, 495, 620, 710]:
        x = data["x_natural_m"][NV+i]
        n = data["reference_normal"][NV+i, :2]
        ax.annotate("", x, x+1.2*n, arrowprops=dict(arrowstyle="->", color=fs.RED, lw=.8), zorder=8)
    for knee in [2, 4]:
        ids = np.flatnonzero(data["angular_arc_index"] == knee)
        xy = data["x_natural_m"][NV+ids]
        ax.plot(*xy.T, color=fs.RED if knee == 2 else fs.BLUE, lw=1.6)
    ax.text(-7, -5.4, "L knee", color=fs.RED, fontsize=7)
    ax.text(4, -5.4, "R knee", color=fs.BLUE, fontsize=7)
    # This panel uses natural geometry: preserve its axes and dimensional delta.
    ax.set_title("(b) Natural cavity and rock band", loc="left", fontsize=7)
    fig.text(.56, .565, r"$\delta=1.015274$ m; band is rock", fontsize=7)
    names = ["Natural", "Precompressed", "Current (0.6750)"]
    shapes = [wall, wall*s0, np.vstack((data["x_natural_m"][NV:]*s0+data["e3_u_m"][NV:],
                                      data["x_natural_m"][NV]*s0+data["e3_u_m"][NV]))]
    for i, (name, xy) in enumerate(zip(names, shapes)):
        ax = fig.add_axes([.05+.32*i, .23, .26, .28])
        ax.plot(*xy.T, color=[fs.BLACK, fs.BLUE, fs.RED][i], lw=1)
        ax.set(xlim=(-8, 8), ylim=(-5.5, 8), aspect="equal")
        ax.set_axis_off()
        ax.set_title(f"({chr(99+i)}) {name}", fontsize=7)
        ax.text(0, -5, [r"$X,\ C^p=I,\ \kappa=0$", r"$x_0=F_0X$", r"$x=F_0X+u$"][i],
                ha="center", va="top", fontsize=7)
        if i < 2:
            fig.text(.33+.32*i, .37, r"$\longrightarrow$", fontsize=13)
    fig.text(.5, .17, "Configuration panels share scale; displacement amplification = 1", ha="center", fontsize=7)
    fig.text(.5, .105, r"Accepted pressures:  $0.7250\ \rightarrow\ 0.7125\ \rightarrow\ 0.7000\ \rightarrow\ 0.6875\ \rightarrow\ 0.6750$",
             ha="center", fontsize=7)
    fig.text(.5, .05, r"Current wall traction: $\sigma n=-p_wn,\quad n\propto F^{-T}N$", ha="center", fontsize=8)
    return fig


def matrix_fields(data, rows, figure_id, quantities, labels, cmaps, norms, closure=False):
    fig = setup(figure_id)
    limits = (-20, 20, -18, 20)
    top, pitch, height = (.91, .177, .148) if closure else (.92, .205, .175)
    xs = [.09, .395, .70]
    for c, label in enumerate(labels):
        fig.text(xs[c]+.12, .985, label, ha="center", va="top", fontsize=8)
    meshes = []
    for j in range(4):
        y = top-j*pitch-height
        for c in range(3):
            ax = field_axes(fig, [xs[c], y, .245, height], f"({chr(97+3*j+c)})"+(f"  {P[j]:.4f}" if c == 0 else ""), limits)
            ax.set_xticks([-20, 0, 20])
            ax.set_yticks([-10, 0, 10, 20])
            if c:
                ax.set_yticklabels([])
            if j < 3:
                ax.set_xticklabels([])
            else:
                ax.set_xlabel(r"$X_1$ (m)", labelpad=1)
            if c == 0:
                ax.set_ylabel(r"$X_2$ (m)", labelpad=1)
            mesh = map_field(ax, data, quantities[j][c], cmaps[c], norms[c], True)
            if figure_id != "displacement":
                support(ax, data, data[f"e{j}_kappa"], color="black", lw=.55)
            meshes.append(mesh)
    by = .18 if closure else .068
    for c in range(3):
        bar(fig, [meshes[j*3+c] for j in range(4)], [xs[c], by, .245, .009], labels[c])
    if closure:
        ax = axes(fig, [.14, .062, .48, .060], "(m) Cavity closure", r"$p_w/p_0$", "Closure (%)")
        for i, (key, label) in enumerate((("width_closure", "Width"), ("height_closure", "Height"), ("area_closure", "Area"))):
            y = [100*next(r for r in rows if r["pressure_ratio"] == p and r["region"] == "wall")[key] for p in P]
            ax.plot(P, y, color=[fs.BLACK, fs.RED, fs.BLUE][i], marker=["o", "^", "s"][i],
                    ms=2.5, lw=.9, label=label)
        ax.set_xlim(.715, .6725)
        ax.set_xticks([.7125, .7, .6875, .675])
        ax.legend(loc="center left", bbox_to_anchor=(1.02, .5), frameon=False)
    return fig


def displacement(data, rows, profiles):
    values = []
    for j in range(4):
        u = EXPANDED[f"e{j}_u_m"]*1000
        values.append([u[:, 0], u[:, 1], np.linalg.norm(u, axis=1)])
    norms = [signed_norm([v[c] for v in values]) for c in range(2)]
    norms.append(sequential_norm([v[2] for v in values]))
    return matrix_fields(data, rows, "displacement", values,
                         [r"$u_1$ (mm)", r"$u_2$ (mm)", r"$|u|$ (mm)"],
                         [field_cmap(signed=True), field_cmap(signed=True), field_cmap()], norms, closure=True)


def stresses(data, rows, profiles):
    values = []
    for j in range(4):
        s = EXPANDED[f"e{j}_sigma_return"]
        tr = np.trace(s, axis1=1, axis2=2)
        dev = s-tr[:, None, None]*np.eye(3)/3
        values.append([-tr/3, np.sqrt(1.5*(dev**2).sum((1, 2))), s[:, 2, 2]])
    return matrix_fields(data, rows, "stresses", values,
                         [r"$p_m^{\rm R}/p_0$", r"$q^{\rm R}/p_0$", r"$\sigma_{33}^{\rm R}/p_0$"],
                         [field_cmap(), field_cmap(), field_cmap(reverse=True)],
                         [sequential_norm([v[c] for v in values], False) for c in [0, 1]]+
                         [sequential_norm([v[2] for v in values], False)])


def cartesian(data, rows, profiles):
    values = [[EXPANDED[f"e{j}_sigma_return"][:, a, b] for a, b in [(0, 0), (1, 1), (0, 1)]] for j in range(4)]
    return matrix_fields(data, rows, "cartesian", values,
                         [r"$\sigma_{11}^{\rm R}/p_0$", r"$\sigma_{22}^{\rm R}/p_0$", r"$\sigma_{12}^{\rm R}/p_0$"],
                         [field_cmap(reverse=True), field_cmap(reverse=True), field_cmap(signed=True)],
                         [sequential_norm([v[c] for v in values], False) for c in [0, 1]]+
                         [signed_norm([v[2] for v in values])])


def radial_station(data, knee):
    ids, s, *_ = knee_grid(data, knee)
    # Same natural along-arc fraction in both knees, without interpolating history.
    target = .498553475533
    length = data["wall_weights_m"][ids].sum()
    index = np.argmin(np.abs(s/length-target))
    return ids[index], s[index]


def finite_deformation(data, rows, profiles):
    fig = setup("finite_deformation")
    values = []
    f0inv = np.linalg.inv(data["f0"])
    j0 = np.linalg.det(data["f0"])
    for j in [0, 3]:
        f = EXPANDED[f"e{j}_F"]
        a = f@f0inv
        eig, v = np.linalg.eigh(a@a.transpose(0, 2, 1))
        h = (v*(.5*np.log(eig))[:, None, :])@v.transpose(0, 2, 1)
        dev = h-np.trace(h, axis1=1, axis2=2)[:, None, None]*np.eye(3)/3
        values.append([np.log(np.linalg.det(f)/j0)*1000, np.sqrt(2/3*(dev**2).sum((1, 2)))*1000])
    norms = [signed_norm([v[0] for v in values]), sequential_norm([v[1] for v in values])]
    meshes = [[], []]
    for row, j in enumerate([0, 3]):
        for col in range(2):
            ax = field_axes(fig, [.10+.47*col, .69-.285*row, .33, .225],
                            f"({chr(97+row*2+col)}) {P[j]:.4f}", (-20, 20, -18, 20))
            ax.set_xticks([-20, 0, 20])
            ax.set_yticks([-10, 0, 10, 20])
            ax.set_ylabel(r"$X_2$ (m)" if col == 0 else "")
            if row:
                ax.set_xlabel(r"$X_1$ (m)", labelpad=1)
            else:
                ax.set_xticklabels([])
            meshes[col].append(map_field(ax, data, values[row][col], field_cmap(signed=(col == 0)), norms[col], True))
    for col, label in enumerate([r"$10^3\ln(J/J_0)$", r"$10^3\sqrt{2/3}\,|\mathrm{dev}\,h_u|$"]):
        bar(fig, meshes[col], [.10+.47*col, .342, .33, .01], label)
    fig.text(.5, .97, r"$\widehat F=FF_0^{-1},\quad h_u=\frac{1}{2}\log(\widehat F\widehat F^T)$", ha="center", fontsize=8)
    ax = field_axes(fig, [.09, .065, .30, .215], "(e) Wall configurations, 1×", (-7.5, 7.5, -5, 7.5))
    wall = closed_wall(data)
    current = data["x_natural_m"][NV:]*data["f0"][0, 0]+data["e3_u_m"][NV:]
    ax.plot(*(wall*data["f0"][0, 0]).T, color=fs.BLACK, lw=1, label="Precompressed")
    ax.plot(*np.vstack((current, current[0])).T, color=fs.RED, lw=.8, ls="--", label="0.6750")
    ax.set(xlabel=r"$x_1$ (m)", ylabel=r"$x_2$ (m)")
    ax.legend(fontsize=7, loc="center", frameon=False)
    ax = axes(fig, [.54, .078, .40, .205], "(f) Final volume decomposition", r"$d$ (m)", r"$10^3\ln J_\bullet$")
    depth = data["radial_distances_natural_m"]
    for knee, ls in [(2, "-"), (4, "--")]:
        idx, _ = radial_station(data, knee)
        total = EXPANDED["band_e3_log_volume"][:NV].reshape(NA, NR)[idx]
        plastic = EXPANDED["band_e3_log_Jp"][:NV].reshape(NA, NR)[idx]
        for val, color, label in [(total, fs.BLACK, r"$J/J_0$"), (total-plastic, fs.BLUE, r"$J_e/J_0$"), (plastic, fs.RED, r"$J_p$")]:
            ax.plot(depth, val*1000, color=color, ls=ls, lw=.9, label=label if knee == 2 else None)
    ax.set(xlim=(0, .20))
    ax.axhline(0, color=".6", lw=.5)
    ax.legend(ncol=3, loc="center", fontsize=7, frameon=False, handlelength=1.2, columnspacing=.7)
    fig.text(.54, .027, "Fixed mid-knee rays: L solid, R dashed", fontsize=7)
    return fig


def plastic(data, rows, profiles):
    fig = setup("plastic")
    locator(fig, [.02, .73, .27, .245], data, "(a) Knee locations")
    fig.text(.33, .925, r"Cumulative $\kappa$ at accepted states", fontsize=9)
    fig.text(.33, .86, "Red/blue boxes: L/R windows\nWall samples use the same colour scale\nGrey: below threshold; equal spatial aspect", fontsize=7, linespacing=1.5)
    fig.text(.33, .775, r"Contours in final column: 0.7125 solid, 0.7000 dashed", fontsize=7)
    vals = [data["e0_kappa_old"], data["e2_kappa"], data["e3_kappa"]]
    ps = [.725, .6875, .675]
    norm = LogNorm(1e-7, max(v.max() for v in vals))
    meshes = []
    wall_colours = []
    for row, knee in enumerate([2, 4]):
        for col, (v, pressure) in enumerate(zip(vals, ps)):
            ax, mesh = knee_map(fig, [.095+.30*col, .425-.295*row, .225, .27],
                                f"({chr(98+row*3+col)}) {pressure:.4f} {'L' if knee == 2 else 'R'}",
                                data, knee, v, plastic_cmap(), norm, labels=(col == 0))
            if col != 0:
                ax.set_yticklabels([])
            if row:
                ax.set_xlabel(r"$X_1$ (m)", labelpad=1)
            if col == 2:
                support(ax, data, data["e0_kappa"], fs.BLUE, "-")
                support(ax, data, data["e1_kappa"], fs.RED, "--")
            wall = data["x_natural_m"][NV:]
            we = .5*(np.roll(wall, 1, axis=0)+wall)
            segments = np.stack((we, np.roll(we, -1, axis=0)), axis=1)
            wall_colour = LineCollection(segments, cmap=plastic_cmap(), norm=norm, linewidth=1.1, zorder=6)
            wall_colour.set_array(v[NV:])
            ax.add_collection(wall_colour)
            wall_colours.append(wall_colour)
            meshes.append(mesh)
    bar(fig, meshes+wall_colours, [.14, .062, .73, .012], r"Accumulated plastic multiplier $\kappa$",
        ticks=[1e-7, 1e-6, 1e-5, 1e-4, 1e-3], log=True)
    return fig


def joint_increment(data, rows, profiles, earlier=False):
    fid = "early_increments" if earlier else "increments"
    fig = setup(fid)
    ends = [0, 1] if earlier else [2, 3]
    parent = [.725]+P[:-1]
    xs = [.07, .305, .55, .785]
    all_values = [[np.linalg.norm(data[f"e{j}_du_m"], axis=1)*1000,
                   np.linalg.norm(data[f"e{j}_dF"], axis=(1, 2))*1000, data[f"e{j}_dk"]] for j in range(4)]
    norms = [sequential_norm([v[i] for v in all_values]) for i in [0, 1]]
    norms.append(LogNorm(1e-7, max(v[2].max() for v in all_values)))
    labels = [r"$|\Delta u|$ (mm)", r"$10^3|\Delta F|_F$", r"Actual $\Delta\kappa$"]
    for g, j in enumerate(ends):
        fig.text(.29+.48*g, .975, f"{parent[j]:.4f} → {P[j]:.4f}", ha="center", fontsize=8)
    fig.text(.50, .935, "L knee       R knee                    L knee       R knee", ha="center", fontsize=7)
    for row in range(3):
        meshes = []
        y = .69-.285*row
        for col, (j, knee) in enumerate([(ends[0], 2), (ends[0], 4), (ends[1], 2), (ends[1], 4)]):
            ax, mesh = knee_map(fig, [xs[col], y, .18, .205], f"({chr(97+row*4+col)})",
                                data, knee, all_values[j][row], plastic_cmap() if row == 2 else field_cmap(), norms[row],
                                old=data[f"e{j}_kappa_old"])
            if col:
                ax.set_yticklabels([])
            else:
                ax.set_ylabel(r"$X_2$ (m)", labelpad=1)
            if row < 2:
                ax.set_xticklabels([])
            else:
                ax.set_xlabel(r"$X_1$ (m)", labelpad=1)
            meshes.append(mesh)
        by = y-.047
        bar(fig, meshes, [.19, by, .62, .009], labels[row],
            ticks=[1e-7, 1e-6, 1e-5, 1e-4, 1e-3] if row == 2 else None, log=row == 2)
    fig.text(.5, .021, "Black guides: old cumulative support; all differences use the accepted parent", ha="center", fontsize=7)
    return fig


def increments(data, rows, profiles):
    return joint_increment(data, rows, profiles)


def early_increments(data, rows, profiles):
    return joint_increment(data, rows, profiles, True)


def stress(data, rows, profiles):
    fig = setup("stress")
    xs = [.07, .305, .55, .785]
    ends = [2, 3]
    vals = [[data[f"e{j}_return_delta_four_Q10"][:, 2],
             data[f"e{j}_return_delta_four_Q10"][:, 3], EXPANDED[f"band_e{j}_trial_f"]] for j in ends]
    norms = [signed_norm([v[c] for v in vals]) for c in range(3)]
    labels = [r"$\Delta\sigma_{tt}^{\rm R}/p_0$", r"$\Delta\sigma_{33}^{\rm R}/p_0$", r"$f_\tau^{\rm tr}/p_0$"]
    for g, text in enumerate(["0.7000 → 0.6875", "0.6875 → 0.6750"]):
        fig.text(.29+.48*g, .977, text, ha="center", fontsize=8)
    fig.text(.5, .942, "L knee       R knee                    L knee       R knee", ha="center", fontsize=7)
    for row in range(3):
        meshes = []
        y = .752-.218*row
        for col, (vi, knee) in enumerate([(0, 2), (0, 4), (1, 2), (1, 4)]):
            j = ends[vi]
            ax, mesh = knee_map(fig, [xs[col], y, .18, .168], f"({chr(97+row*4+col)})",
                                data, knee, vals[vi][row], field_cmap(signed=True), norms[row], old=data[f"e{j}_kappa_old"])
            if col:
                ax.set_yticklabels([])
            else:
                ax.set_ylabel(r"$X_2$ (m)", labelpad=1)
            if row < 2:
                ax.set_xticklabels([])
            else:
                ax.set_xlabel(r"$X_1$ (m)", labelpad=1)
            meshes.append(mesh)
            if row == 2:
                idx, s = radial_station(data, knee)
                ray = data["x_natural_m"][:NV].reshape(NA, NR, 2)[idx]
                ax.plot(*ray[:26].T, color=fs.BLUE, lw=1, zorder=6)
        bar(fig, meshes, [.23, y-(.017 if row < 2 else .034), .54, .008], labels[row])
    depth = data["radial_distances_natural_m"]
    for col, knee in enumerate([2, 4]):
        ax = axes(fig, [.13+.45*col, .075, .33, .125], f"({chr(109+col)}) {'Left' if knee == 2 else 'Right'} fixed ray",
                  r"$d$ (m)", r"Trial quantities / $p_0$" if col == 0 else None)
        idx, s = radial_station(data, knee)
        for j, color in [(2, fs.BLACK), (3, fs.RED)]:
            q = EXPANDED[f"band_e{j}_trial_q"][:NV].reshape(NA, NR)[idx]
            resist = (EXPANDED[f"band_e{j}_trial_alpha_p"]+EXPANDED[f"band_e{j}_trial_strength"])[:NV].reshape(NA, NR)[idx]
            ax.plot(depth, q, color=color, lw=.9, label=f"{P[j]:.4f}, drive")
            ax.plot(depth, resist, color=color, ls="--", lw=.9, label=f"{P[j]:.4f}, resistance")
        ax.set_xlim(0, .2)
        ax.set_ylim(.82, 1.16)
    fig.text(.5, .018, r"Solid: $q_\tau^{\rm tr}$; dashed: $\alpha p_\tau^{\rm tr}+J(k_0+H\kappa_n)$; black/red: 0.6875/0.6750",
             ha="center", fontsize=7)
    return fig


def sources(data, rows, profiles):
    fig = setup("sources")
    depth = data["radial_distances_natural_m"]
    for col, knee in enumerate([2, 4]):
        ax = axes(fig, [.12+.46*col, .62, .34, .28], f"({chr(97+col)}) {'Left' if knee == 2 else 'Right'} knee band",
                  r"Depth $d$ (m)", r"$10^4 G_C(d)$ (m$^2$)" if col == 0 else None)
        ids = np.flatnonzero(data["angular_arc_index"] == knee)
        weight = data["volume_weights_m2"].reshape(NA, NR)[ids]
        for j, ls in [(2, "-"), (3, "--")]:
            dk = data[f"e{j}_dk"][:NV].reshape(NA, NR)[ids]
            cat = data[f"e{j}_category"][:NV].reshape(NA, NR)[ids]
            for code, color in [(1, fs.BLUE), (2, fs.RED)]:
                contribution = (weight*dk*(cat == code)).sum(0)
                ax.plot(depth, np.cumsum(contribution)*1e4, color=color, ls=ls, lw=1)
        ax.set(xlim=(0, .20), ylim=(0, .8))
    fig.legend(handles=[Line2D([], [], color=fs.BLUE, label="Old"), Line2D([], [], color=fs.RED, label="New"),
                        Line2D([], [], color=fs.BLACK, label="0.7000 → 0.6875"),
                        Line2D([], [], color=fs.BLACK, ls="--", label="0.6875 → 0.6750")],
               loc="upper center", bbox_to_anchor=(.5, .997), ncol=2, frameon=False, fontsize=7)
    for col, region in enumerate(["collar", "wall"]):
        ax = axes(fig, [.12+.46*col, .21, .34, .28], f"({chr(99+col)}) Full {'band' if col == 0 else 'wall'} budget",
                  r"Interval endpoint $p_w/p_0$", r"$10^4 I_C$ (m$^2$)" if col == 0 else r"$10^3 I_C$ (m)")
        selected = [next(r for r in rows if r["pressure_ratio"] == pressure and r["region"] == region) for pressure in P[1:]]
        factor = 1e4 if col == 0 else 1e3
        bottom = np.zeros(3)
        for category, color in [("old", fs.BLUE), ("new", fs.RED), ("subthreshold", ".75")]:
            values = np.array([r[f"{category}_delta_kappa_integral"]*factor for r in selected])
            ax.bar(np.arange(3), values, bottom=bottom, width=.57, color=color, edgecolor="black", lw=.4)
            bottom += values
        for i, r in enumerate(selected):
            ax.text(i, bottom[i]+.035*max(bottom), f"{100*r['new_increment_share']:.1f}%", ha="center", va="bottom", fontsize=7)
        ax.set_xticks(np.arange(3), [f"{p:.4f}" for p in P[1:]])
        ax.set_ylim(0, max(bottom)*1.24)
    fig.text(.5, .115, "Labels: new-region share of the actual increment", ha="center", fontsize=7)
    fig.text(.5, .072, r"Final band: area $\times$ mean $\Delta\kappa$ = increment contribution", ha="center", fontsize=8)
    fig.text(.5, .036, r"Old: $0.301096\times3.95246\,10^{-4}$;  New: $0.091893\times1.59959\,10^{-4}$  (m$^2$)",
             ha="center", fontsize=7)
    return fig


def coordination(data, rows, profiles):
    fig = setup("coordination")
    values = [data["e3_network_four_Q10"][:, 2], data["e3_return_four_Q10"][:, 2]]
    values.append(values[0]-values[1])
    gap = [data[f"e{j}_difference_norm_over_p0"] for j in [2, 3]]
    labels = [r"$\sigma_{tt}^{\rm N}/p_0$", r"$\sigma_{tt}^{\rm R}/p_0$", r"$(\sigma_{tt}^{\rm N}-\sigma_{tt}^{\rm R})/p_0$"]
    norms = [sequential_norm(values[:2], False)]*2+[signed_norm([values[2]])]
    for row in range(2):
        meshes = []
        for col in range(3):
            rect = [.08+.312*col, .72-.275*row, .266, .215]
            ax = field_axes(fig, rect, f"({chr(97+row*3+col)})", (-8.2, 8.2, -5.6, 8.1))
            ax.set_xticks([-5, 0, 5])
            ax.set_yticks([-5, 0, 5])
            if col:
                ax.set_yticklabels([])
            else:
                ax.set_ylabel(r"$X_2$ (m)", labelpad=1)
            if row == 0:
                val, norm, label = values[col], norms[col], labels[col]
                cmap = field_cmap(reverse=True) if col < 2 else field_cmap(signed=True)
            else:
                val = gap[col] if col < 2 else gap[1]-gap[0]
                cmap = field_cmap() if col < 2 else field_cmap(signed=True)
                norm = sequential_norm(gap) if col < 2 else signed_norm([val])
                label = [r"$D_\sigma$, 0.6875", r"$D_\sigma$, 0.6750", r"$\Delta D_\sigma$"][col]
            mesh = map_field(ax, data, val, cmap, norm)
            bar(fig, [mesh], [.095+.312*col, .699-.275*row, .235, .008], label)
            if row == 1 and col == 1:
                peak = np.argmax(gap[1][NV:])+NV
                point = data["x_natural_m"][peak]
                ax.plot(*point, "o", mec="black", mfc="none", ms=4, zorder=7)
                ax.annotate("Wall peak", point, (0, -1.5), fontsize=7, ha="center", zorder=8,
                            arrowprops=dict(arrowstyle="->", lw=.6))
        if row:
            fig.text(.5, .34, r"$D_\sigma=|\sigma^{\rm N}-\sigma^{\rm R}|_F/p_0$; positive change = worse coordination",
                     ha="center", fontsize=7)
    for col, knee in enumerate([2, 4]):
        ax = axes(fig, [.13+.46*col, .092, .33, .18], f"({chr(103+col)}) {'Left' if knee == 2 else 'Right'} current wall",
                  r"$s$ (m)", r"$10^3 r^{\rm R}$" if col == 0 else None)
        idx, s, *_ = knee_grid(data, knee)
        for j, color in [(2, fs.BLACK), (3, fs.RED)]:
            vals = data[f"e{j}_return_four_current"][NV+idx]
            ax.plot(s, (vals[:, 0]+P[j])*1000, color=color, lw=.9)
            ax.plot(s, vals[:, 1]*1000, color=color, ls="--", lw=.9)
        ax.axhline(0, color=".6", lw=.5)
        ax.set(xlim=(0, s[-1]), ylim=(-5, 5))
    fig.text(.5, .979, r"Final mixed stresses in fixed $Q_{10}$; band maps, natural geometry", ha="center", fontsize=8)
    fig.text(.5, .046, "Solid: normal residual; dashed: tangential residual; black/red: 0.6875/0.6750", ha="center", fontsize=7)
    fig.text(.5, .015, "Final wall peak rises 15.68%; full-wall RMS changes +0.019%", ha="center", fontsize=7)
    return fig


def acceptance(data, rows, profiles):
    fig = setup("acceptance")
    events_path = ROOT / "data/validation_checks.jsonl"
    events = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines()]
    records = {}
    for event in events:
        if event["phase"] == "physical_validation":
            records.setdefault(event["evaluations"], event)
    assert set(records) == {0, 201, 401}
    series = []
    for evaluation, event in records.items():
        v = event["validation"]
        thresholds = v["effective_thresholds"]
        worst = max(v[key] for key in ("consistency_rms", "consistency_wall_rms", "consistency_collar_rms",
                                      "consistency_transition_rms", "consistency_outer_rms"))
        series.append([worst/thresholds["consistency_rms"], v["material_weak_max"]/thresholds["weak_max"],
                       v["traction_material_rms"]/thresholds["traction_material_rms"]])
    ax = axes(fig, [.14, .40, .80, .48], "(a) Recorded validation checks at one pressure",
              "Objective evaluations at recorded check", "Residual / acceptance bound")
    for i, (label, color, marker) in enumerate(zip(["Worst consistency RMS", "Returned local-work peak", "Returned traction RMS"],
                                                 [fs.BLACK, fs.RED, fs.BLUE], ["o", "^", "s"])):
        ax.plot(list(records), np.array(series)[:, i], linestyle="none", marker=marker, color=color, ms=5, label=label)
    ax.axhline(1, color=".5", lw=.9, ls="--")
    ax.set(xlim=(-22, 425), xticks=[0, 201, 401], yscale="log", ylim=(.1, 10))
    ax.set_yticks([.1, 1, 10], ["0.1", "1", "10"])
    ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.legend(loc="upper right", frameon=False, fontsize=7)
    fig.text(.14, .25, "(b) Final accepted step: 0.6875 → 0.6750", fontsize=8)
    fig.text(.14, .17, "327.62 s total; 150.73 s curvature preparation (included)\n401 objective evaluations; 18 native L-BFGS update batches",
             fontsize=8, linespacing=1.6)
    fig.text(.14, .055, "Only three distinct checks were recorded; no dense convergence curve is inferred.", fontsize=7)
    return fig


RENDERERS = dict(problem=problem, architecture=architecture, displacement=displacement, stresses=stresses,
                 finite_deformation=finite_deformation, plastic=plastic, increments=increments,
                 stress=stress, sources=sources, coordination=coordination,
                 cartesian=cartesian, early_increments=early_increments, acceptance=acceptance)


def validate_plot_data(data, rows):
    """Reconcile rendered budgets/RMS and colour bounds against original-point evidence."""
    checks = []
    weights = np.r_[data["volume_weights_m2"], data["wall_weights_m"]]
    point = np.arange(NV + NA)
    regions = {"collar": point < NV, "wall": point >= NV}
    for side, knee in (("left", 2), ("right", 4)):
        for domain in ("collar", "wall"):
            regions[f"{side}_knee_{domain}"] = regions[domain] & (data["arc_index"] == knee)
    assert np.all(weights > 0)
    for j, pressure in enumerate(P):
        dk, category = data[f"e{j}_dk"], data[f"e{j}_category"]
        assert np.all(np.isfinite(dk)) and dk.min() >= 0
        np.testing.assert_allclose(dk, data[f"e{j}_kappa"] - data[f"e{j}_kappa_old"], rtol=0, atol=1e-15)
        assert np.isin(category, [0, 1, 2]).all()
        assert np.linalg.norm(data[f"e{j}_u_m"], axis=1).max()*1000 <= 90
        tt = data[f"e{j}_return_four_Q10"][:, 2]
        assert tt.min() >= -1.7 and tt.max() <= -1.0
        assert data[f"e{j}_kappa"].max() <= 3e-3 and dk.max() <= 2e-3
        for region, mask in regions.items():
            record = next(r for r in rows if r["pressure_ratio"] == pressure and r["region"] == region)
            integral = np.sum(weights[mask] * dk[mask])
            np.testing.assert_allclose(integral, record["actual_delta_kappa_integral"], rtol=1e-12, atol=1e-18)
            for code, name in ((0, "subthreshold"), (1, "old"), (2, "new")):
                selection = mask & (category == code)
                value = np.sum(weights[selection] * dk[selection])
                np.testing.assert_allclose(value, record[name + "_delta_kappa_integral"], rtol=1e-12, atol=1e-18)
            gap = data[f"e{j}_difference_norm_over_p0"][mask]
            rms = np.sqrt(np.sum(weights[mask] * gap**2) / weights[mask].sum())
            np.testing.assert_allclose(rms, record["network_return_difference_rms_over_p0"], rtol=1e-12, atol=1e-15)
            checks.append([pressure, region])
    assert data["e3_difference_norm_over_p0"].max()*1000 <= 11
    return {"status": "passed", "endpoint_region_records": len(checks),
            "checks": "Natural-weighted total/class increment integrals and full-tensor difference RMS; own-parent increments; shared colour bounds without upper clipping.",
            "training_or_field_evaluation": False}


def main():
    global EXPANDED
    with np.load(OUT / "plot_data.npz", allow_pickle=False) as archive:
        data = dict(archive)
    with np.load(OUT / "expanded_fields.npz", allow_pickle=False) as archive:
        EXPANDED = dict(archive)
    rows, profiles = csv_rows("table1.csv"), csv_rows("knee_profiles.csv")
    print(validate_plot_data(data, rows), flush=True)
    selected = sys.argv[1:] or list(RENDERERS)
    if set(selected) - RENDERERS.keys():
        raise ValueError("Unknown figure id; available: " + ", ".join(RENDERERS))
    for figure_id in selected:
        spec = next(s for s in SPEC["figures"] if s["id"] == figure_id)
        fig = RENDERERS[figure_id](data, rows, profiles)
        path = OUT / (spec["stem"] + ".pdf")
        with plt.rc_context({"pdf.fonttype": 42, "svg.fonttype": "none", "savefig.bbox": None}):
            fig.savefig(path, facecolor="white", metadata={"Creator": None, "Producer": None, "CreationDate": None})
            fig.savefig(path.with_suffix(".svg"), facecolor="white", metadata={"Creator": None, "Date": None})
        plt.close(fig)
        print(figure_id + ": PDF/SVG written", flush=True)


if __name__ == "__main__":
    main()
