"""Original regional budgets and profile formulas, with generated inputs."""
import csv
from pathlib import Path
import numpy as np
import torch
import current_traction as ct
from horseshoe_geometry import HorseshoeWall
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures/pinn_mechanism_endpoints_01'
PRESSURES = [.7125, .7, .6875, .675]
REGIONS = ['collar', 'left_knee_collar', 'right_knee_collar',
           'wall', 'left_knee_wall', 'right_knee_wall']
def scalar(value):
    return float(value)

def mean(v, w):
    return scalar((v * w).sum() / w.sum())

def rms(v, w):
    return mean(v.reshape(len(w), -1).square().sum(-1), w) ** .5

def local(v, q):
    return q.transpose(-1, -2) @ v @ q

def four(v):
    return torch.stack((v[:, 0, 0], v[:, 0, 1], v[:, 1, 1], v[:, 2, 2]), -1)
def export_reports(config, grid, fields, full_fields, f0):
    x = grid['x_natural_m']
    wall = HorseshoeWall.from_json(ROOT/config['geometry'], device=x.device, scale=1/f0[0, 0])
    closure = {}
    nv, tol, p0 = grid['volume_count'], config['plastic_threshold'], config['p0']
    w = torch.cat((grid['volume_weights_m2'], grid['wall_weights_m']))
    volume = torch.arange(len(x), device=x.device) < nv
    arc = grid['arc_index']
    masks = dict(zip(REGIONS, (volume, volume & (arc == 2), volume & (arc == 4),
                              ~volume, ~volume & (arc == 2), ~volume & (arc == 4))))
    _, q10, _ = ct.current_frame(fields[.7125]['F'], grid['reference_normal'])
    arrays = {k: v.detach().cpu().numpy() for k,v in grid.items() if isinstance(v, torch.Tensor)}
    arrays.update(Q10=q10.cpu().numpy(), f0=f0.cpu().numpy(), pressures=np.array(PRESSURES))
    rows, spatial, profiles = [], [], []
    partition_error = 0.
    for j, p in enumerate(PRESSURES):
        end = fields[p]
        old = fields[end['previous_pressure_ratio']]
        assert torch.equal(end['cp_old'], old['cp']) and torch.equal(end['kappa_old'], old['kappa'])
        dk, du, df = end['kappa']-old['kappa'], end['u_m']-old['u_m'], end['F']-old['F']
        assert scalar(dk.min()) >= -1e-12
        plastic, active, old_plastic = end['kappa'] > tol, dk > tol, old['kappa'] > tol
        category = torch.where(old_plastic, 1, torch.where(plastic, 2, 0))
        difference = end['sigma_network']-end['sigma_return']
        difference_norm = torch.linalg.matrix_norm(difference)/p0
        determinant = torch.linalg.det(end['F'])
        _, qcurrent, nanson = ct.current_frame(end['F'], grid['reference_normal'])
        wc = w * torch.where(volume, determinant, nanson)
        gauges = x.new_tensor([[6.73, 0], [-6.73, 0], [0, 6.73], [0, -4.32]])
        gauge_u = full_fields[p].displacement(gauges/f0[0,0]).detach()
        cur = gauges + gauge_u
        ids = torch.arange(6, device=x.device).repeat_interleave(128)
        frac = torch.arange(128, device=x.device, dtype=x.dtype).repeat(6)/128
        wx, _ = wall.sample(ids, frac)
        wx0 = wx @ f0[:2,:2].T
        wcur = wx0 + full_fields[p].displacement(wx).detach()
        crosssum = lambda a: (a[:,0]*torch.roll(a[:,1],-1)-a[:,1]*torch.roll(a[:,0],-1)).sum()
        c = {'width_closure': 1-scalar((cur[0]-cur[1]).norm())/13.46,
             'height_closure': 1-scalar((cur[2]-cur[3]).norm())/11.05,
             'area_closure': 1-scalar(crosssum(wcur)/crosssum(wx0))}
        closure[str(p)] = c
        common = {'dk':dk, 'du_m':du, 'dF':df, 'category':category, 'active':active,
                  'difference_norm_over_p0':difference_norm, 'J':determinant, 'nanson':nanson}
        for kind in ('return','network'):
            common[kind+'_four_Q10'] = four(local(end['sigma_'+kind], q10))/p0
            common[kind+'_delta_four_Q10'] = four(local(end['sigma_'+kind]-old['sigma_'+kind], q10))/p0
            common[kind+'_four_current'] = four(local(end['sigma_'+kind], qcurrent))/p0
        for key,value in {**end, **common}.items():
            if isinstance(value,torch.Tensor) and key != 'native_delta_kappa':
                arrays[f'e{j}_{key}'] = value.detach().cpu().numpy()
        for region, mask in masks.items():
            weight = w[mask]
            row = {'pressure_ratio':p, 'previous_pressure_ratio':end['previous_pressure_ratio'], 'region':region,
                   'measure_units':'m2' if 'collar' in region else 'm', 'measure_total':scalar(weight.sum()),
                   'current_measure_total':scalar(wc[mask].sum()),
                   'cumulative_plastic_measure':scalar(w[mask & plastic].sum()),
                   'interval_active_measure':scalar(w[mask & active].sum()),
                   'current_cumulative_plastic_measure':scalar(wc[mask & plastic].sum()),
                   'current_interval_active_measure':scalar(wc[mask & active].sum()),
                   'kappa_mean':mean(end['kappa'][mask],weight), 'kappa_max':scalar(end['kappa'][mask].max()),
                   'actual_delta_kappa_mean':mean(dk[mask],weight), 'actual_delta_kappa_integral':scalar((w[mask]*dk[mask]).sum()),
                   'delta_kappa_max':scalar(dk[mask].max()), 'new_cumulative_measure':scalar(w[mask & (category==2)].sum()),
                   'displacement_rms_m':rms(end['u_m'][mask],weight), 'increment_displacement_rms_m':rms(du[mask],weight),
                   'increment_F_rms':rms(df[mask],weight), 'increment_F_max':scalar(torch.linalg.matrix_norm(df[mask]).max()),
                   'network_return_difference_rms_over_p0':rms(difference[mask]/p0,weight),
                   'network_return_difference_max_over_p0':scalar(difference_norm[mask].max()),
                   'J_min':scalar(determinant[mask].min()), 'J_max':scalar(determinant[mask].max()), **c}
            for code,label in enumerate(('subthreshold','old','new')):
                chosen = mask & (category==code)
                integral = scalar((w[chosen]*dk[chosen]).sum())
                row[label+'_measure'] = scalar(w[chosen].sum())
                row[label+'_delta_kappa_integral'] = integral
                row[label+'_increment_share'] = integral/row['actual_delta_kappa_integral'] if row['actual_delta_kappa_integral'] else 0.
            partition_error = max(partition_error,abs(sum(row[t+'_delta_kappa_integral'] for t in ('old','new','subthreshold'))-row['actual_delta_kappa_integral']))
            for kind in ('return','network'):
                for a,comp in enumerate(('nn','nt','tt','33')):
                    row[f'{kind}_{comp}_mean_Q10_over_p0'] = mean(common[kind+'_four_Q10'][mask,a],weight)
                    row[f'{kind}_{comp}_increment_mean_Q10_over_p0'] = mean(common[kind+'_delta_four_Q10'][mask,a],weight)
                    row[f'{kind}_{comp}_current_mean_over_p0'] = mean(common[kind+'_four_current'][mask,a],weight)
                row[kind+'_stress_increment_rms_over_p0'] = rms((end['sigma_'+kind]-old['sigma_'+kind])[mask]/p0,weight)
            rows.append(row)
            for label,chosen in [('cumulative',plastic & mask),('new', (category==2)&mask),('old_increment',(category==1)&mask&(dk>0))]:
                if bool(chosen.any()):
                    spatial.append({'pressure_ratio':p,'region':region,'support':label,
                        'x1_min_m':scalar(x[chosen,0].min()),'x1_max_m':scalar(x[chosen,0].max()),
                        'x2_min_m':scalar(x[chosen,1].min()),'x2_max_m':scalar(x[chosen,1].max()),
                        'distance_max_m':scalar(grid['distance_natural_m'][chosen].max()),
                        'active_cumulative_disagreement_measure':scalar(w[mask & (active != plastic)].sum())})
        # Full-knee profiles: exact archived wall locations and radial weighted
        # means/RMS at each angular material station. No new material points.
        wa = grid['volume_weights_m2'].reshape(736,96)
        for knee in (2,4):
            angular = torch.where(grid['angular_arc_index']==knee)[0]
            length = grid['wall_weights_m'][angular].sum()
            frac = grid['arc_fraction'][nv+angular]
            s = (frac if knee==2 else 1-frac)*length
            for k,index in enumerate(angular.tolist()):
                wi, bi = nv+index, slice(index*96,(index+1)*96)
                pr = {'pressure_ratio':p,'side':'left' if knee==2 else 'right','angular_index':index,
                      'wall_point_index':wi,'s_natural_m':scalar(s[k]),'x1_natural_m':scalar(x[wi,0]),
                      'x2_natural_m':scalar(x[wi,1]),'du_wall_norm_mm':scalar(du[wi].norm())*1000,
                      'dF_wall_norm':scalar(df[wi].norm()), 'difference_wall_over_p0':scalar(difference_norm[wi]),
                      'difference_band_radial_rms_over_p0':rms(difference[bi]/p0,wa[index]),
                      'dk_wall':scalar(dk[wi])}
                for kind in ('return','network'):
                    for a,comp in enumerate(('nn','nt','tt','33')):
                        pr[f'{kind}_{comp}_wall_over_p0']=scalar(common[kind+'_four_Q10'][wi,a])
                        pr[f'{kind}_{comp}_delta_wall_over_p0']=scalar(common[kind+'_delta_four_Q10'][wi,a])
                        pr[f'{kind}_{comp}_delta_band_mean_over_p0']=mean(common[kind+'_delta_four_Q10'][bi,a],wa[index])
                profiles.append(pr)
    assert partition_error < 1e-15
    for name,records in [('table1.csv',rows),('knee_profiles.csv',profiles),('spatial_support.csv',spatial)]:
        with (OUT/name).open('w',newline='',encoding='utf-8') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    np.savez_compressed(OUT/'plot_data.npz',**arrays)
