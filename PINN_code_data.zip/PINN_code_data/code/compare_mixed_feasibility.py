"""GPU field/history reconstruction and comparison of isolated feasibility runs.

This postprocessor never feeds reference fields back into PINN training.
Outputs are reproducible JSON/PT evidence inside the selected results folder.
"""
import os
import time
PW, PC = time.perf_counter(), time.process_time()
for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
             "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
import argparse
import hashlib
import json
from pathlib import Path
import torch
import dp_material as dp
from mixed_geometry import geometry_from_config
from mixed_reference_sampling import ReferenceProbe

ROOT = Path(__file__).resolve().parents[1]


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def reconstruct_reference(folder, common_config, f0, material, common=None):
    config = json.loads((folder/"config.json").read_text(encoding="utf-8"))
    for key in ("geometry", "p0", "material"):
        if config[key] != common_config[key]:
            raise ValueError("Reference sensitivity must preserve "+key)
    mesh = geometry_from_config(config, ROOT, f0, mesh=config["reference_mesh"])
    if common is None:
        common = geometry_from_config(common_config, ROOT, f0, mesh=common_config["validation_mesh"])
    probe = ReferenceProbe(mesh, common, f0, material)
    records, files, history = [], sorted(folder.glob("accepted_*.pt")), {}
    maximum_local_error = 0.
    for path in files:
        cp = torch.load(path, map_location=f0.device, weights_only=True)
        f, u, trial = probe.evaluate(cp["u"])
        # Independently verify the production update on sparse states from the
        # actual field history; this does not affect the reference solution.
        ids = torch.arange(0, len(f), 127, device=f.device)
        check = dp.evaluate(f[ids], dp.MaterialState(probe.cp[ids], probe.kappa[ids]), material)
        maximum_local_error = max(maximum_local_error, float((trial.sigma[ids]-check.sigma).abs().max()))
        nv, w = probe.nv, common.volume.weight
        cofn = torch.linalg.solve(f[nv:].transpose(-1, -2), common.boundary.normal[:, :, None]).squeeze(-1)
        n = cofn/cofn.norm(dim=-1, keepdim=True)
        traction = (trial.sigma[nv:] @ n[:, :, None]).squeeze(-1)+cp["pressure"]*n
        info = {"pressure": cp["pressure"], "kappa_max": float(trial.kappa.max()),
                "cumulative_plastic_area_m2": float((w*(trial.kappa[:nv] > common_config["plastic_threshold"])).sum()),
                "active_plastic_area_m2": float((w*(trial.dl[:nv] > common_config["plastic_threshold"])).sum()),
                "material_wall_traction_rms": float(traction.square().sum(-1).mean().sqrt()),
                "j_min": float(torch.linalg.det(f).min()), "yield_max": float(trial.yield_value.max()),
                "plastic_volume_max": float((.5*torch.linalg.slogdet(trial.cp)[1]-material.beta*trial.kappa).abs().max())}
        probe.commit(trial)
        records.append(info)
        history[round(cp["pressure"], 12)] = {"kappa": trial.kappa[:nv], "dl": trial.dl[:nv]}
    final = probe.checkpoint(f, u, trial)
    torch.save(final, folder/"probe_last.pt")
    dump(folder/"probe_metrics.json", {"records": records, "maximum_independent_local_stress_error": maximum_local_error,
                                     "sampling_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    return final, records, history


def pair(a, b, threshold, boundary_weight):
    if not torch.equal(a["coordinates"], b["coordinates"]):
        raise ValueError("Cannot compare differently ordered point pools")
    nv, w = a["volume_count"], a["volume_weights"]
    ma, mb = a["kappa"][:nv] > threshold, b["kappa"][:nv] > threshold
    denom = (w*mb).sum()
    difference = (w*(ma ^ mb)).sum()
    return {"plastic_symmetric_difference_area_m2": float(difference),
            "plastic_symmetric_difference_over_reference": float(difference/denom) if denom > 0 else None,
            "reference_plastic_area_m2": float(denom),
            "wall_displacement_relative_l2": float(((boundary_weight*(a["u"][nv:]-b["u"][nv:]).square().sum(-1)).sum()
                /(boundary_weight*b["u"][nv:].square().sum(-1)).sum().clamp_min(1e-28)).sqrt()),
            "kappa_relative_l2": float(((w*(a["kappa"][:nv]-b["kappa"][:nv]).square()).sum()
                /(w*b["kappa"][:nv].square()).sum().clamp_min(1e-28)).sqrt())}


def plastic_path(a, b, weight, threshold, p0):
    rows = []
    for pressure in sorted(set(a) & set(b), reverse=True):
        row = {"pressure_ratio": pressure/p0}
        for name, field in (("cumulative", "kappa"), ("active", "dl")):
            actual, expected = a[pressure][field] > threshold, b[pressure][field] > threshold
            difference, area = (weight*(actual ^ expected)).sum(), (weight*expected).sum()
            row[name+"_symmetric_difference_m2"] = float(difference)
            row[name+"_reference_area_m2"] = float(area)
            row[name+"_symmetric_difference_over_reference"] = float(difference/area) if area > 0 else None
            row[name+"_absolute_difference_over_width_squared"] = float(difference/13.46**2)
        rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--common-config", default="config/mixed_horseshoe_feasibility.json")
    parser.add_argument("--probe-angular", type=int)
    parser.add_argument("--probe-radial", type=int)
    parser.add_argument("--probe-quadrature", type=int)
    parser.add_argument("--anchor")
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.backends.cuda.matmul.allow_tf32 = False
    config = json.loads((ROOT/args.common_config).read_text(encoding="utf-8"))
    for name in ("angular", "radial", "quadrature"):
        value = getattr(args, "probe_"+name)
        if value is not None:
            config["validation_mesh"][name] = value
    torch.cuda.set_device(config["device"])
    m = dp.DPParameters.from_young_poisson(**config["material"])
    f0, _, initial = dp.elastic_precompression(m, torch.tensor(config["p0"], device=config["device"], dtype=torch.float64))
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    wall, cpu = time.perf_counter(), time.process_time()
    start.record()
    values, paths, data, histories = {}, {}, {}, {}
    common = geometry_from_config(config, ROOT, f0, mesh=config["validation_mesh"])
    for name in args.runs:
        if name in values:
            continue
        folder = ROOT/"results/mixed_feasibility"/name
        result = json.loads((folder/"result.json").read_text(encoding="utf-8"))
        values[name], paths[name], histories[name] = reconstruct_reference(folder, config, f0, m, common)
        data[name] = result["records"]
        print(json.dumps({"run": name, "probe_final": paths[name][-1],
                          "elapsed_wall_seconds": time.perf_counter()-wall,
                          "elapsed_cpu_seconds": time.process_time()-cpu}), flush=True)
    pairs = {}
    selected_pairs = ([(name, args.anchor) for name in args.runs if name != args.anchor] if args.anchor
                      else list(zip(args.runs[:-1], args.runs[1:])))
    for left, right in selected_pairs:
        if paths[left][-1]["pressure"] != paths[right][-1]["pressure"]:
            continue
        metrics = pair(values[left], values[right], config["plastic_threshold"], common.boundary.weight)
        metrics["plastic_path"] = plastic_path(histories[left], histories[right], common.volume.weight,
                                               config["plastic_threshold"], config["p0"])
        common_pressures = set(r["pressure_ratio"] for r in data[left]) & set(r["pressure_ratio"] for r in data[right])
        for key in ("width_closure", "height_closure", "area_closure"):
            a = torch.tensor([next(r[key] for r in data[left] if r["pressure_ratio"] == p) for p in sorted(common_pressures)], device=f0.device)
            b = torch.tensor([next(r[key] for r in data[right] if r["pressure_ratio"] == p) for p in sorted(common_pressures)], device=f0.device)
            metrics[key+"_curve_relative_max"] = float((a-b).abs().max()/b.abs().max().clamp_min(1e-14))
        pairs[left+"__"+right] = metrics
    end.record()
    torch.cuda.synchronize()
    resources = {"wall_seconds": time.perf_counter()-wall, "process_cpu_seconds": time.process_time()-cpu,
                 "cuda_event_span_seconds_including_host_gaps": start.elapsed_time(end)/1000,
                 "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
                 "process_wall_including_imports": time.perf_counter()-PW, "process_cpu_including_imports": time.process_time()-PC}
    output = ROOT/"results/mixed_feasibility"/args.output
    if output.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Output must be one directory name")
    output.mkdir(exist_ok=False)
    dump(output/"comparison.json", {"pairs": pairs, "resources": resources, "common_config": config})
    print(json.dumps({"pairs": pairs, "resources": resources}), flush=True)


if __name__ == "__main__":
    main()
