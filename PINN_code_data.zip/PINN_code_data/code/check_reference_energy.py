"""GPU work/storage/dissipation audit of accepted independent reference paths.

Pressure and displacement interpolate linearly between accepted endpoints;
Simpson integration is exact for follower work on that interpolated path.
Endpoint plastic correction work is first-order, not an exact path integral.
No energy result is used as the nonassociated equilibrium objective.
"""
import os
import time
PW, PC = time.perf_counter(), time.process_time()
for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
             "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
import argparse
import hashlib
import json
from pathlib import Path
import torch
import dp_material as dp
from mixed_geometry import geometry_from_config, cofactor_normal
from mixed_reference import embed

ROOT = Path(__file__).resolve().parents[1]


def elastic_log(f, cp):
    pieces = []
    minimum, maximum = float("inf"), 0.
    for ff, pp in zip(f.split(4096), cp.split(4096)):
        value, vector = torch.linalg.eigh(ff @ torch.linalg.inv(pp) @ ff.transpose(-1, -2))
        if not bool((value > 0).all()):
            raise ValueError("Invalid elastic spectrum in energy audit")
        pieces.append((vector*(.5*value.log())[:, None, :]) @ vector.transpose(-1, -2))
        minimum = min(minimum, float(value.min().sqrt()))
        maximum = max(maximum, float(value.max().sqrt()))
    return torch.cat(pieces), minimum, maximum


def energy(h, material):
    trace = h.diagonal(dim1=-2, dim2=-1).sum(-1)
    deviator = h-trace[:, None, None]*torch.eye(3, device=h.device, dtype=h.dtype)/3
    psi = material.shear*deviator.square().sum((-2, -1))+.5*material.bulk*trace.square()
    tau = 2*material.shear*deviator+material.bulk*trace[:, None, None]*torch.eye(3, device=h.device, dtype=h.dtype)
    return psi, tau


def audit(name):
    folder = ROOT/"results/mixed_feasibility"/name
    config = json.loads((folder/"config.json").read_text(encoding="utf-8"))
    material = dp.DPParameters.from_young_poisson(**config["material"])
    f0 = dp.elastic_precompression(material, torch.tensor(config["p0"], device=config["device"], dtype=torch.float64))[0]
    mesh = geometry_from_config(config, ROOT, f0, mesh=config["reference_mesh"])
    def deformation(u, q):
        return embed(f0[:2, :2]+torch.einsum("qai,qaj->qij", u[q.conn], q.grad))
    previous_u = torch.zeros_like(mesh.nodes)
    previous_cp = torch.eye(3, device=f0.device).expand(len(mesh.volume.x), 3, 3).clone()
    old_h = elastic_log(f0.expand_as(previous_cp), previous_cp)[0]
    old_psi = energy(old_h, material)[0]
    old_fw = f0.expand(len(mesh.boundary.x), 3, 3)
    previous_pressure = config["p0"]
    totals = torch.zeros(3, device=f0.device)
    rows = []
    for path in sorted(folder.glob("accepted_*.pt")):
        saved = torch.load(path, map_location=f0.device, weights_only=True)
        if not torch.equal(saved["coordinates"], mesh.volume.x):
            raise ValueError("Energy integration points differ from material history")
        u, cp, pressure = saved["u"], saved["cp"], saved["pressure"]
        f, fw = deformation(u, mesh.volume), deformation(u, mesh.boundary)
        h, low, high = elastic_log(f, cp)
        trial_h = elastic_log(f, previous_cp)[0]
        psi, tau = energy(h, material)
        plastic_work = (tau*(trial_h-h)).sum((-2, -1))
        v, b = mesh.volume, mesh.boundary
        storage = ((psi-old_psi)*v.weight).sum()
        dissipation = (plastic_work*v.weight).sum()
        du = (b.shape[:, :, None]*(u-previous_u)[b.conn]).sum(1)
        force0 = -previous_pressure*cofactor_normal(old_fw, b.normal)[:, :2]
        force1 = -pressure*cofactor_normal(fw, b.normal)[:, :2]
        forcem = -.5*(pressure+previous_pressure)*cofactor_normal(.5*(fw+old_fw), b.normal)[:, :2]
        work = (((force0+4*forcem+force1)/6*du).sum(-1)*b.weight).sum()
        totals += torch.stack((work, storage, dissipation))
        rows.append({"pressure_ratio": pressure/config["p0"], "external_work": float(work),
            "stored_energy_change": float(storage), "endpoint_plastic_work": float(dissipation),
            "work_storage_dissipation_gap": float(work-storage-dissipation),
            "minimum_point_endpoint_plastic_work": float(plastic_work.min()),
            "elastic_stretch_min": low, "elastic_stretch_max": high})
        previous_u, previous_cp, previous_pressure = u, cp, pressure
        old_psi, old_fw = psi, fw
    gap = totals[0]-totals[1]-totals[2]
    return {"run": name, "records": rows, "totals": {"external_work": float(totals[0]),
        "stored_energy_change": float(totals[1]), "endpoint_plastic_work": float(totals[2]),
        "work_storage_dissipation_gap": float(gap),
        "gap_over_external_work_magnitude": float(gap/totals[0].abs()) if totals[0].abs() > 1e-14 else None},
        "units": "p0*m^2 per natural out-of-plane unit thickness",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.cuda.set_device(0)
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    wall, cpu = time.perf_counter(), time.process_time()
    start.record()
    data = []
    for name in args.runs:
        item = audit(name)
        data.append(item)
        print(json.dumps({"run": name, **item["totals"]}), flush=True)
    end.record()
    torch.cuda.synchronize()
    resources = {"wall_seconds": time.perf_counter()-wall, "process_cpu_seconds": time.process_time()-cpu,
        "cuda_event_span_seconds_including_host_gaps": start.elapsed_time(end)/1000,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "process_wall_including_imports": time.perf_counter()-PW, "process_cpu_including_imports": time.process_time()-PC,
        "device": "cuda:0", "dtype": "torch.float64", "tensor_threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads()}
    out = ROOT/"results/mixed_feasibility"/args.output
    if out.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Output must be one directory name")
    out.mkdir(exist_ok=False)
    (out/"energy.json").write_text(json.dumps({"runs": data, "resources": resources}, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps(resources), flush=True)


if __name__ == "__main__":
    main()
