"""Original reporting-grid and constitutive field-export functions."""
from pathlib import Path
from types import SimpleNamespace
import torch
import current_traction as ct
import dp_material as dp
from horseshoe_geometry import HorseshoeWall
from mixed_geometry import gauss
ROOT = Path(__file__).resolve().parents[1]
def collar_points(config, f0, panels, radial_panels, order):
    wall = HorseshoeWall.from_json(ROOT / config["geometry"], device=f0.device, scale=1/f0[0, 0])
    delta = config["collar_precompressed_m"] / f0[0, 0]
    g, gw = gauss(order, f0.device)
    arcs = torch.cat([torch.full((n * order,), i, device=f0.device, dtype=torch.long)
                      for i, n in enumerate(panels)])
    fractions = torch.cat([((torch.arange(n, device=f0.device)[:, None] + g) / n).flatten()
                           for n in panels])
    lengths = wall.radii * wall.sweeps
    arc_weights = torch.cat([gw.repeat(n) * lengths[i] / n for i, n in enumerate(panels)])
    xw, normal = wall.sample(arcs, fractions)
    levels = delta * torch.linspace(0, 1, radial_panels + 1, device=f0.device).square()
    distances = (levels[:-1, None] + levels.diff()[:, None] * g).flatten()
    dw = (levels.diff()[:, None] * gw).flatten()
    na, nr = len(xw), len(distances)
    xv = (xw[:, None, :] - distances[None, :, None] * normal[:, None, :2]).reshape(-1, 2)
    weights = (arc_weights[:, None] * dw * (1 + distances / wall.radii[arcs, None])).flatten()
    points = torch.cat((xv, xw))
    normals = torch.cat((normal.repeat_interleave(nr, 0), normal))
    d = torch.cat((distances.repeat(na), torch.zeros(na, device=f0.device)))
    arc_index = torch.cat((arcs.repeat_interleave(nr), arcs))
    projection = wall.project(points)
    errors = {"projection_distance_max_m": float((projection.distance - d).abs().max()),
              "projection_normal_max": float((projection.normal - normals).abs().max()),
              "area_quadrature_absolute_error_m2": float((weights.sum() - lengths.sum() * delta - torch.pi * delta.square()).abs()),
              "arc_quadrature_absolute_error_m": float((arc_weights.sum() - lengths.sum()).abs())}
    if max(errors.values()) > 1e-9:
        raise ValueError("Normal-offset geometry/measure check failed: " + repr(errors))
    mesh = SimpleNamespace(wall=wall, radius=config["outer_widths"] * 13.46 / f0[0, 0],
        volume=SimpleNamespace(x=xv, weight=weights),
        boundary=SimpleNamespace(x=xw, normal=normal, weight=arc_weights))
    r = d / delta
    raw = {"x_natural_m": points, "reference_normal": normals, "distance_natural_m": d,
           "arc_index": arc_index, "arc_fraction": torch.cat((fractions.repeat_interleave(nr), fractions)),
           "chi": 1 - 3 * r.square() + 2 * r.pow(3), "eta": (1 - r).square(),
           "volume_weights_m2": weights, "wall_weights_m": arc_weights,
           "radial_distances_natural_m": distances, "radial_weights_m": dw,
           "angular_weights_m": arc_weights, "angular_arc_index": arcs,
           "volume_shape": [na, nr], "volume_count": len(xv), "delta_natural_m": float(delta)}
    return mesh, raw, errors

def predictor(f, cp, kappa, material):
    b = dp.sym(f @ torch.linalg.solve(cp, f.transpose(-1, -2)))
    log = .5 * dp.log_spd_plane(b)
    tau, _ = dp.hencky_response(log, material)
    p, q = dp.invariants(tau)
    strength = torch.linalg.det(f) * material.strength(kappa)
    return {"f_tau": q - material.alpha * p - strength,
            "q_tau": q, "p_tau": p, "J_strength": strength}

def snapshot(f, u, cp_old, kappa_old, trial, pressure, old_pressure, material, sigma_net=None):
    item = {"pressure_ratio": pressure, "previous_pressure_ratio": old_pressure,
            "F": f.detach(), "u_m": u.detach(), "cp_old": cp_old.detach().clone(),
            "kappa_old": kappa_old.detach().clone(), "cp": trial.cp.detach().clone(),
            "kappa": trial.kappa.detach().clone(), "sigma_return": trial.sigma.detach(),
            "branch": trial.branch.detach(), "native_predictor": predictor(f, cp_old, kappa_old, material)}
    item["native_delta_kappa"] = item["kappa"] - item["kappa_old"]
    smooth = trial.branch == 1
    if bool(smooth.any()):
        denominator = 3 * material.shear + material.alpha * material.bulk * material.beta + torch.linalg.det(f) * material.hardening
        error = (item["native_delta_kappa"][smooth] - item["native_predictor"]["f_tau"][smooth] / denominator[smooth]).abs().max()
        item["native_drive_return_check_max"] = float(error)
        if float(error) > 1e-11:
            raise ValueError("Native predictor does not reproduce its smooth return increment")
    else:
        item["native_drive_return_check_max"] = 0.
    if sigma_net is not None:
        item["sigma_network"] = sigma_net.detach()
    return item

def evaluate_conditional_endpoint(model, old, grid, material, pressure, old_step, sigma_anchor=None):
    """Evaluate one endpoint on archived points with its fixed accepted old state."""
    x = grid["x_natural_m"]
    parts = []
    for left in range(0, len(x), 4096):
        right = min(left + 4096, len(x))
        u, f, aw, ao = model.deformation(x[left:right], graph=False)
        parts.append((u, f, aw, ao))
    u, f, aw, ao = [torch.cat([part[i] for part in parts]) for i in range(4)]
    state = dp.MaterialState(old["cp"], old["kappa"], old_step)
    trial = dp.evaluate(f, state, material)
    if sigma_anchor is not None and (sigma_anchor.shape != f.shape or sigma_anchor.requires_grad):
        raise ValueError("Conditional stress anchor must be fixed and match the evaluation points")
    stresses = []
    for left in range(0, len(x), 4096):
        right = min(left + 4096, len(x))
        selected = slice(left, right)
        stresses.append(ct.blended_stress(f[selected], aw[selected], ao[selected],
            grid["distance_natural_m"][selected], grid["reference_normal"][selected],
            pressure * model.p0, model.delta, basis=model.basis, initial_f=model.f0.expand_as(f[selected]),
            constitutive_increment=None if sigma_anchor is None else trial.sigma[selected]-sigma_anchor[selected]))
    sigma = torch.cat(stresses)
    return snapshot(f, u, old["cp"], old["kappa"], trial, pressure,
                    old["pressure_ratio"], material, sigma)
