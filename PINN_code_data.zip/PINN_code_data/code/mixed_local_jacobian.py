"""Exploit point locality without changing the complete mixed Jacobian."""
import copy
import torch
import dp_material as dp
import current_traction as ct


def fill_constitutive_rows(jacobian, residual, problem, parameters, emit, point_batch=32):
    pool = problem.pool
    if pool.history.state is not problem.old_state:
        raise ValueError("Local Jacobian cannot cross a material-history commit")
    prefix = 2*len(pool.mesh.free)+2*len(pool.tests.scale)
    count = len(pool.x)
    end = prefix+4*count
    local = copy.copy(problem)
    fields = ("z", "zgrad", "envelope", "envgrad", "direct", "directgrad", "radial_stress")
    batches = 0
    for left in range(0, count, point_batch):
        right = min(count, left+point_batch)
        selected = slice(left, right)
        for name in fields:
            value = getattr(problem, name)
            setattr(local, name, None if value is None else value[selected])
        if problem.displacement_cache is not None:
            local.displacement_cache = {name: value[selected] for name, value in problem.displacement_cache.items()}
        old = dp.MaterialState(problem.old_state.cp[selected], problem.old_state.kappa[selected], problem.old_state.step)
        anchor = None if problem.return_anchor is None else problem.return_anchor[selected]
        def point_residual(weights):
            f, aw, ao = local.fields(weights)
            trial = dp.evaluate(f, old, problem.material)
            stress = ct.blended_stress(f, aw, ao, pool.distance[selected], pool.normal[selected], problem.pressure,
                problem.model.delta, basis=problem.model.basis, initial_f=problem.model.f0.expand_as(f),
                constitutive_increment=None if anchor is None else trial.sigma-anchor)
            difference = (stress-trial.sigma)/problem.model.p0
            vector = torch.stack((difference[:, 0, 0], 2**.5*difference[:, 0, 1],
                                  difference[:, 1, 1], difference[:, 2, 2]), -1)*problem.consistency_weights[selected, None]
            if problem.controls.get("normalize_residual_by_load", False):
                vector = vector/problem.model.load_amplitude
            return vector.flatten()
        values, backward = torch.func.vjp(point_residual, parameters)
        row_slice = slice(prefix+4*left, prefix+4*right)
        if not torch.allclose(values, residual[row_slice], rtol=1e-10, atol=1e-12):
            raise ValueError("Point-block residual differs from the full mixed residual")
        directions = torch.eye(values.numel(), device=parameters.device, dtype=parameters.dtype)
        jacobian[row_slice] = torch.vmap(lambda vector: backward(vector)[0])(directions).detach()
        batches += 1
        if batches % 32 == 0:
            emit({"phase": "point_block_jacobian", "points": right, "total_points": count,
                  "point_backward_batches": batches})
    global_rows = torch.cat((torch.arange(prefix, device=parameters.device),
                             torch.arange(end, len(residual), device=parameters.device)))
    return global_rows, batches
