"""Original expanded-grid and trial-field reconstruction formulas."""
import time
from pathlib import Path
import numpy as np
import torch
import dp_material as dp
OUT = Path(__file__).resolve().parents[1] / 'figures/pinn_mechanism_endpoints_01'


def export_expanded(p, prefix_fields, field, cfg, f0, material):
    start = time.perf_counter()
    device = f0.device
    radius = cfg['outer_widths'] * 13.46 / float(f0[0, 0])
    prefix = {'pressures': [item.pressure for item in prefix_fields]}
    na, nr, nv = 736, 96, 70656
    wall = p["x_natural_m"][nv:]
    normal = p["reference_normal"][nv:, :2]
    # Midpoint display boundaries end at d=35 m. All new values are evaluated
    # at these coordinates; the original inner-band coordinates are copied.
    outer_edges = np.geomspace(1 / p["f0"][0, 0], 35., 81)
    outer_depth = .5 * (outer_edges[:-1] + outer_edges[1:])
    new_x = wall[:, None, :] - outer_depth[None, :, None] * normal[:, None, :]
    x = np.concatenate((p["x_natural_m"][:nv].reshape(na, nr, 2), new_x), axis=1)
    nrad = x.shape[1]
    x = np.concatenate((x.reshape(-1, 2), wall))
    assert np.linalg.norm(x, axis=1).max() < radius
    old_ids = np.concatenate(((np.arange(na)[:, None] * nrad + np.arange(nr)).ravel(),
                              np.arange(na * nrad, len(x))))
    reverse = np.full(len(x), -1, dtype=int)
    reverse[old_ids] = np.arange(len(p["x_natural_m"]))
    np.testing.assert_array_equal(x[old_ids], p["x_natural_m"])
    outputs = {"x_natural_m": x, "radial_distances_natural_m": np.r_[p["radial_distances_natural_m"], outer_depth],
               "outer_radial_edges_m": outer_edges, "volume_shape": np.array([na, nrad]),
               "f0": p["f0"], "pressures": p["pressures"], "original_point_indices": old_ids}
    retained = ("u_m", "F", "sigma_return", "kappa")
    parts = {f"e{j}_{key}": [] for j in range(4) for key in retained}
    errors = {f"e{j}_{key}": 0. for j in range(4) for key in (*retained, "cp")}
    prefix_plastic = {str(v): 0. for v in prefix["pressures"]}
    for left in range(0, len(x), 4096):
        right = min(left + 4096, len(x))
        points = torch.as_tensor(x[left:right], device=device)
        state = dp.MaterialState.virgin((len(points),), device=device)
        # Virgin initialization occurs once, before the first accepted pressure.
        for pressure, previous in zip(prefix["pressures"][:-1], prefix_fields[:-1]):
            _, f = previous.jet(points)
            trial = dp.evaluate(f, state, material)
            state = dp.commit_state(state, trial)
            prefix_plastic[str(pressure)] = max(prefix_plastic[str(pressure)], float(state.kappa.max()))
        for index, (u, f) in enumerate(field.iter_jets(points)):
            trial = dp.evaluate(f, state, material)
            if index == 0:
                prefix_plastic["0.725"] = max(prefix_plastic["0.725"], float(trial.kappa.max()))
            else:
                j = index - 1
                values = dict(u_m=u, F=f, sigma_return=trial.sigma, kappa=trial.kappa, cp=trial.cp)
                subset = reverse[left:right] >= 0
                for key, value in values.items():
                    host = value.detach().cpu().numpy()
                    if key in retained:
                        parts[f"e{j}_{key}"].append(host)
                    if subset.any():
                        difference = np.max(np.abs(host[subset] - p[f"e{j}_{key}"][reverse[left:right][subset]]))
                        errors[f"e{j}_{key}"] = max(errors[f"e{j}_{key}"], float(difference))
            state = dp.commit_state(state, trial)
        if left % (4096 * 8) == 0:
            print(f"Historical replay: {right}/{len(x)} points, {time.perf_counter()-start:.1f} s", flush=True)
    assert max(errors.values()) < 1e-11, errors
    outputs.update({key: np.concatenate(value) for key, value in parts.items()})
    # Derived near-wall fields use the archived accepted endpoint and own parent.
    drive_error = volume_error = 0.
    for j in range(4):
        f = torch.as_tensor(p[f"e{j}_F"], device=device)
        old = dp.MaterialState(torch.as_tensor(p[f"e{j}_cp_old"], device=device),
                               torch.as_tensor(p[f"e{j}_kappa_old"], device=device), j + 9)
        trial = dp.evaluate(f, old, material)
        tau_trial, _ = dp.hencky_response(trial.trial_log, material)
        pm, q = dp.invariants(tau_trial)
        strength = torch.linalg.det(f) * material.strength(old.kappa)
        fhat = f @ torch.linalg.inv(f0)
        hu = .5 * dp.log_spd_plane(dp.sym(fhat @ fhat.transpose(-1, -2)))
        logjp = .5 * torch.log(torch.linalg.det(torch.as_tensor(p[f"e{j}_cp"], device=device)))
        derived = dict(trial_q=q, trial_alpha_p=material.alpha * pm, trial_strength=strength,
                       trial_f=q - material.alpha * pm - strength,
                       log_volume=torch.log(torch.linalg.det(f) / torch.linalg.det(f0)),
                       equivalent_hencky=torch.sqrt(2 / 3 * dp.dev(hu).square().sum((-2, -1))), log_Jp=logjp)
        for key, value in derived.items():
            outputs[f"band_e{j}_{key}"] = value.cpu().numpy()
        drive_error = max(drive_error, float(np.max(np.abs(trial.delta_lambda.cpu().numpy() - p[f"e{j}_dk"]))))
        volume_error = max(volume_error, float(np.max(np.abs(logjp.cpu().numpy() - material.beta * p[f"e{j}_kappa"]))))
    assert drive_error < 1e-11 and volume_error < 1e-11
    np.savez_compressed(OUT / 'expanded_fields.npz', **outputs)
