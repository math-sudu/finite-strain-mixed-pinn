"""Recover only saved, completed dense Newton iterations after interruption.

The unaccepted network is an optimizer iterate, never a material history.
The runner first replays and validates every accepted material state. A
recovered step spends only its remaining Newton/L-BFGS budget; incomplete
Jacobian work is repeated and remains included in measured resource bounds.
"""
import hashlib
import json
from pathlib import Path
import torch
from mixed_pinn import checks


def file_digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def coordinate_binding(candidate):
    """Bind a fixed metric to one physical interval and its optimizer settings."""
    from mixed_history import content_identity
    return {"pressure": candidate["pressure"],
        "parent_field_id": candidate["parent_field_reference"]["field_id"],
        "context_source": candidate["context_source"],
        "parent_histories": [content_identity(candidate[key]) for key in
                             ("parent_train_history", "parent_validation_history")],
        "optimizer_settings": candidate["optimizer_settings"]}


class FixedCoordinateStore:
    """Publish one immutable metric dependency before any referring candidate."""
    def __init__(self, directory):
        self.directory = Path(directory)
        self.reference = self.signature = self.binding = None

    def externalize(self, candidate):
        from mixed_history import content_identity
        state = candidate.get("optimizer_state")
        coordinates = None if state is None else state.get("coordinates")
        if coordinates is None or coordinates.get("factor") is None:
            return candidate
        factor = coordinates["factor"]
        signature = (factor.data_ptr(), factor._version, tuple(factor.shape), factor.dtype, factor.device)
        binding = coordinate_binding(candidate)
        if self.reference is None:
            core = {"schema_version": 1, "binding": binding, "spec": coordinates["spec"],
                "scale": coordinates["scale"], "factor": factor}
            metric_id = content_identity(core)
            payload = dict(core, metric_id=metric_id)
            path = self.directory/("fixed_metric_"+metric_id+".pt")
            if path.exists():
                raise ValueError("A new interval metric must not overwrite an existing dependency")
            temporary = path.with_suffix(".tmp.pt")
            torch.save(payload, temporary)
            temporary.replace(path)
            self.reference = {"file": path.name, "sha256": file_digest(path), "metric_id": metric_id,
                "binding_id": content_identity(binding), "bytes": path.stat().st_size}
            self.signature, self.binding = signature, binding
        elif signature != self.signature or binding != self.binding:
            raise ValueError("Immutable metric or its interval binding changed during checkpointing")
        path = self.directory/self.reference["file"]
        if not path.is_file() or path.stat().st_size != self.reference["bytes"]:
            raise ValueError("Fixed metric dependency disappeared or changed size")
        packed = dict(coordinates, factor=None, factor_reference=dict(self.reference))
        return dict(candidate, optimizer_state=dict(state, coordinates=packed))


def load_configuration_candidate(path, device, optimizer_settings=None):
    """Read inline legacy factors or strictly verified external metric references."""
    from mixed_history import content_identity
    path = Path(path)
    candidate = torch.load(path, map_location=device, weights_only=True)
    state = candidate.get("optimizer_state")
    coordinates = None if state is None else state.get("coordinates")
    if coordinates is None or "factor_reference" not in coordinates:
        return candidate
    reference = coordinates["factor_reference"]
    dependency = (path.parent/reference["file"]).resolve()
    binding = coordinate_binding(candidate)
    if (dependency.parent != path.parent.resolve() or coordinates.get("factor") is not None
            or (optimizer_settings is not None and candidate["optimizer_settings"] != optimizer_settings)
            or content_identity(binding) != reference["binding_id"]
            or dependency.stat().st_size != reference["bytes"] or file_digest(dependency) != reference["sha256"]):
        raise ValueError("Fixed metric dependency path, checksum or interval binding differs")
    saved = torch.load(dependency, map_location=device, weights_only=True)
    core = {key: value for key, value in saved.items() if key != "metric_id"}
    if (saved["schema_version"] != 1 or saved["metric_id"] != reference["metric_id"]
            or content_identity(core) != reference["metric_id"] or saved["binding"] != binding
            or saved["spec"] != coordinates["spec"] or not torch.equal(saved["scale"], coordinates["scale"])):
        raise ValueError("Fixed metric identity, parameter order or scale differs")
    coordinates["factor"] = saved["factor"]
    coordinates.pop("factor_reference")
    return candidate


def install_configuration_candidate(saved, model, train, validation, pressure):
    """Install an uncommitted field only after matching its entire parent state."""
    from mixed_history import content_identity
    context = model.displacement_context
    if (context is None or context.version != 2 or saved.get("accepted") is not False
            or saved.get("field_schema_version") != 2 or saved["pressure"] != pressure
            or saved["parent_field_reference"]["field_id"] != context.parent.field_id
            or saved["context_source"] != context.source):
        raise ValueError("Candidate pressure or complete parent configuration differs")
    for pool, key in ((train, "parent_train_history"), (validation, "parent_validation_history")):
        context.check_history(pool.history)
        if content_identity(saved[key]) != content_identity(pool.history.checkpoint()):
            raise ValueError("Candidate belongs to another accepted material history")
    model.load_state_dict(saved["network"])
    context.check_model(model)


def read_interrupted(folder, method):
    if (folder/"result.json").exists():
        raise ValueError("Interrupted recovery requires a run without a final result")
    record = json.loads((folder/"interruption.json").read_text(encoding="utf-8"))
    if record["method"] != method or record["status"] not in (
            "process_absent_after_host_restart", "process_absent_cause_unknown"):
        raise ValueError("Interruption metadata or method mismatch")
    return {"method": method, "records": json.loads((folder/"path.json").read_text(encoding="utf-8")),
            "resources": record["measured_lower_bounds"]}


def pending_from_records(config, records):
    """Rebuild adaptive pressure queue including recorded rejected steps."""
    pending = list(config["pressures"])
    previous = 1.
    for row in records:
        if not pending or abs(pending.pop(0)-row["pressure_ratio"]) > 1e-12:
            raise ValueError("Saved pressure attempts disagree with the adaptive queue")
        pressure = row["pressure_ratio"]
        if row["accepted"]:
            previous = pressure
        elif previous-pressure >= 2*config["minimum_pressure_increment"]-1e-12:
            pending[0:0] = [round(.5*(previous+pressure), 12), pressure]
        else:
            pending = []
    return pending


def restore_optimizer(folder, config, model, train, validation, initial, material, pressure):
    metadata = json.loads((folder/"interruption.json").read_text(encoding="utf-8"))
    root = Path(__file__).resolve().parents[1]
    changes = {}
    recovery_files = {"mixed_pinn.py", "mixed_full_newton.py", "run_mixed_feasibility.py", "mixed_recovery.py"}
    for old in (folder/"sources").iterdir():
        current = root/("tests" if old.name.startswith("test_") else "code")/old.name
        if old.name == Path(config["geometry"]).name:
            current = root/config["geometry"]
        old_hash = hashlib.sha256(old.read_bytes()).hexdigest()
        current_hash = hashlib.sha256(current.read_bytes()).hexdigest()
        if old_hash != current_hash:
            if old.name not in recovery_files:
                raise ValueError("A non-recovery source changed: "+old.name)
            changes[old.name] = {"interrupted_sha256": old_hash, "recovery_sha256": current_hash}
    name = metadata["candidate"]
    path = folder/name
    if path.resolve().parent != folder.resolve():
        raise ValueError("Recovery candidate escapes the source run")
    if hashlib.sha256(path.read_bytes()).hexdigest() != metadata["candidate_sha256"]:
        raise ValueError("Interrupted candidate changed")
    saved = torch.load(path, map_location=model.f0.device, weights_only=True)
    if "field_reference" in saved or "configuration_displacement_version" in saved.get("network", {}):
        raise ValueError("Conditional configuration fields do not support generic optimizer recovery")
    if saved["accepted"] or abs(saved["pressure"]-pressure) > 1e-12:
        raise ValueError("Recovery requires the uncommitted next pressure candidate")
    if saved["old_accepted_file"] != f"accepted_{train.history.state.step-1:03d}.pt":
        raise ValueError("Candidate is bound to a different accepted prefix")
    for pool, key in ((train, "training"), (validation, "validation")):
        if saved[key+"_state_step"] != pool.history.state.step or saved[key+"_identity"] != pool.history.key:
            raise ValueError("Candidate point identity or history step mismatch")
    events = [json.loads(line) for line in (folder/"events.jsonl").read_text(encoding="utf-8").splitlines()]
    report = saved["physical_report"]
    matching = []
    for i, event in enumerate(events):
        if event.get("phase") == "physical_validation" and all(event.get(k) == v for k, v in report.items()):
            matching.append(i)
    if len(matching) != 1:
        raise ValueError("Candidate has no unique matching physical-validation event")
    boundary = matching[0]
    update = events[boundary-1]
    if update.get("phase") != "full_newton" or not update["accepted_parameter_step"]:
        raise ValueError("Recovery is supported only after a completed dense Newton parameter step")
    if any(e.get("phase") in ("full_newton", "adam", "lbfgs", "pinn_step") for e in events[boundary+1:]):
        raise ValueError("Later optimization or commit events make this candidate stale")
    if update["linear_solver"] != "dense" or report["evaluations"] != config["optimizer"]["adam_steps"]:
        raise ValueError("Recovery requires the completed Adam phase followed by dense Newton")
    progress = {"phase": "full_newton", "iteration": update["iteration"],
        "next_damping": update["next_damping"],
        "counts": {k: v for k, v in update.items() if k.startswith("full_")}}
    if "optimizer_checkpoint" in report and report["optimizer_checkpoint"] != progress:
        raise ValueError("Optimizer checkpoint disagrees with its event")
    original = {key: value.detach().clone() for key, value in model.state_dict().items()}
    errors = []
    try:
        model.load_state_dict(saved["network"])
        for pool, key in ((train, "training_physics"), (validation, "validation")):
            data = pool.evaluate(model, pressure, material, initial, graph=False)
            data["pressure"] = pressure
            current = checks(pool, data, model, config, initial)
            if current["accepted"] != report[key]["accepted"] or current["failed_checks"] != report[key]["failed_checks"]:
                raise ValueError("Recovered candidate changed its physical verdict")
            for name, value in current.items():
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    errors.append(abs(value-report[key][name]))
        if max(errors, default=0.) > 1e-10:
            raise ValueError("Recovered candidate fields do not reproduce the saved checks")
    finally:
        model.load_state_dict(original)
    return {"network": saved["network"], "optimizer_checkpoint": progress,
        "training_counts": {k: report[k] for k in ("evaluations", "invalid_updates", "physical_checks")},
        "verification": {"candidate_sha256": metadata["candidate_sha256"],
            "recovery_orchestration_source_changes": changes,
            "completed_newton_iterations": progress["iteration"],
            "remaining_newton_iterations": config["optimizer"]["full_newton_steps"]-progress["iteration"],
            "next_damping": progress["next_damping"], "physical_metric_max_difference": max(errors, default=0.),
            "candidate_material_state_committed": False}}
