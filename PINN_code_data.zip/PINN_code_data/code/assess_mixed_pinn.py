"""Independent field/response assessment of accepted PINN checkpoints on GPU.

Runs only after training. It reconstructs reference material histories at the
PINN validation coordinates and never supplies labels or checkpoint choices.
"""
import os
import time
PW, PC = time.perf_counter(), time.process_time()
for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
             "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import argparse
import hashlib
import json
from pathlib import Path
import torch
import dp_material as dp
from mixed_geometry import geometry_from_config
from mixed_reference_sampling import ReferenceProbe
from mixed_pinn import MixedNet, EvaluationPool

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def assess(run, reference, candidate_name=None):
    folder = ROOT/"results/mixed_feasibility"/run
    refdir = ROOT/"results/mixed_feasibility"/reference
    config, refconfig = read(folder/"config.json"), read(refdir/"config.json")
    for key in ("geometry", "p0", "material", "outer_widths"):
        if config[key] != refconfig[key]:
            raise ValueError("PINN and reference must describe the same boundary value problem: "+key)
    result, refresult = read(folder/"result.json"), read(refdir/"result.json")
    if "method" not in result:
        events = [json.loads(line) for line in (folder/"events.jsonl").read_text(encoding="utf-8").splitlines()]
        result["method"] = next(item["method"] for item in events if item.get("phase") == "start_pressure")
        result["records"] = read(folder/"path.json")
    if (folder/"invalidation.json").exists():
        raise ValueError("An invalidated diagnostic run cannot be assessed as an accepted path")
    material = dp.DPParameters.from_young_poisson(**config["material"])
    f0, _, initial = dp.elastic_precompression(material, torch.tensor(config["p0"], device=config["device"], dtype=torch.float64))
    valmesh = geometry_from_config(config, ROOT, f0, mesh=config["validation_mesh"])
    refmesh = geometry_from_config(refconfig, ROOT, f0, mesh=refconfig["reference_mesh"])
    probe = ReferenceProbe(refmesh, valmesh, f0, material)
    pool = EvaluationPool("validation", valmesh, config["p0"])
    model = MixedNet(config, f0, initial, valmesh.radius, result["method"])
    accepted_paths = sorted(folder.glob("accepted_*.pt"))
    candidate = None
    if candidate_name is not None:
        candidate_path = folder/candidate_name
        if candidate_path.parent != folder or not candidate_name.startswith("candidate_"):
            raise ValueError("Candidate must be a saved candidate filename within the run")
        candidate = torch.load(candidate_path, map_location=f0.device, weights_only=True)
        if candidate["accepted"]:
            raise ValueError("Candidate diagnostics require an explicitly uncommitted checkpoint")
        old = candidate["old_accepted_file"]
        if old is None:
            accepted_paths = []
        else:
            names = [p.name for p in accepted_paths]
            if old not in names:
                raise ValueError("Candidate old accepted state is missing")
            accepted_paths = accepted_paths[:names.index(old)+1]
    targets = {round(torch.load(p, map_location=f0.device, weights_only=True)["pressure"], 12) for p in accepted_paths}
    if candidate is not None:
        targets.add(round(candidate["pressure"], 12))
    references = {}
    for path in sorted(refdir.glob("accepted_*.pt")):
        saved = torch.load(path, map_location=f0.device, weights_only=True)
        f, u, trial = probe.evaluate(saved["u"])
        probe.commit(trial)
        key = round(saved["pressure"], 12)
        if key in targets:
            references[key] = {"sigma": trial.sigma, "kappa": trial.kappa,
                "wall_u": saved["wall_displacement_768"],
                "response": next(r for r in refresult["records"] if round(r["pressure_ratio"]*config["p0"], 12) == key)}
    rows = []
    ids = torch.arange(6, device=f0.device).repeat_interleave(128)
    fraction = torch.arange(128, device=f0.device, dtype=f0.dtype).repeat(6)/128
    wallx = valmesh.wall.sample(ids, fraction)[0]
    wallweight = valmesh.wall.radii[ids]*valmesh.wall.sweeps[ids]/128
    def weighted_relative(error, field, weight):
        axes = tuple(range(1, field.ndim))
        numerator = (error.square().sum(axes)*weight).sum()
        denominator = (field.square().sum(axes)*weight).sum()
        return float((numerator/denominator).sqrt()) if denominator > 1e-28 else None
    evaluation_paths = accepted_paths+([candidate_path] if candidate is not None else [])
    for path in evaluation_paths:
        saved = torch.load(path, map_location=f0.device, weights_only=True)
        diagnostic = candidate is not None and path == candidate_path
        model.load_state_dict(saved["network"])
        if not torch.equal(model.f0, f0):
            raise ValueError("Checkpoint changed the precompressed natural reference")
        p = saved["pressure"]
        data = pool.evaluate(model, p, material, initial, graph=False)
        tr = data["trial"]
        key = round(p, 12)
        if diagnostic:
            if (saved["validation_identity"] != pool.history.key
                    or saved["validation_state_step"] != pool.history.state.step):
                raise ValueError("Candidate is bound to a different validation pool or old state")
            replay_error = None
            observed = saved["physical_report"]["validation"]
        else:
            state = saved["validation_history"]
            pool.history.check(state["coordinates"], state["ids"], pool.history.state.step)
            if (state["identity_sha256"] != pool.history.key or state["step"] != pool.history.state.step+1
                    or state["pressures"] != pool.history.pressures+[p]):
                raise ValueError("Accepted state has a different material-point identity or pressure history")
            replay_error = max(float((state["cp"]-tr.cp).abs().max()), float((state["kappa"]-tr.kappa).abs().max()))
            if replay_error > 1e-10:
                raise ValueError("Accepted PINN material history did not reproduce")
            if not any(r["accepted"] and round(r["pressure_ratio"]*config["p0"], 12) == key for r in result["records"]):
                raise ValueError("Checkpoint lacks an accepted physical-step record")
            # Replay an already accepted step; candidates never reach this commit.
            pool.history.state = dp.commit_state(pool.history.state, tr)
            pool.history.pressures.append(p)
            observed = next(r["validation"] for r in result["records"] if r["accepted"] and round(r["pressure_ratio"]*config["p0"], 12) == key)
        row = {"pressure_ratio": p/config["p0"], "history_replay_max_error": replay_error,
               "uncommitted_candidate": diagnostic, "old_or_replayed_state_step": pool.history.state.step}
        if key not in references:
            row["reference_available"] = False
            rows.append(row)
            continue
        ref = references[key]
        nv, weight = pool.nv, valmesh.volume.weight
        near = pool.distance[:nv] < 2*model.delta
        sig, sigref = tr.sigma[:nv][near], ref["sigma"][:nv][near]
        sigma_diff = sig-sigref
        row["reference_available"] = True
        row["material_stress_relative_l2_near_wall"] = weighted_relative(sigma_diff, sigref, weight[near])
        increment = sigref-initial.sigma
        row["material_stress_increment_relative_l2_near_wall"] = weighted_relative(sigma_diff, increment, weight[near]) if p != config["p0"] else None
        row["network_stress_relative_l2_near_wall"] = weighted_relative(data["stress"][:nv][near]-sigref, sigref, weight[near])
        row["network_stress_increment_relative_l2_near_wall"] = weighted_relative(data["stress"][:nv][near]-sigref, increment, weight[near]) if p != config["p0"] else None
        wu = model.fields(wallx)[0].detach()
        row["wall_displacement_relative_l2"] = weighted_relative(wu-ref["wall_u"], ref["wall_u"], wallweight) if p != config["p0"] else None
        actual = tr.kappa[:nv] > config["plastic_threshold"]
        expected = ref["kappa"][:nv] > config["plastic_threshold"]
        area = (weight*expected).sum()
        diffarea = (weight*(actual ^ expected)).sum()
        row["reference_plastic_area_m2"] = float(area)
        row["plastic_symmetric_difference_m2"] = float(diffarea)
        row["plastic_symmetric_difference_over_reference"] = float(diffarea/area) if area > 0 else None
        row["kappa_relative_l2"] = weighted_relative((tr.kappa[:nv]-ref["kappa"][:nv])[:, None], ref["kappa"][:nv, None], weight) if area > 0 else None
        for field in ("width_closure", "height_closure", "area_closure"):
            row[field] = observed[field]
            row["reference_"+field] = ref["response"][field]
        rows.append(row)
    errors = {}
    for field in ("width_closure", "height_closure", "area_closure"):
        comparable = [r for r in rows if r["reference_available"]]
        signal = max(abs(r["reference_"+field]) for r in comparable)
        errors[field+"_curve_error"] = max(abs(r[field]-r["reference_"+field]) for r in comparable)/signal if signal > 1e-14 else None
    complete_reference = all(r["reference_available"] for r in rows)
    accuracy_passed = (complete_reference and any(r["pressure_ratio"] != 1 for r in rows)
        and all(v is not None and v <= .02 for v in errors.values())
        and all(r.get("wall_displacement_relative_l2") is None or r["wall_displacement_relative_l2"] <= .03 for r in rows))
    return {"run": run, "reference": reference, "records": rows, "curve_errors": errors,
            "candidate_diagnostic_only": candidate_name,
            "all_accepted_pressures_referenced": complete_reference,
            "response_accuracy_passed": accuracy_passed, "solver_run_error": result.get("error"),
            "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in [Path(__file__), ROOT/"code/mixed_pinn.py", ROOT/"code/mixed_reference_sampling.py", ROOT/"code/dp_reference.py"]}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True)
    parser.add_argument("--reference", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--candidate", help="Uncommitted candidate filename; diagnostic only, never commits a state")
    args = parser.parse_args()
    out = ROOT/"results/mixed_feasibility"/args.output
    if out.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Output must be one directory name")
    out.mkdir(exist_ok=False)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.cuda.set_device(0)
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    wall, cpu = time.perf_counter(), time.process_time()
    start.record()
    result = {"mode": "pinn_assessment", "reference": args.reference, "runs": []}
    try:
        for run in args.runs:
            result["runs"].append(assess(run, args.reference, args.candidate))
    except Exception as error:
        result["error"] = repr(error)
        raise
    finally:
        end.record()
        torch.cuda.synchronize()
        result["resources"] = {"wall_seconds": time.perf_counter()-wall, "process_cpu_seconds": time.process_time()-cpu,
            "cuda_event_span_seconds_including_host_gaps": start.elapsed_time(end)/1000,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "process_wall_including_imports": time.perf_counter()-PW, "process_cpu_including_imports": time.process_time()-PC,
            "device": "cuda:0", "dtype": "torch.float64", "tensor_threads": 1, "interop_threads": 1,
            "deterministic_algorithms": True, "pid": os.getpid(), "torch": torch.__version__, "cuda_build": torch.version.cuda}
        names = [str(Path(__file__).relative_to(ROOT)), "code/dp_material.py", "code/current_traction.py",
                 "code/mixed_pinn.py", "code/mixed_history.py", "code/mixed_residual.py", "code/mixed_geometry.py",
                 "code/horseshoe_geometry.py", "code/mixed_q2.py", "code/mixed_reference_sampling.py",
                 "code/mixed_reference.py", "code/mixed_krylov.py", "code/dp_reference.py"]
        names.extend({read(ROOT/"results/mixed_feasibility"/run/"config.json")["geometry"] for run in args.runs})
        (out/"sources").mkdir()
        result["source_sha256"] = {}
        for name in names:
            content = (ROOT/name).read_bytes()
            (out/"sources"/Path(name).name).write_bytes(content)
            result["source_sha256"][name] = hashlib.sha256(content).hexdigest()
        (out/"assessment.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
        print(json.dumps({"curve_errors": {d["run"]: d["curve_errors"] for d in result["runs"]},
                          "resources": result["resources"], "error": result.get("error")}), flush=True)


if __name__ == "__main__":
    main()
