"""GPU Gauss-Newton preconditioning of the common final layer.

The backbone is fixed only during this optimizer substep. Its features and
spatial gradients are cached, while F, current normals, follower pressure and
the material response remain differentiable with respect to displacement-head
weights. It solves the same residual vector, with no FEM labels.
"""
import torch
import dp_material as dp
import current_traction as ct
from mixed_residual import constitutive_work, regional_enabled, regional_excess, weak_coupling, virtual_work_excess


class HeadResidual:
    def __init__(self, model, pool, pressure, material, initial, controls):
        self.model, self.pool, self.pressure = model, pool, pressure
        self.material, self.initial, self.controls = material, initial, controls
        self.coupling = weak_coupling(controls)
        self.field_context = model.displacement_context
        if self.field_context is not None and self.field_context.version == 2:
            self.field_context.check_history(pool.history)
        pool.history.check(pool.x, pool.history.ids, pool.history.state.step)
        self.old_state = pool.history.state
        self.return_anchor = pool.get_return_anchor(pressure)
        x = pool.x.detach().clone().requires_grad_(True)
        feature = model.features(x)
        grad = torch.stack([torch.autograd.grad(feature[:, k].sum(), x, retain_graph=True)[0]
                            for k in range(feature.shape[1])], 1)
        self.feature = torch.cat((feature.detach(), torch.ones_like(x[:, :1])), -1)
        grad = torch.cat((grad.detach(), torch.zeros_like(x[:, None, :])), 1)
        r2 = x.square().sum(-1)/model.lstar**2
        denominator = r2 if model.inverse_square else 1+r2
        envelope = (1-x.square().sum(-1)/model.radius**2)/denominator
        den_grad = 2*x/model.lstar**2
        env_grad = -2*x/(model.radius**2*denominator[:, None])-(1-x.square().sum(-1)/model.radius**2)[:, None]*den_grad/denominator.square()[:, None]
        self.u_gradient = (model.load_amplitude*model.length*model.displacement_scale*(envelope[:, None, None]*grad
                            +self.feature[:, :, None]*env_grad[:, None, :])).detach()
        self.f_offset = model.f0[:2, :2]
        self.displacement_cache = None
        if model.displacement_context is not None:
            self.displacement_cache = cache = model.displacement_context.prepare(pool.x)
            mapped, mapped_grad = model.feature_jets(cache["y"], cache["h"])
            mapped = torch.cat((mapped.detach(), torch.ones_like(x[:, :1])), -1)
            mapped_grad = torch.cat((mapped_grad.detach(), torch.zeros_like(x[:, None, :])), 1)
            factor = model.load_amplitude*model.length*model.displacement_scale
            self.u_gradient = (factor*(cache["envelope"][:, None, None]*mapped_grad
                +mapped[:, :, None]*cache["envgrad"][:, None, :])).detach()
            self.f_offset = (cache["predictor_f"][:, :2, :2]-factor*(
                cache["anchor_v"][:, :, None]*cache["envgrad"][:, None, :]
                +cache["envelope"][:, None, None]*cache["anchor_grad"])).detach()
        self.radial_stress = (1/r2).detach() if model.inverse_square else torch.ones_like(r2)
        self.base = torch.stack((initial.sigma[0, 0], initial.sigma[0, 1], initial.sigma[1, 1], initial.sigma[2, 2]))
        weights = torch.empty_like(pool.distance)
        d = pool.distance[:pool.nv]
        for mask in (d < model.delta, (d >= model.delta) & (d < 2*model.delta), d >= 2*model.delta):
            weights[:pool.nv][mask] = 1/(4*mask.sum().to(d.dtype))
        weights[pool.nv:] = 1/(4*(len(weights)-pool.nv))
        self.consistency_weights = (weights*controls["consistency_weight"]).sqrt()

    def parameters(self):
        return torch.cat((self.model.head.weight.detach(), self.model.head.bias.detach()[:, None]), -1).flatten()

    def install(self, weights):
        matrix = weights.reshape(10, -1)
        with torch.no_grad():
            self.model.head.weight.copy_(matrix[:, :-1])
            self.model.head.bias.copy_(matrix[:, -1])

    def residual(self, weights):
        if self.model.displacement_context is not self.field_context:
            raise ValueError("Head solve cannot span a configuration change")
        if self.pool.history.state is not self.old_state:
            raise ValueError("Head solve cannot span a material-history commit")
        matrix = weights.reshape(10, -1)
        f = dp.plane_tensor(self.f_offset+torch.einsum("qaj,ia->qij", self.u_gradient, matrix[:2]))
        aw = self.model.load_amplitude*self.model.p0*(self.feature @ matrix[2:6].T)+self.base
        ao = self.model.load_amplitude*self.model.p0*self.radial_stress[:, None]*(self.feature @ matrix[6:10].T)+self.base
        return self.residual_from_fields(f, aw, ao)

    def residual_from_fields(self, f, aw, ao):
        trial = dp.evaluate(f, self.old_state, self.material)
        stress = ct.blended_stress(f, aw, ao, self.pool.distance, self.pool.normal, self.pressure,
            self.model.delta, basis=self.model.basis, initial_f=self.model.f0.expand_as(f),
            constitutive_increment=None if self.return_anchor is None else trial.sigma-self.return_anchor)
        piola = dp.cauchy_to_piola(f, stress)
        nv = self.pool.nv
        local = self.pool.mesh.weak(piola[:nv], f[nv:], self.pressure, self.model.p0, self.model.f0, self.initial.piola)
        multi = self.pool.tests.residual(piola[:nv], f[nv:], self.pressure, self.model.p0, self.model.f0, self.initial.piola)
        delta = (stress-trial.sigma)/self.model.p0
        # Exact symmetric Frobenius norm with four plane-strain components.
        error = torch.stack((delta[:, 0, 0], 2**.5*delta[:, 0, 1], delta[:, 1, 1], delta[:, 2, 2]), -1)*self.consistency_weights[:, None]
        parts = [local.flatten()*(self.controls["weak_weight"]/local.numel())**.5,
                 multi.flatten()*(self.controls["weak_weight"]/multi.numel())**.5, error.flatten()]
        cw = self.controls.get("consistency_weak_weight", 0.)
        if cw:
            if self.coupling == "material_equilibrium":
                clocal = self.pool.mesh.weak(trial.piola[:nv], f[nv:], self.pressure,
                    self.model.p0, self.model.f0, self.initial.piola)
                cmulti = self.pool.tests.residual(trial.piola[:nv], f[nv:], self.pressure,
                    self.model.p0, self.model.f0, self.initial.piola)
            else:
                clocal, cmulti = constitutive_work(self.pool, piola[:nv]-trial.piola[:nv], self.model.p0)
            parts.extend((clocal.flatten()*(cw/clocal.numel())**.5, cmulti.flatten()*(cw/cmulti.numel())**.5))
        if regional_enabled(self.controls, self.pressure, self.model.p0):
            parts.append(regional_excess(delta, self.pool, self.model.delta, self.controls))
        if self.controls.get("virtual_work_excess", False):
            if self.coupling != "material_equilibrium" or cw <= 0:
                raise ValueError("Work excess requires material equilibrium")
            parts.append(virtual_work_excess({"weak": local, "multi": multi,
                "material_weak": clocal, "material_multi": cmulti}, self.model, self.controls))
        vector = torch.cat(parts)
        return vector/self.model.load_amplitude if self.controls.get("normalize_residual_by_load", False) else vector

    def norm_curvature_groups(self):
        """Primitive residual blocks and their scalar norm-excess rows."""
        controls, pool = self.controls, self.pool
        local, multi = 2*pool.mesh.free.numel(), 2*len(pool.tests.scale)
        prefix, points = local+multi, len(pool.x)
        offset = prefix+4*points
        material_offset = offset
        if controls.get("consistency_weak_weight", 0.):
            offset += local+multi
        groups = []
        if regional_enabled(controls, self.pressure, self.model.p0):
            ids = torch.arange(points, device=pool.x.device)
            volume, distance = ids < pool.nv, pool.distance
            masks = (volume & (distance < self.model.delta),
                volume & (distance >= self.model.delta) & (distance < 2*self.model.delta),
                volume & (distance >= 2*self.model.delta), ~volume)
            rows = prefix+4*ids[:, None]+torch.arange(4, device=pool.x.device)
            factor = controls.get("virtual_work_regional_factor", 1.) if controls.get("virtual_work_excess", False) else 1.
            for index, (label, mask) in enumerate(zip(("collar", "transition", "outer", "wall"), masks)):
                groups.append({"name": label, "rows": rows[mask].flatten(), "norm_row": offset+index,
                    "base_weight": controls["consistency_weight"]/4,
                    "penalty_weight": controls["regional_consistency_weight"]*factor,
                    "target": controls["regional_consistency_target"]})
            offset += 4
        if controls.get("virtual_work_excess", False) and "virtual_work_rms_target" in controls:
            for index, (label, left, key) in enumerate((("network_local_rms", 0, "weak_weight"),
                    ("material_local_rms", material_offset, "consistency_weak_weight"))):
                groups.append({"name": label, "rows": torch.arange(left, left+local, device=pool.x.device),
                    "norm_row": offset+index, "base_weight": controls[key],
                    "penalty_weight": controls[key]*controls["virtual_work_rms_factor"],
                    "target": controls["virtual_work_rms_target"]*float(self.model.load_amplitude)})
        return groups

    def generalized_norm_row_scale(self, residual):
        """Factor the convex norm-loss curvature while preserving J.T @ r.

        Scale primitive rows by sqrt(1+w/c*(1-t/q)) and the active norm row
        by sqrt(t/q). Dividing the linearized RHS residual by those factors
        preserves the exact gradient. These are metric rows, not a new loss.
        """
        row_scale = torch.ones_like(residual)
        amplitude = float(self.model.load_amplitude) if self.controls.get("normalize_residual_by_load", False) else 1.
        reports = []
        for group in self.norm_curvature_groups():
            base, weight, target = group["base_weight"], group["penalty_weight"], group["target"]
            if min(base, weight, target) <= 0:
                raise ValueError("Generalized norm curvature requires positive base weights and margins")
            q = residual[group["rows"]].norm()*amplitude/base**.5
            expected = weight**.5*torch.relu(q-target)/amplitude
            if not torch.allclose(expected, residual[group["norm_row"]], rtol=1e-9, atol=1e-12):
                raise ValueError("Norm curvature block does not reproduce its scalar residual")
            active = bool(q > target)
            if active:
                row_scale[group["rows"]] = (1+weight/base*(1-target/q)).sqrt()
                row_scale[group["norm_row"]] = (target/q).sqrt()
            reports.append({"name": group["name"], "norm": float(q), "target": target, "active": active})
        return row_scale, {"norm_curvature_groups": reports,
            "active_norm_curvature_groups": sum(row["active"] for row in reports)}

    def inactive_work_excess_rows(self, residual):
        """Only zero ReLU-excess rows have an identically zero pullback here."""
        empty = torch.empty(0, device=residual.device, dtype=torch.long)
        if not self.controls.get("virtual_work_excess", False):
            return empty
        local = 2*self.pool.mesh.free.numel()
        multi = 2*len(self.pool.tests.grad)
        offset = residual.numel()-2*(local+multi)
        selected = []
        for size, target in ((local, "virtual_work_local_target"), (multi, "virtual_work_multi_target"),
                             (local, "virtual_work_local_target"), (multi, "virtual_work_multi_target")):
            # A signed zero-target residual still has a Jacobian at zero.
            if self.controls[target] > 0:
                rows = torch.arange(offset, offset+size, device=residual.device)
                selected.append(rows[residual[rows] == 0])
            offset += size
        return torch.cat(selected) if selected else empty


def head_newton(model, pool, pressure, material, initial, controls, iterations, emit, stop_check=None):
    reduced = HeadResidual(model, pool, pressure, material, initial, controls)
    weights = reduced.parameters()
    counts = {"head_jvp_evaluations": 0, "head_residual_evaluations": 0}
    for iteration in range(iterations):
        r = reduced.residual(weights).detach()
        counts["head_residual_evaluations"] += 1
        jac = torch.empty((len(r), len(weights)), device=weights.device, dtype=weights.dtype)
        for column in range(len(weights)):
            direction = torch.zeros_like(weights)
            direction[column] = 1
            _, derivative = torch.func.jvp(reduced.residual, (weights,), (direction,))
            jac[:, column] = derivative.detach()
            counts["head_jvp_evaluations"] += 1
            if (column+1) % 100 == 0:
                emit({"phase": "head_jacobian", "iteration": iteration, "columns": column+1, **counts})
        scale = jac.norm(dim=0).clamp_min(1e-12)
        scaled = jac/scale
        normal, rhs = scaled.T @ scaled, scaled.T @ r
        spectrum = torch.linalg.eigvalsh(normal)
        emit({"phase": "head_conditioning", "iteration": iteration,
              "normalized_normal_eigenvalue_min": float(spectrum.min()),
              "normalized_normal_eigenvalue_max": float(spectrum.max()),
              "directions_above_relative_1e_8": int((spectrum > 1e-8*spectrum.max()).sum()),
              "columns": len(weights)})
        success = False
        for damping in (1e-8, 1e-6, 1e-4, 1e-2):
            correction = torch.linalg.solve(normal+damping*torch.eye(len(weights), device=weights.device, dtype=weights.dtype), -rhs)/scale
            for backtrack in range(12):
                candidate = weights+(0.5**backtrack)*correction
                try:
                    rr = reduced.residual(candidate)
                    counts["head_residual_evaluations"] += 1
                    if float(rr.square().sum()) < float(r.square().sum()):
                        weights, success = candidate.detach(), True
                        break
                except ValueError:
                    counts["head_residual_evaluations"] += 1
            if success:
                break
        reduced.install(weights)
        final_loss = float(reduced.residual(weights).square().sum())
        counts["head_residual_evaluations"] += 1
        emit({"phase": "head_newton", "iteration": iteration+1, "accepted_parameter_step": success,
              "loss": final_loss, **counts})
        if stop_check is not None and stop_check():
            counts["head_physics_passed"] = True
            break
        if not success:
            break
    return counts
