"""Batched reverse Jacobian and column-scaled GPU normal equations.

Only backward pullbacks are batched, so forward material branch selection
occurs once at the fixed linearization. No unchecked material path is used.
"""
import torch


def dense_system(residual, pullback, parameters, emit, batch_size=64, point_problem=None):
    rows, columns = residual.numel(), parameters.numel()
    free, _ = torch.cuda.mem_get_info(parameters.device)
    # Driver-free memory excludes this process's unused caching-allocator
    # blocks, which are reusable by the following Jacobian allocation.
    reusable = max(0, torch.cuda.memory_reserved(parameters.device)-torch.cuda.memory_allocated(parameters.device))
    available = free+reusable
    # The Jacobian is scaled in place and deleted immediately after forming
    # the Gram matrix. Account for one Jacobian, four square solve buffers,
    # and a separate 2 GiB allowance for AD/BLAS workspaces.
    estimate = 8*(rows*columns+4*columns*columns)+2*1024**3
    emit({"phase": "dense_memory_check", "driver_free_bytes": free, "own_reusable_bytes": reusable,
          "conservative_additional_bytes": estimate})
    if available < estimate:
        raise ValueError(f"Insufficient available GPU memory for dense neural Jacobian: {available} < {estimate}")
    jacobian = torch.empty((rows, columns), device=parameters.device, dtype=parameters.dtype)
    if point_problem is not None:
        from mixed_local_jacobian import fill_constitutive_rows
        global_rows, point_batches = fill_constitutive_rows(jacobian, residual, point_problem, parameters, emit)
    else:
        global_rows = torch.arange(rows, device=parameters.device)
        point_batches = 0
    batches = 0
    for left in range(0, len(global_rows), batch_size):
        right = min(len(global_rows), left+batch_size)
        vectors = torch.zeros((right-left, rows), device=parameters.device, dtype=parameters.dtype)
        indices = torch.arange(right-left, device=parameters.device)
        selected = global_rows[left:right]
        vectors[indices, selected] = 1
        jacobian[selected] = torch.vmap(lambda vector: pullback(vector)[0])(vectors).detach()
        batches += 1
        if batches % 32 == 0:
            emit({"phase": "dense_neural_jacobian", "rows": right, "total_rows": len(global_rows),
                  "columns": columns, "backward_batches": batches})
    scale = jacobian.norm(dim=0).clamp_min(1e-12)
    jacobian.div_(scale)
    normal = jacobian.T @ jacobian
    rhs = -(jacobian.T @ residual)
    del jacobian
    return normal, rhs, scale, {"dense_jacobian_rows": rows, "dense_backward_batches": batches+point_batches,
                               "point_backward_batches": point_batches}


def solve_damped(normal, rhs, damping):
    matrix = normal.clone()
    matrix.diagonal().add_(damping)
    correction = torch.linalg.solve(matrix, rhs)
    relative = (matrix @ correction-rhs).norm()/rhs.norm().clamp_min(1e-30)
    if not torch.isfinite(relative) or relative > 1e-7:
        raise ValueError("Dense Gauss-Newton direction failed its true linear residual check")
    return correction, float(relative)
