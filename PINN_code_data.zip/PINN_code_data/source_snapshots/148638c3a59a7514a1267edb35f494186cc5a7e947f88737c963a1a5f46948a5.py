"""Mixed weak PINN with current traction and fixed material histories.

The loss is a squared virtual-work residual plus constitutive consistency,
not a total potential for a nonassociated material. Reference FEM fields
never enter this module, loss, initialization or checkpoint selection.
"""
import copy
import torch
from torch import nn
import dp_material as dp
import current_traction as ct
from mixed_history import PointHistory, accept_all
from mixed_geometry import wall_geometry_checks, MultiScaleTests
from mixed_residual import constitutive_work, objective


METHODS = {"W-GH": "cartesian", "W-LH": "current", "W-RH": "initial"}


class MixedNet(nn.Module):
    def __init__(self, config, f0, initial, radius, method):
        super().__init__()
        self.method, self.basis = method, METHODS[method]
        self.p0, self.length = config["p0"], 13.46
        self.displacement_scale = config["p0"]/config["material"]["young"]
        self.inverse_square = config.get("field_scaling") == "inverse_square_exterior_envelope"
        self.lstar = self.length/float(f0[0, 0])
        self.radius, self.delta = float(radius), config["collar_precompressed_m"]/float(f0[0, 0])
        self.register_buffer("f0", f0.clone())
        self.register_buffer("initial_stress", initial.sigma.clone())
        self.load_floor = config.get("load_scaling", {}).get("minimum_amplitude")
        if self.load_floor is None:
            self.load_amplitude = 1.
        else:
            self.register_buffer("load_amplitude", f0.new_tensor(self.load_floor))
        layers, width = [], config["network"]["width"]
        for i in range(config["network"]["depth"]):
            layers.extend((nn.Linear(2 if i == 0 else width, width), nn.Tanh()))
        self.body = nn.Sequential(*layers)
        self.coordinate_features = config["network"].get("coordinate_features") == "linear_angular_quadratic"
        self.head = nn.Linear(width+(5 if self.coordinate_features else 0), 10)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)
        self.to(device=f0.device, dtype=f0.dtype)
        self.displacement_context = None
        if config["network"].get("initializer") == "xavier_tanh":
            # Common initialization only; input remains X/L* and capacity is
            # unchanged. Preserve nonzero biases for even spatial features.
            with torch.no_grad():
                for index, layer in enumerate(self.body):
                    if isinstance(layer, nn.Linear):
                        nn.init.xavier_uniform_(layer.weight, gain=nn.init.calculate_gain("tanh"))
                        nn.init.uniform_(layer.bias, -.1, .1)
                        if index == 0:
                            layer.weight.mul_(config["network"]["input_gain"])

    def set_pressure(self, pressure):
        if self.displacement_context is not None and float(pressure) != self.displacement_context.pressure:
            raise ValueError("Configuration displacement cannot cross its fixed pressure interval")
        if self.load_floor is not None:
            with torch.no_grad():
                self.load_amplitude.fill_(max(abs(1-pressure/self.p0), self.load_floor))

    def features(self, x, parameters=None):
        return self.features_from_z(x/self.lstar, parameters)

    def features_from_z(self, z, parameters=None):
        if parameters is None:
            learned = self.body(z)
        else:
            learned = z
            for i, layer in enumerate(self.body):
                if isinstance(layer, nn.Linear):
                    learned = learned @ parameters[f"body.{i}.weight"].T+parameters[f"body.{i}.bias"]
                elif isinstance(layer, nn.Tanh):
                    learned = torch.tanh(learned)
                else:
                    raise ValueError("Configuration features support Linear/Tanh only")
        if not self.coordinate_features:
            return learned
        r2 = z.square().sum(-1)
        # Shared exterior coordinate basis: linear terms support 1/r
        # displacement, angular terms support 1/r^2 stress, and r^2
        # supports the finite-outer-boundary constant stress correction.
        direct = torch.stack((z[:, 0], z[:, 1], (z[:, 0]**2-z[:, 1]**2)/r2,
                              2*z[:, 0]*z[:, 1]/r2, r2), -1)
        return torch.cat((learned, direct), -1)

    def feature_jets(self, points, mapping, parameters=None):
        """Feature values and exact first derivatives in natural coordinates."""
        p = dict(self.named_parameters()) if parameters is None else parameters
        z = points/self.lstar
        h, grad = z, mapping/self.lstar
        for i, layer in enumerate(self.body):
            if isinstance(layer, nn.Linear):
                weight, bias = p[f"body.{i}.weight"], p[f"body.{i}.bias"]
                h = h @ weight.T+bias
                grad = torch.einsum("qaj,ia->qij", grad, weight)
            elif isinstance(layer, nn.Tanh):
                h = torch.tanh(h)
                grad = grad*(1-h.square())[:, :, None]
            else:
                raise ValueError("Configuration gradients support Linear/Tanh only")
        if self.coordinate_features:
            x, y = z.unbind(-1)
            r2 = x.square()+y.square()
            direct = torch.stack((x, y, (x.square()-y.square())/r2, 2*x*y/r2, r2), -1)
            zero, one = torch.zeros_like(x), torch.ones_like(x)
            dz = torch.stack((torch.stack((one, zero), -1), torch.stack((zero, one), -1),
                torch.stack((4*x*y.square()/r2.square(), -4*x.square()*y/r2.square()), -1),
                torch.stack((2*y*(y.square()-x.square())/r2.square(),
                             2*x*(x.square()-y.square())/r2.square()), -1),
                torch.stack((2*x, 2*y), -1)), 1)
            directgrad = torch.einsum("qai,qij->qaj", dz, mapping/self.lstar)
            h, grad = torch.cat((h, direct), -1), torch.cat((grad, directgrad), 1)
        return h, grad

    def configuration_kinematics(self, cache, parameters=None):
        p = dict(self.named_parameters()) if parameters is None else parameters
        feature, grad = self.feature_jets(cache["y"], cache["h"], p)
        raw = feature @ p["head.weight"][:2].T+p["head.bias"][:2]
        rawgrad = torch.einsum("qaj,ia->qij", grad, p["head.weight"][:2])
        factor = self.length*self.displacement_scale*self.load_amplitude
        difference = raw-cache["anchor_v"]
        u = cache["predictor_u"]+factor*cache["envelope"][:, None]*difference
        increment = factor*(difference[:, :, None]*cache["envgrad"][:, None, :]
            +cache["envelope"][:, None, None]*(rawgrad-cache["anchor_grad"]))
        f = dp.plane_tensor(cache["predictor_f"][:, :2, :2]+increment)
        return u, f

    def set_displacement_context(self, context):
        if self.displacement_context is not None:
            raise ValueError("A configuration context cannot be replaced while active")
        context.check_model(self)
        self.displacement_context = context
        self.register_buffer("configuration_displacement_version", self.f0.new_tensor(1, dtype=torch.int64))

    def clear_displacement_context(self):
        self.displacement_context = None
        if "configuration_displacement_version" in self._buffers:
            del self._buffers["configuration_displacement_version"]

    def load_state_dict(self, state_dict, strict=True, **kwargs):
        marked = "configuration_displacement_version" in state_dict
        if marked != (self.displacement_context is not None):
            raise ValueError("Load the matching full displacement context before its network state")
        if marked and (int(state_dict["configuration_displacement_version"]) != 1
                or float(state_dict["load_amplitude"]) != self.displacement_context.amplitude):
            raise ValueError("Configuration network version or pressure amplitude differs")
        return super().load_state_dict(state_dict, strict=strict, **kwargs)

    def field_snapshot(self):
        return {"network": copy.deepcopy(self.state_dict()), "context": self.displacement_context}

    def restore_fields(self, saved):
        self.clear_displacement_context()
        network = saved["network"]
        if saved["context"] is not None:
            plain = {k: v for k, v in network.items() if k != "configuration_displacement_version"}
            self.load_state_dict(plain)
            self.set_displacement_context(saved["context"])
        self.load_state_dict(network)

    def fields(self, x):
        # A strictly positive known load scale changes parameter conditioning,
        # not the admissible fields. Its checkpointed buffer makes replay exact.
        outputs = self.load_amplitude*self.head(self.features(x))
        r2 = x.square().sum(-1)/self.lstar**2
        # Common smooth positive factor; both outer displacement components vanish.
        denominator = r2 if self.inverse_square else 1+r2
        # The origin is inside the excluded cavity. This positive exterior
        # scaling supplies the elastic 1/r displacement decay for a linear
        # head, without prescribing a circular solution or a field label.
        dp.require(denominator > 0, "Field envelope is defined only outside the cavity")
        envelope = (1-x.square().sum(-1)/self.radius**2)/denominator
        u = self.length*self.displacement_scale*envelope[:, None]*outputs[:, :2]
        if self.displacement_context is not None:
            context = self.displacement_context
            if x.requires_grad:
                # This path defines the complete compatible field for AD checks.
                old_u = context.old_model.fields(x)[0]
                y = x+torch.linalg.solve(self.f0[:2, :2], old_u[..., None]).squeeze(-1)
                anchor = context.old_model.head(context.old_model.features(y))[:, :2]
                raw = self.head(self.features(y))[:, :2]
                u = context.predictor_model.fields(x)[0]+self.length*self.displacement_scale*self.load_amplitude*envelope[:, None]*(raw-anchor)
            else:
                cache = context.prepare(x)
                raw = self.head(self.features(cache["y"]))[:, :2]
                u = cache["predictor_u"]+self.length*self.displacement_scale*self.load_amplitude*envelope[:, None]*(raw-cache["anchor_v"])
        base = torch.stack((self.initial_stress[0, 0], self.initial_stress[0, 1],
                            self.initial_stress[1, 1], self.initial_stress[2, 2]))/self.p0
        wall = self.p0*(outputs[:, 2:6]+base)
        outer_correction = outputs[:, 6:10]/r2[:, None] if self.inverse_square else outputs[:, 6:10]
        outer = self.p0*(outer_correction+base)
        return u, wall, outer

    def deformation(self, points, graph=True):
        if self.displacement_context is not None:
            cache = self.displacement_context.prepare(points)
            with torch.set_grad_enabled(graph):
                u, f = self.configuration_kinematics(cache)
                outputs = self.load_amplitude*self.head(self.features(points))
                base = torch.stack((self.initial_stress[0, 0], self.initial_stress[0, 1],
                                    self.initial_stress[1, 1], self.initial_stress[2, 2]))
                aw = self.p0*outputs[:, 2:6]+base
                r2 = points.square().sum(-1)/self.lstar**2
                outer = outputs[:, 6:10]/r2[:, None] if self.inverse_square else outputs[:, 6:10]
                ao = self.p0*outer+base
                dp.check_deformation(f)
            return (u, f, aw, ao) if graph else tuple(t.detach() for t in (u, f, aw, ao))
        x = points.detach().clone().requires_grad_(True)
        u, aw, ao = self.fields(x)
        grad = torch.stack([torch.autograd.grad(u[:, i].sum(), x, create_graph=graph,
                                               retain_graph=True)[0] for i in range(2)], -2)
        f = dp.plane_tensor(self.f0[:2, :2]+grad)
        dp.check_deformation(f)
        if not graph:
            return tuple(t.detach() for t in (u, f, aw, ao))
        return u, f, aw, ao


class FrozenConfiguration:
    """External immutable old field; never an nn.Module in the trainable model."""
    def __init__(self, model, pressure, source=None):
        if model.method != "W-GH" or model.displacement_context is not None or model.load_floor is None:
            raise ValueError("Configuration displacement requires an original load-scaled GH field")
        self.pressure, self.source = float(pressure), copy.deepcopy(source or {})
        self.old_model = copy.deepcopy(model).requires_grad_(False)
        self.predictor_model = copy.deepcopy(self.old_model)
        self.predictor_model.set_pressure(pressure)
        self.amplitude = float(self.predictor_model.load_amplitude)
        self.caches = []

    def check_model(self, model):
        if model.method != "W-GH" or float(model.load_amplitude) != self.amplitude:
            raise ValueError("Configuration context method or target pressure differs")
        for name in ("radius", "lstar", "length", "delta", "displacement_scale", "inverse_square", "coordinate_features"):
            if getattr(model, name) != getattr(self.old_model, name):
                raise ValueError("Configuration context changed field settings: "+name)
        for name in ("f0", "initial_stress"):
            if not torch.equal(getattr(model, name), getattr(self.old_model, name)):
                raise ValueError("Configuration context changed precompression")

    def prepare(self, points):
        for cached in self.caches:
            if cached["x"].shape == points.shape and torch.equal(cached["x"], points):
                return cached
        x = points.detach().clone()
        with torch.enable_grad():
            old_u, old_f, _, _ = self.old_model.deformation(x, graph=False)
            predictor_u, predictor_f, _, _ = self.predictor_model.deformation(x, graph=False)
        with torch.no_grad():
            y = x+torch.linalg.solve(self.old_model.f0[:2, :2], old_u[..., None]).squeeze(-1)
            h = torch.linalg.solve(self.old_model.f0[:2, :2], old_f[:, :2, :2])
            features, gradients = self.old_model.feature_jets(y, h)
            anchor = self.old_model.head(features)[:, :2]
            anchor_grad = torch.einsum("qaj,ia->qij", gradients, self.old_model.head.weight[:2])
            r2 = x.square().sum(-1)/self.old_model.lstar**2
            denominator = r2 if self.old_model.inverse_square else 1+r2
            exterior = 1-x.square().sum(-1)/self.old_model.radius**2
            envelope = exterior/denominator
            envgrad = (-2*x/(self.old_model.radius**2*denominator[:, None])
                -exterior[:, None]*2*x/(self.old_model.lstar**2*denominator.square()[:, None]))
            cached = {"x": x, "y": y, "h": h, "old_u": old_u, "old_f": old_f,
                "predictor_u": predictor_u, "predictor_f": predictor_f,
                "anchor_v": anchor, "anchor_grad": anchor_grad, "envelope": envelope, "envgrad": envgrad}
        self.caches.append(cached)
        return cached

    def checkpoint(self):
        return {"version": 1, "representation": "accepted_configuration_increment", "pressure": self.pressure,
            "source": copy.deepcopy(self.source), "network": copy.deepcopy(self.old_model.state_dict()),
            "settings": {name: getattr(self.old_model, name) for name in
                ("radius", "lstar", "length", "delta", "displacement_scale", "inverse_square", "coordinate_features")}}

    @classmethod
    def restore(cls, model, saved):
        if saved.get("version") != 1 or saved.get("representation") != "accepted_configuration_increment":
            raise ValueError("Unknown configuration context format")
        if model.displacement_context is not None:
            raise ValueError("Restore the context on a separate original model")
        old = copy.deepcopy(model)
        old.load_state_dict(saved["network"])
        for name, value in saved["settings"].items():
            if getattr(old, name) != value:
                raise ValueError("Saved configuration settings differ: "+name)
        return cls(old, saved["pressure"], saved["source"])


class EvaluationPool:
    def __init__(self, name, mesh, initial_pressure):
        self.mesh = mesh
        self.nv = len(mesh.volume.x)
        self.x = torch.cat((mesh.volume.x, mesh.boundary.x))
        self.history = PointHistory(name, self.x, initial_pressure)
        self.tests = MultiScaleTests(mesh, 2*float(mesh.wall.radii[0]),
                                     shift=1.13 if name == "validation" else 1.)
        projection = mesh.wall.project(self.x)
        self.distance, self.normal = projection.distance.detach(), projection.normal.detach()
        # Wall quadrature carries analytic normals and exactly d=0.
        self.distance[self.nv:] = 0
        self.normal[self.nv:] = mesh.boundary.normal
        self.return_anchor = None
        self.return_anchor_source = None
        self.return_anchor_pressure = None

    def freeze_return_anchor(self, model, pressure, material):
        """Freeze the returned stress of the load predictor without a commit."""
        if self.return_anchor is not None:
            raise ValueError("A fixed return anchor cannot be recomputed during an increment")
        f = model.deformation(self.x, graph=False)[1]
        state = self.history
        trial = state.trial(f, self.x, state.ids, state.state.step, material)
        self.return_anchor = trial.sigma.detach().clone()
        self.return_anchor_source = state.state
        self.return_anchor_pressure = float(pressure)

    def get_return_anchor(self, pressure):
        if self.return_anchor is not None:
            if (self.return_anchor_source is not self.history.state
                    or self.return_anchor_pressure != float(pressure)):
                raise ValueError("Return anchor cannot cross a history commit or pressure change")
        return self.return_anchor

    def return_anchor_checkpoint(self):
        if self.return_anchor is None:
            return None
        self.get_return_anchor(self.return_anchor_pressure)
        return {"sigma": self.return_anchor, "pressure": self.return_anchor_pressure,
                "history": self.history.checkpoint()}

    def restore_return_anchor(self, saved):
        """Restore an immutable anchor against the exact old point history."""
        history, state = saved["history"], self.history
        if (history["name"] != state.name or history["identity_sha256"] != state.key
                or not torch.equal(history["coordinates"], state.x)
                or not torch.equal(history["ids"], state.ids) or history["step"] != state.state.step
                or history["pressures"] != state.pressures
                or not torch.equal(history["cp"], state.state.cp)
                or not torch.equal(history["kappa"], state.state.kappa)):
            raise ValueError("Return anchor history or point identity differs")
        sigma = saved["sigma"]
        if (sigma.shape != state.state.cp.shape or sigma.device != state.x.device
                or sigma.dtype != state.x.dtype or sigma.requires_grad):
            raise ValueError("Return anchor must be a fixed stress on this point pool")
        dp.check_block(sigma, "Return anchor", symmetric=True)
        if self.return_anchor is not None and (not torch.equal(sigma, self.return_anchor)
                or self.return_anchor_pressure != float(saved["pressure"])):
            raise ValueError("Restore cannot change an existing return anchor")
        self.return_anchor = sigma.detach().clone()
        self.return_anchor_source = state.state
        self.return_anchor_pressure = float(saved["pressure"])

    def evaluate(self, model, pressure, material, initial, graph=True):
        u, f, aw, ao = model.deformation(self.x, graph)
        state = self.history
        trial = state.trial(f, self.x, state.ids, state.state.step, material)
        anchor = self.get_return_anchor(pressure)
        stress = ct.blended_stress(f, aw, ao, self.distance, self.normal, pressure, model.delta,
                                  basis=model.basis, initial_f=model.f0.expand_as(f),
                                  constitutive_increment=None if anchor is None else trial.sigma-anchor)
        piola = dp.cauchy_to_piola(f, stress)
        weak = self.mesh.weak(piola[:self.nv], f[self.nv:], pressure, model.p0, model.f0, initial.piola)
        multi = self.tests.residual(piola[:self.nv], f[self.nv:], pressure, model.p0, model.f0, initial.piola)
        cweak, cmulti = constitutive_work(self, piola[:self.nv]-trial.piola[:self.nv], model.p0)
        rmweak, rmmulti = weak-cweak, multi-cmulti
        error = (stress-trial.sigma)/model.p0
        return {"u": u, "f": f, "trial": trial, "stress": stress, "weak": weak, "pressure": pressure,
                "material_weak": rmweak, "multi": multi, "material_multi": rmmulti, "error": error,
                "constitutive_weak": cweak, "constitutive_multi": cmulti}

    def consistency(self, data, delta):
        # Region-balanced Frobenius norm; far-domain volume cannot hide wall errors.
        norm = data["error"].square().sum((-2, -1))
        d = self.distance[:self.nv]
        masks = (d < delta, (d >= delta) & (d < 2*delta), d >= 2*delta)
        return torch.stack([norm[:self.nv][mask].mean() for mask in masks]+[norm[self.nv:].mean()]).mean()


def checks(pool, data, model, config, initial):
    trial, f = data["trial"], data["f"]
    nv, b = pool.nv, pool.mesh.boundary
    n, _, area = ct.current_frame(f[nv:], b.normal)
    pressure = data["pressure"]
    tnet = (data["stress"][nv:] @ n[:, :, None]).squeeze(-1)+pressure*n
    trm = (trial.sigma[nv:] @ n[:, :, None]).squeeze(-1)+pressure*n
    d = pool.distance[:nv]
    errors = data["error"].square().sum((-2, -1))
    out = {"consistency_rms": float(pool.consistency(data, model.delta).sqrt()),
        "consistency_wall_rms": float(errors[nv:].mean().sqrt()),
        "consistency_collar_rms": float(errors[:nv][d < model.delta].mean().sqrt()),
        "consistency_transition_rms": float(errors[:nv][(d >= model.delta) & (d < 2*model.delta)].mean().sqrt()),
        "consistency_outer_rms": float(errors[:nv][d >= 2*model.delta].mean().sqrt()),
        "traction_material_rms": float(trm.square().sum(-1).mean().sqrt()/model.p0),
        "hard_traction_max": float(tnet.abs().max()/model.p0),
        "weak_rms": float(data["weak"].square().mean().sqrt()),
        "weak_max": float(data["weak"].abs().max()),
        "material_weak_rms": float(data["material_weak"].square().mean().sqrt()),
        "material_weak_max": float(data["material_weak"].abs().max()),
        "multiscale_weak_rms": float(data["multi"].square().mean().sqrt()),
        "multiscale_weak_max": float(data["multi"].abs().max()),
        "multiscale_material_weak_rms": float(data["material_multi"].square().mean().sqrt()),
        "multiscale_material_weak_max": float(data["material_multi"].abs().max()),
        "j_min": float(torch.linalg.det(f).min()), "yield_max": float(trial.yield_value.max()/model.p0),
        "plastic_volume_max": float((.5*torch.linalg.slogdet(trial.cp)[1]-config["material"]["beta"]*trial.kappa).abs().max()),
        "cp_eigenvalue_min": float(torch.stack([torch.linalg.eigvalsh(chunk).min()
                                                for chunk in trial.cp.split(4096)]).min()),
        "endpoint_dissipation_min": float((trial.tau*(trial.trial_log-trial.elastic_log)).sum((-2, -1)).min()),
        "kappa_max": float(trial.kappa.max()), "delta_lambda_max": float(trial.delta_lambda.max()),
        "cumulative_plastic_area_m2": float((pool.mesh.volume.weight*(trial.kappa[:nv] > config["plastic_threshold"])).sum()),
        "active_plastic_area_m2": float((pool.mesh.volume.weight*(trial.delta_lambda[:nv] > config["plastic_threshold"])).sum()),
        "current_area_ratio_min": float((area/model.f0[0, 0]).min()),
        "current_area_ratio_max": float((area/model.f0[0, 0]).max()),
        "normal_rotation_max_rad": float(torch.atan2(torch.linalg.cross(b.normal, n).norm(dim=-1), (b.normal*n).sum(-1)).max())}
    # Independent, denser wall polygon and exact fixed material gauge points.
    ids = torch.arange(6, device=f.device).repeat_interleave(128)
    frac = torch.arange(128, device=f.device, dtype=f.dtype).repeat(6)/128
    wallx, _ = pool.mesh.wall.sample(ids, frac)
    wu = model.fields(wallx)[0]
    xcur = wallx @ model.f0[:2, :2].T+wu
    out.update(wall_geometry_checks(xcur))
    initial_geo = wall_geometry_checks(wallx @ model.f0[:2, :2].T)
    out["area_closure"] = 1-out["wall_polygon_area_m2"]/initial_geo["wall_polygon_area_m2"]
    gauges = torch.tensor([[6.73, 0], [-6.73, 0], [0, 6.73], [0, -4.32]], device=f.device, dtype=f.dtype)
    cur = gauges+model.fields(gauges/model.f0[0, 0])[0].detach()
    out["width_closure"] = float(1-(cur[0]-cur[1]).norm()/13.46)
    out["height_closure"] = float(1-(cur[2]-cur[3]).norm()/11.05)
    scale = (max(abs(1-pressure/model.p0), config["load_scaling"]["minimum_amplitude"])
             if config.get("acceptance_scaling") == "unloading_amplitude" else 1.)
    relative_keys = {"consistency_rms", "traction_material_rms", "weak_rms", "weak_max"}
    if config.get("constitutive_acceptance_scaling") == "p0":
        relative_keys.remove("consistency_rms")
    thresholds = {key: value*scale if key in relative_keys else value for key, value in config["acceptance"].items()}
    out["physical_residual_scale"] = scale
    out["effective_thresholds"] = thresholds
    failed = [key for key, tol in thresholds.items() if (out[key] < tol if key == "j_min" else out[key] > tol)]
    if out["cp_eigenvalue_min"] <= 0 or out["endpoint_dissipation_min"] < -1e-11:
        failed.append("material_admissibility")
    if out["wall_self_intersections"] or out["wall_polygon_area_m2"] <= 0:
        failed.append("wall_geometry")
    if out["material_weak_rms"] > thresholds["weak_rms"] or out["material_weak_max"] > thresholds["weak_max"]:
        failed.append("material_virtual_work")
    if (out["multiscale_weak_max"] > thresholds["weak_rms"]
            or out["multiscale_material_weak_max"] > thresholds["weak_rms"]):
        failed.append("multiscale_virtual_work")
    if pressure < model.p0 and min(out["width_closure"], out["height_closure"], out["area_closure"]) < -1e-7:
        failed.append("small_unloading_response_sign")
    if max(out["consistency_wall_rms"], out["consistency_collar_rms"], out["consistency_transition_rms"],
           out["consistency_outer_rms"]) > thresholds["consistency_rms"]:
        failed.append("regional_consistency")
    out["accepted"], out["failed_checks"] = not failed, failed
    return out


def train_step(model, train, validation, pressure, material, initial, config, emit, candidate_callback=None,
               optimizer_resume=None, displacement_context=None):
    if displacement_context is None:
        return _train_step(model, train, validation, pressure, material, initial, config, emit,
                           candidate_callback, optimizer_resume)
    if optimizer_resume is not None or any(pool.return_anchor is not None for pool in (train, validation)):
        raise ValueError("Configuration increment cannot combine optimizer recovery or stress lifting")
    if config["optimizer"].get("weak_coupling") != "material_equilibrium":
        raise ValueError("Configuration displacement requires material equilibrium")
    original = model.field_snapshot()
    histories = [(pool.history.state, pool.history.pressures.copy()) for pool in (train, validation)]
    try:
        model.set_pressure(pressure)
        model.set_displacement_context(displacement_context)
        result = _train_step(model, train, validation, pressure, material, initial, config, emit, candidate_callback)
        if not result["accepted"]:
            model.restore_fields(original)
        return result
    except Exception:
        model.restore_fields(original)
        for pool, (state, pressures) in zip((train, validation), histories):
            pool.history.state, pool.history.pressures = state, pressures
        raise


def _train_step(model, train, validation, pressure, material, initial, config, emit, candidate_callback=None,
                optimizer_resume=None):
    original = copy.deepcopy(model.state_dict())
    previous_amplitude = float(model.load_amplitude)
    model.set_pressure(pressure)
    controls = config["optimizer"]
    counts = {"evaluations": 0, "invalid_updates": 0, "physical_checks": 0}
    progress = {"phase": "initial"}
    if optimizer_resume is not None:
        model.load_state_dict(optimizer_resume["network"])
        model.set_pressure(pressure)
        counts.update(optimizer_resume["training_counts"])
        progress = optimizer_resume["optimizer_checkpoint"].copy()
    def save_optimizer_state(state):
        nonlocal progress
        progress = state
    def ready():
        counts["physical_checks"] += 1
        passed = True
        reports = []
        for pool in (train, validation):
            candidate = pool.evaluate(model, pressure, material, initial, graph=False)
            candidate["pressure"] = pressure
            verdict = checks(pool, candidate, model, config, initial)
            passed = passed and verdict["accepted"]
            reports.append(verdict)
        report = {"pressure_ratio": pressure/model.p0, "training_physics": reports[0],
                  "validation": reports[1], "physical_checks_passed": passed,
                  "optimizer_checkpoint": progress, **counts}
        if candidate_callback is not None:
            candidate_callback(report)
        emit({"phase": "physical_validation", **report})
        return passed
    def loss():
        data = train.evaluate(model, pressure, material, initial)
        result = objective(data, train, model, controls)
        counts["evaluations"] += 1
        return result
    if pressure != config["p0"] or train.history.state.step > 0:
        optimizer = torch.optim.Adam(model.parameters(), lr=controls["adam_lr"])
        try:
            converged = ready()
        except ValueError:
            if model.displacement_context is not None:
                raise
            # Back off the load predictor while retaining its parameter scale.
            with torch.no_grad():
                model.head.weight.mul_(previous_amplitude/float(model.load_amplitude))
                model.head.bias.mul_(previous_amplitude/float(model.load_amplitude))
            converged = False
            counts["invalid_updates"] += 1
        for iteration in range(0 if converged or optimizer_resume is not None else controls["adam_steps"]):
            safe = copy.deepcopy(model.state_dict())
            optimizer.zero_grad(set_to_none=True)
            try:
                value = loss()
                value.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 10.)
                optimizer.step()
                # Reject orientation failures before the next inverse/log.
                model.deformation(train.x, graph=False)
            except ValueError:
                model.load_state_dict(safe)
                counts["invalid_updates"] += 1
                optimizer = torch.optim.Adam(model.parameters(), lr=controls["adam_lr"]*.5)
            if (iteration+1) % controls["check_every"] == 0:
                emit({"phase": "adam", "iteration": iteration+1, "loss": float(value.detach()), **counts})
                if ready():
                    converged = True
                    break
        if not converged and optimizer_resume is None and controls.get("head_newton_steps", 0):
            from mixed_head_newton import head_newton
            counts.update(head_newton(model, train, pressure, material, initial, controls,
                                      controls["head_newton_steps"], emit, stop_check=ready))
            converged = counts.get("head_physics_passed", False)
        if not converged and controls.get("full_newton_steps", 0):
            from mixed_full_newton import full_newton
            counts.update(full_newton(model, train, pressure, material, initial, controls, emit, ready,
                resume_state=progress if optimizer_resume is not None else None,
                state_callback=save_optimizer_state))
            converged = counts.get("full_physics_passed", False)
        optimizer = torch.optim.LBFGS(model.parameters(), lr=1., max_iter=20, max_eval=25,
                                     history_size=50, tolerance_grad=1e-11, tolerance_change=1e-14,
                                     line_search_fn="strong_wolfe")
        # PyTorch rejects curvature pairs when y.s <= 1e-10. Scaling the
        # entire objective preserves its minimizer and relative terms while
        # keeping small-unloading curvature above that absolute cutoff.
        objective_scale = controls.get("lbfgs_objective_scale", 1.)
        progress = {"phase": "lbfgs"}
        start_count = counts["evaluations"]
        while not converged and counts["evaluations"]-start_count < controls["lbfgs_evaluations"]:
            safe = copy.deepcopy(model.state_dict())
            before = counts["evaluations"]
            def closure():
                optimizer.zero_grad(set_to_none=True)
                value = objective_scale*loss()
                value.backward()
                return value
            try:
                value = optimizer.step(closure)/objective_scale
            except ValueError:
                model.load_state_dict(safe)
                counts["invalid_updates"] += 1
                break
            if (counts["evaluations"]-start_count)//controls["check_every"] > (before-start_count)//controls["check_every"]:
                history = optimizer.state[next(iter(model.parameters()))]
                emit({"phase": "lbfgs", "loss": float(value.detach()),
                      "curvature_pairs": len(history.get("old_dirs", [])), **counts})
                if ready():
                    converged = True
            if counts["evaluations"]-before <= 1:
                break
    td = train.evaluate(model, pressure, material, initial, graph=False)
    vd = validation.evaluate(model, pressure, material, initial, graph=False)
    td["pressure"], vd["pressure"] = pressure, pressure
    validation_checks = checks(validation, vd, model, config, initial)
    train_checks = checks(train, td, model, config, initial)
    accepted = validation_checks["accepted"] and train_checks["accepted"]
    if candidate_callback is not None:
        candidate_callback({"pressure_ratio": pressure/model.p0, "training_physics": train_checks,
                            "validation": validation_checks, "physical_checks_passed": accepted, **counts})
    result = {"pressure_ratio": pressure/config["p0"], "accepted": accepted,
              "validation": validation_checks, "training_physics": train_checks, **counts}
    if accepted:
        accept_all([train.history, validation.history], [td["trial"], vd["trial"]], pressure, {"accepted": True})
    else:
        model.load_state_dict(original)
    return result
