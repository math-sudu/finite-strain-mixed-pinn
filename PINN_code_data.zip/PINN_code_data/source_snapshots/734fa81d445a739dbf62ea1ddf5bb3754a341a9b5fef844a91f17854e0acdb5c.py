"""Reproducible, isolated GPU feasibility entry; one process and one seed.

Examples (from project root):
  python code/run_mixed_feasibility.py reference --tag reference_base
  python code/run_mixed_feasibility.py pinn --method W-GH --tag gh
  python code/run_mixed_feasibility.py check --tag integration_checks
Each tag must be new. Config, source snapshots, accepted states, failures and
actual process/CUDA-event timing are saved beneath results/mixed_feasibility.
"""
import os
import time
PROCESS_WALL, PROCESS_CPU = time.perf_counter(), time.process_time()
for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
             "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import traceback
import torch
import dp_material as dp
from mixed_geometry import geometry_from_config, wall_geometry_checks
from mixed_reference import ReferenceSolver
from mixed_pinn import MixedNet, EvaluationPool, train_step, checks
from mixed_history import accept_all

ROOT = Path(__file__).resolve().parents[1]


def snapshot():
    p = subprocess.run(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.free,utilization.gpu",
                        "--format=csv,noheader"], capture_output=True, text=True)
    return p.stdout.strip()


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def observations(solver):
    device, dtype = solver.f0.device, solver.f0.dtype
    arc = torch.tensor([0, 0, 0, 3], device=device)
    frac = torch.tensor([0., 1., .5, .5], device=device, dtype=dtype)
    x, _ = solver.mesh.wall.sample(arc, frac)
    current = x @ solver.f0[:2, :2].T+solver.wall_displacement(arc, frac)
    ids = torch.arange(6, device=device).repeat_interleave(128)
    fr = torch.arange(128, device=device, dtype=dtype).repeat(6)/128
    wx = solver.mesh.wall.sample(ids, fr)[0] @ solver.f0[:2, :2].T
    wu = solver.wall_displacement(ids, fr)
    area0 = wall_geometry_checks(wx)["wall_polygon_area_m2"]
    area = wall_geometry_checks(wx+wu)["wall_polygon_area_m2"]
    return {"width_closure": float(1-(current[0]-current[1]).norm()/13.46),
            "height_closure": float(1-(current[2]-current[3]).norm()/11.05), "area_closure": 1-area/area0}, wu


def run_reference(config, f0, material, out, emit):
    mesh = geometry_from_config(config, ROOT, f0, mesh=config["reference_mesh"])
    solver = ReferenceSolver(mesh, f0, material, config["p0"], config["reference"])
    records = []
    pending = list(config["pressures"])
    while pending:
        pressure = pending.pop(0)
        start = time.perf_counter()
        metrics = solver.solve(pressure*config["p0"])
        metrics["wall_seconds"] = time.perf_counter()-start
        if metrics["accepted"]:
            obs, wall_u = observations(solver)
            metrics.update(obs)
            cp = solver.checkpoint()
            cp["wall_displacement_768"] = wall_u
            torch.save(cp, out/f"accepted_{len(records):03d}.pt")
        records.append(metrics)
        save_json(out/"path.json", records)
        emit({"phase": "reference_step", **metrics})
        if not metrics["accepted"]:
            break
    return {"mode": "reference", "records": records, "dofs": 2*len(mesh.free),
            "volume_points": len(mesh.volume.x), "wall_points": len(mesh.boundary.x)}


def resume_prefix(source, config, f0, initial, material, train, validation, model, out, emit, through=None,
                  recover_interrupted=False):
    folder = ROOT/"results/mixed_feasibility"/source
    if folder.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Resume source must be one run name")
    if (folder/"invalidation.json").exists():
        raise ValueError("An invalidated diagnostic cannot supply an accepted history")
    old_config = json.loads((folder/"config.json").read_text(encoding="utf-8"))
    if recover_interrupted:
        from mixed_recovery import read_interrupted
        old_result = read_interrupted(folder, model.method)
    else:
        old_result = json.loads((folder/"result.json").read_text(encoding="utf-8"))
    if (old_result.get("error") not in (None, "Cooperative stop requested for this run")
            or old_result.get("method") != model.method):
        raise ValueError("Resume requires the same method and a completed or cooperatively stopped run")
    records = []
    accepted = [row["pressure_ratio"] for row in old_result["records"] if row["accepted"]]
    if "accepted_pressures" in old_result and accepted != old_result["accepted_pressures"]:
        raise ValueError("Accepted checkpoint index disagrees with physical-step records")
    files = sorted(folder.glob("accepted_*.pt"))
    if len(files) != len(accepted):
        raise ValueError("Incomplete accepted checkpoint sequence")
    if through is not None:
        matches = [i for i, p in enumerate(accepted) if abs(p-through) < 1e-12]
        if len(matches) != 1:
            raise ValueError("Requested resume endpoint is not one accepted source pressure")
        accepted = accepted[:matches[0]+1]
        files = files[:len(accepted)]
    # A new regional training term may be added only when it is inactive on
    # every reused pressure. Thus the accepted prefix has the same objective,
    # budget, fields, material points and physical acceptance in both runs.
    from mixed_residual import REGIONAL_KEYS, regional_enabled
    def compatible_config(candidate):
        result = {k: v for k, v in candidate.items() if k != "pressures"}
        result["optimizer"] = {k: v for k, v in candidate["optimizer"].items() if k not in REGIONAL_KEYS}
        return result
    if compatible_config(old_config) != compatible_config(config):
        raise ValueError("Resume must preserve material, points, architecture, budgets and physical tolerances")
    changed_regions = any(old_config["optimizer"].get(k) != config["optimizer"].get(k) for k in REGIONAL_KEYS)
    if changed_regions and any(regional_enabled(c["optimizer"], p*c["p0"], c["p0"])
                               for c in (old_config, config) for p in accepted):
        raise ValueError("Changed regional objective was active on the reused pressure prefix")
    if config["pressures"][:len(accepted)] != accepted:
        raise ValueError("Accepted source pressures must be the exact target-path prefix")
    for index, path in enumerate(files):
        begin = time.perf_counter()
        saved = torch.load(path, map_location=f0.device, weights_only=True)
        pressure = accepted[index]*config["p0"]
        if abs(saved["pressure"]-pressure) > 1e-12:
            raise ValueError("Resume pressure does not match the checkpoint")
        model.load_state_dict(saved["network"])
        if not torch.equal(model.f0, f0):
            raise ValueError("Resume changed the natural-reference precompression")
        trials, reports, replay_errors = [], [], []
        for pool, key in ((train, "train_history"), (validation, "validation_history")):
            old = saved[key]
            pool.history.check(old["coordinates"], old["ids"], pool.history.state.step)
            if old["step"] != pool.history.state.step+1 or old["identity_sha256"] != pool.history.key:
                raise ValueError("Resume point identity or load step is inconsistent")
            if old["pressures"] != pool.history.pressures+[pressure]:
                raise ValueError("Resume material state is bound to a different pressure history")
            data = pool.evaluate(model, pressure, material, initial, graph=False)
            data["pressure"] = pressure
            report = checks(pool, data, model, config, initial)
            trial = data["trial"]
            error = max(float((old["cp"]-trial.cp).abs().max()), float((old["kappa"]-trial.kappa).abs().max()))
            if not report["accepted"] or error > 1e-10:
                raise ValueError("Resume prefix failed physical acceptance or material-history replay")
            trials.append(trial)
            reports.append(report)
            replay_errors.append(error)
        accept_all([train.history, validation.history], trials, pressure, {"accepted": True})
        torch.save({"network": model.state_dict(), "pressure": pressure,
            "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint()},
            out/f"accepted_{index:03d}.pt")
        record = {"pressure_ratio": accepted[index], "accepted": True, "replayed_prefix": True,
            "source_run": source, "evaluations": 0, "validation": reports[1], "training_physics": reports[0],
            "history_replay_max_error": max(replay_errors),
            "wall_seconds": time.perf_counter()-begin}
        records.append(record)
        save_json(out/"path.json", records)
        emit({"phase": "replayed_prefix", "method": model.method, **record})
    return records, accepted.copy(), old_result["resources"]


def run_pinn(config, f0, initial, material, out, emit, method, resume=None, resume_through=None,
             recover_interrupted=False):
    trainmesh = geometry_from_config(config, ROOT, f0)
    valmesh = geometry_from_config(config, ROOT, f0, mesh=config["validation_mesh"])
    train = EvaluationPool("training", trainmesh, config["p0"])
    validation = EvaluationPool("validation", valmesh, config["p0"])
    model = MixedNet(config, f0, initial, trainmesh.radius, method)
    records, accepted = [], []
    source_resources = None
    if resume is not None:
        records, accepted, source_resources = resume_prefix(resume, config, f0, initial, material,
            train, validation, model, out, emit, resume_through, recover_interrupted)
    pending = list(config["pressures"])[len(accepted):]
    optimizer_resume = None
    recovery_verification = None
    if recover_interrupted:
        from mixed_recovery import restore_optimizer
        optimizer_resume = restore_optimizer(ROOT/"results/mixed_feasibility"/resume, config, model,
            train, validation, initial, material, pending[0]*config["p0"])
        recovery_verification = optimizer_resume["verification"]
        emit({"phase": "optimizer_recovery_verified", **recovery_verification})
    while pending:
        pressure = pending.pop(0)
        start = time.perf_counter()
        emit({"phase": "start_pressure", "method": method, "pressure_ratio": pressure})
        def save_candidate(report):
            attempt = len(records)
            temporary = out/f"candidate_{attempt:03d}.tmp.pt"
            torch.save({"network": model.state_dict(), "pressure": pressure*config["p0"], "accepted": False,
                "old_accepted_file": f"accepted_{len(accepted)-1:03d}.pt" if accepted else None,
                "training_state_step": train.history.state.step, "validation_state_step": validation.history.state.step,
                "training_identity": train.history.key, "validation_identity": validation.history.key,
                "physical_report": report}, temporary)
            temporary.replace(out/f"candidate_{attempt:03d}.pt")
        metrics = train_step(model, train, validation, pressure*config["p0"], material, initial, config, emit,
                             save_candidate, optimizer_resume=optimizer_resume)
        optimizer_resume = None
        metrics["wall_seconds"] = time.perf_counter()-start
        if metrics["accepted"]:
            step = {"network": model.state_dict(), "pressure": pressure*config["p0"],
                    "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint()}
            torch.save(step, out/f"accepted_{len(accepted):03d}.pt")
            accepted.append(pressure)
        records.append(metrics)
        save_json(out/"path.json", records)
        emit({"phase": "pinn_step", "method": method, **metrics})
        if not metrics["accepted"]:
            # Full parameter rollback already occurred. No failed trial is committed.
            previous = accepted[-1] if accepted else 1.
            if previous-pressure >= 2*config["minimum_pressure_increment"]-1e-12:
                middle = round(.5*(previous+pressure), 12)
                pending[0:0] = [middle, pressure]
                emit({"phase": "load_step_bisection", "rejected": pressure, "retry": middle})
            else:
                break
    return {"mode": "pinn", "method": method, "records": records, "accepted_pressures": accepted,
            "resumed_from": resume, "resumed_through": resume_through,
            "recovered_interrupted_optimizer": recover_interrupted, "recovery_verification": recovery_verification,
            "source_run_resources": source_resources,
            "source_resource_scope": "Entire source run, including diagnostics; excluded from this run's timers and not a prefix-only cost",
            "parameters": sum(p.numel() for p in model.parameters()),
            "training_points": len(train.x), "validation_points": len(validation.x),
            "training_identity": train.history.key, "validation_identity": validation.history.key}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["reference", "pinn", "check"])
    parser.add_argument("--config", default="config/mixed_horseshoe_feasibility.json")
    parser.add_argument("--tag", required=True)
    parser.add_argument("--method", choices=["W-GH", "W-LH", "W-RH"], default="W-GH")
    parser.add_argument("--resume-run")
    parser.add_argument("--recover-interrupted", action="store_true")
    parser.add_argument("--resume-through", type=float, help="Replay only through this accepted source pressure ratio")
    parser.add_argument("--angular", type=int)
    parser.add_argument("--radial", type=int)
    parser.add_argument("--quadrature", type=int)
    parser.add_argument("--degree", type=int, choices=[1, 2])
    parser.add_argument("--outer", type=float)
    parser.add_argument("--pressures", nargs="+", type=float)
    parser.add_argument("--max-pressure-step", type=float)
    parser.add_argument("--linear-solver", choices=["dense", "bicgstab"])
    args = parser.parse_args()
    if args.resume_through is not None and args.resume_run is None:
        parser.error("--resume-through requires --resume-run")
    if args.recover_interrupted and (args.resume_run is None or args.resume_through is not None or args.mode != "pinn"):
        parser.error("Interrupted recovery requires a complete --resume-run prefix in pinn mode")
    config = json.loads((ROOT/args.config).read_text(encoding="utf-8"))
    if args.linear_solver is not None:
        config["reference"]["linear_solver"] = args.linear_solver
    if args.pressures is not None:
        config["pressures"] = args.pressures
    if args.max_pressure_step is not None:
        refined = [config["pressures"][0]]
        for left, right in zip(config["pressures"][:-1], config["pressures"][1:]):
            count = max(1, math.ceil((abs(right-left)-1e-12)/args.max_pressure_step))
            refined.extend(round(left+(right-left)*i/count, 12) for i in range(1, count+1))
        config["pressures"] = refined
    for key in ("angular", "radial", "quadrature", "degree"):
        if getattr(args, key) is not None:
            config["reference_mesh"][key] = getattr(args, key)
    if args.outer is not None:
        config["outer_widths"] = args.outer
    if not config["device"].startswith("cuda:") or not torch.cuda.is_available():
        raise RuntimeError("CUDA required; no CPU fallback")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.use_deterministic_algorithms(config.get("deterministic_algorithms", False))
    torch.cuda.set_device(config["device"])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.manual_seed(config["seed"])
    out = ROOT/"results/mixed_feasibility"/args.tag
    if out.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Tag must be one directory name")
    out.mkdir(parents=True, exist_ok=False)
    save_json(out/"config.json", config)
    sources = ["code/dp_material.py", "code/current_traction.py", "code/horseshoe_geometry.py",
               "code/mixed_geometry.py", "code/dp_reference.py", "code/mixed_reference.py",
               "code/mixed_history.py", "code/mixed_pinn.py", "code/run_mixed_feasibility.py",
               "code/mixed_reference_sampling.py", "code/compare_mixed_feasibility.py",
               "code/mixed_head_newton.py", "code/assess_mixed_pinn.py", "tests/test_mixed_head_newton.py",
               "code/mixed_q2.py", "code/mixed_krylov.py", "code/check_reference_energy.py",
               "code/mixed_residual.py", "code/mixed_full_newton.py",
               "code/mixed_dense_jacobian.py",
               "code/mixed_local_jacobian.py",
               "tests/test_mixed_feasibility.py", config["geometry"]]
    sources.append("tests/test_mixed_determinism.py")
    sources.append("code/mixed_recovery.py")
    hashes = {}
    (out/"sources").mkdir()
    for name in sources:
        source = ROOT/name
        if source.exists():
            data = source.read_bytes()
            hashes[name] = hashlib.sha256(data).hexdigest()
            (out/"sources"/source.name).write_bytes(data)
    f0, _, initial = dp.elastic_precompression(dp.DPParameters.from_young_poisson(**config["material"]),
                        torch.tensor(config["p0"], device=config["device"], dtype=torch.float64))
    material = dp.DPParameters.from_young_poisson(**config["material"])
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    wall, cpu = time.perf_counter(), time.process_time()
    before = snapshot()
    begin.record()
    events = open(out/"events.jsonl", "a", encoding="utf-8", buffering=1)
    def emit(data):
        item = {"elapsed_wall_seconds": time.perf_counter()-wall, "elapsed_process_cpu_seconds": time.process_time()-cpu,
                "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                "peak_reserved_bytes": torch.cuda.max_memory_reserved(), **data}
        line = json.dumps(item, allow_nan=False)
        print(line, flush=True)
        events.write(line+"\n")
        if data.get("phase") != "finished" and "error" not in data and (out/"stop.request").exists():
            raise RuntimeError("Cooperative stop requested for this run")
    emit({"phase": "initialized", "device": str(f0.device), "dtype": str(f0.dtype),
          "threads": [torch.get_num_threads(), torch.get_num_interop_threads()], "gpu_before": before})
    code, result = 0, {}
    try:
        if args.mode == "reference":
            result = run_reference(config, f0, material, out, emit)
        elif args.mode == "pinn":
            result = run_pinn(config, f0, initial, material, out, emit, args.method, args.resume_run,
                              args.resume_through, args.recover_interrupted)
        else:
            sys.path.insert(0, str(ROOT/"tests"))
            from test_mixed_feasibility import run_checks
            result = run_checks(config, f0, initial, material, emit)
            from test_mixed_head_newton import run_head_checks
            result["head_checks"] = run_head_checks(config, f0, initial, material, emit)
            from test_mixed_determinism import run_determinism_check
            result["determinism_check"] = run_determinism_check(config, f0, initial, material, emit)
    except Exception as error:
        code = 1
        result = {"error": str(error), "traceback": traceback.format_exc()}
        emit(result)
    finally:
        end.record()
        torch.cuda.synchronize()
        result.setdefault("mode", args.mode)
        if args.mode == "pinn":
            result.setdefault("method", args.method)
        if "records" not in result and (out/"path.json").exists():
            result["records"] = json.loads((out/"path.json").read_text(encoding="utf-8"))
        result["resources"] = {"wall_seconds": time.perf_counter()-wall, "process_cpu_seconds": time.process_time()-cpu,
            "cuda_event_span_seconds_including_host_gaps": begin.elapsed_time(end)/1000,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "process_wall_including_imports": time.perf_counter()-PROCESS_WALL,
            "process_cpu_including_imports": time.process_time()-PROCESS_CPU,
            "gpu_before": before, "gpu_after": snapshot(), "pid": os.getpid(),
            "torch": torch.__version__, "cuda_build": torch.version.cuda, "python": sys.version,
            "device": str(f0.device), "dtype": str(f0.dtype), "tensor_threads": torch.get_num_threads(),
            "interop_threads": torch.get_num_interop_threads()}
        result["resources"]["deterministic_algorithms"] = torch.are_deterministic_algorithms_enabled()
        result["resources"]["cublas_workspace_config"] = os.environ["CUBLAS_WORKSPACE_CONFIG"]
        result["source_sha256"] = hashes
        result["source_unchanged"] = all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest() == h for p, h in hashes.items())
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        save_json(out/"result.json", result)
        emit({"phase": "finished", "exit_code": code, "resources": result["resources"]})
        events.close()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
