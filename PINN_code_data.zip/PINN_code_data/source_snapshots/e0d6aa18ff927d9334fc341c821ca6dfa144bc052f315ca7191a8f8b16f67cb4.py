"""Coordinate/ID-bound histories and atomic load-step acceptance."""
from dataclasses import dataclass
import hashlib
import torch
import dp_material as dp


def identity(x, ids):
    # Host transfer is serialization only; all state arithmetic stays on GPU.
    return hashlib.sha256(x.detach().cpu().numpy().tobytes()+ids.cpu().numpy().tobytes()).hexdigest()


class PointHistory:
    def __init__(self, name, x, initial_pressure):
        if not (x.is_cuda and x.dtype == torch.float64):
            raise ValueError("History requires CUDA float64 coordinates")
        self.name, self.x = name, x.detach().clone()
        self.ids = torch.arange(len(x), device=x.device)
        self.key = identity(self.x, self.ids)
        self.state = dp.MaterialState.virgin((len(x),), device=x.device)
        self.pressures = [initial_pressure]

    def check(self, x, ids, step):
        if step != self.state.step or not torch.equal(ids, self.ids) or not torch.equal(x, self.x):
            raise ValueError("Material point identity/order/coordinates or load step changed")

    def trial(self, f, x, ids, step, material):
        self.check(x, ids, step)
        return dp.evaluate(f, self.state, material)

    def checkpoint(self):
        return {"name": self.name, "coordinates": self.x, "ids": self.ids, "identity_sha256": self.key,
                "cp": self.state.cp, "kappa": self.state.kappa, "step": self.state.step,
                "pressures": self.pressures.copy()}


def accept_all(pools, trials, pressure, physical_checks):
    """Prepare every state first; a failed/stale trial cannot partially commit."""
    if not physical_checks.get("accepted", False):
        raise ValueError("Independent physical checks rejected the load step")
    if len(pools) != len(trials) or len({p.state.step for p in pools}) != 1:
        raise ValueError("Inconsistent point pools/load steps")
    prepared = []
    for pool, trial in zip(pools, trials):
        if identity(pool.x, pool.ids) != pool.key:
            raise ValueError("Point pool changed after initialization")
        prepared.append(dp.commit_state(pool.state, trial))
    for pool, new in zip(pools, prepared):
        pool.state = new
        pool.pressures.append(pressure)


def replay(model, saved_steps, x, material, initial_pressure):
    """Reconstruct new material coordinates using every accepted displacement.

    saved_steps contains accepted model state_dicts in chronological order.
    The caller supplies a separate model instance; live training is untouched.
    """
    pool = PointHistory("replayed", x, initial_pressure)
    for step in saved_steps:
        if "configuration_displacement_version" in step["network"]:
            raise ValueError("A conditional configuration field requires its dedicated context loader")
        model.load_state_dict(step["network"])
        f = model.deformation(x, graph=False)[1]
        trial = pool.trial(f, x, pool.ids, pool.state.step, material)
        pool.state = dp.commit_state(pool.state, trial)
        pool.pressures.append(step["pressure"])
    return pool
