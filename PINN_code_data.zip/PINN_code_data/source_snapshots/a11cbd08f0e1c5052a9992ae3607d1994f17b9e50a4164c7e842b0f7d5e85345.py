"""Repeat the actual Adam graph from the same seed and frozen old history."""
from pathlib import Path
import torch
from mixed_geometry import geometry_from_config
from mixed_pinn import MixedNet, EvaluationPool
from mixed_residual import objective


def run_determinism_check(config, f0, initial, material, emit):
    if not config.get("deterministic_algorithms", False):
        return {"performed": False, "reason": "Recorded legacy configuration does not request deterministic algorithms"}
    assert torch.are_deterministic_algorithms_enabled()
    root = Path(__file__).resolve().parents[1]
    mesh = geometry_from_config(config, root, f0)
    pool = EvaluationPool("determinism", mesh, config["p0"])
    old = pool.history.state
    outcomes, traces = [], []
    for repeat in range(2):
        torch.manual_seed(config["seed"])
        model = MixedNet(config, f0, initial, mesh.radius, "W-GH")
        model.set_pressure(.98)
        optimizer = torch.optim.Adam(model.parameters(), lr=config["optimizer"]["adam_lr"])
        values = []
        for iteration in range(40):
            optimizer.zero_grad(set_to_none=True)
            data = pool.evaluate(model, .98, material, initial)
            loss = objective(data, pool, model, config["optimizer"])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 10.)
            optimizer.step()
            values.append(loss.detach())
        outcomes.append(torch.cat([p.detach().flatten() for p in model.parameters()]))
        traces.append(torch.stack(values))
        assert pool.history.state is old and old.step == 0 and old.kappa.max() == 0
        emit({"check": "deterministic_adam_repeat", "repeat": repeat+1, "iterations": 40,
              "final_loss": float(values[-1]), "history_unchanged": True})
    parameter_error = float((outcomes[0]-outcomes[1]).abs().max())
    loss_error = float((traces[0]-traces[1]).abs().max())
    assert parameter_error == 0 and loss_error == 0
    report = {"performed": True, "repetitions": 2, "iterations_per_repeat": 40,
              "parameter_max_difference": parameter_error, "loss_max_difference": loss_error,
              "scope": "Same host/process, same seed, actual full training-point Adam graph"}
    emit({"check": "deterministic_adam_equivalence", **report})
    return report
