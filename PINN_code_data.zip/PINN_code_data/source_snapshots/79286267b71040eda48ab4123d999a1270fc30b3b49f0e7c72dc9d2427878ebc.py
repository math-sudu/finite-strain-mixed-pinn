"""Mixed weak PINN with current traction and fixed material histories.

The loss is a squared virtual-work residual plus constitutive consistency,
not a total potential for a nonassociated material. Reference FEM fields
never enter this module, loss, initialization or checkpoint selection.
"""
import copy
import torch
from torch import nn
import dp_material as dp
import current_traction as ct
from mixed_history import PointHistory, accept_all
from mixed_geometry import wall_geometry_checks, MultiScaleTests
from mixed_residual import constitutive_work, objective


METHODS = {"W-GH": "cartesian", "W-LH": "current", "W-RH": "initial"}


class MixedNet(nn.Module):
    def __init__(self, config, f0, initial, radius, method):
        super().__init__()
        self.method, self.basis = method, METHODS[method]
        self.p0, self.length = config["p0"], 13.46
        self.displacement_scale = config["p0"]/config["material"]["young"]
        self.inverse_square = config.get("field_scaling") == "inverse_square_exterior_envelope"
        self.lstar = self.length/float(f0[0, 0])
        self.radius, self.delta = float(radius), config["collar_precompressed_m"]/float(f0[0, 0])
        self.register_buffer("f0", f0.clone())
        self.register_buffer("initial_stress", initial.sigma.clone())
        self.load_floor = config.get("load_scaling", {}).get("minimum_amplitude")
        if self.load_floor is None:
            self.load_amplitude = 1.
        else:
            self.register_buffer("load_amplitude", f0.new_tensor(self.load_floor))
        layers, width = [], config["network"]["width"]
        for i in range(config["network"]["depth"]):
            layers.extend((nn.Linear(2 if i == 0 else width, width), nn.Tanh()))
        self.body = nn.Sequential(*layers)
        self.coordinate_features = config["network"].get("coordinate_features") == "linear_angular_quadratic"
        self.head = nn.Linear(width+(5 if self.coordinate_features else 0), 10)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)
        self.to(device=f0.device, dtype=f0.dtype)
        if config["network"].get("initializer") == "xavier_tanh":
            # Common initialization only; input remains X/L* and capacity is
            # unchanged. Preserve nonzero biases for even spatial features.
            with torch.no_grad():
                for index, layer in enumerate(self.body):
                    if isinstance(layer, nn.Linear):
                        nn.init.xavier_uniform_(layer.weight, gain=nn.init.calculate_gain("tanh"))
                        nn.init.uniform_(layer.bias, -.1, .1)
                        if index == 0:
                            layer.weight.mul_(config["network"]["input_gain"])

    def set_pressure(self, pressure):
        if self.load_floor is not None:
            with torch.no_grad():
                self.load_amplitude.fill_(max(abs(1-pressure/self.p0), self.load_floor))

    def features(self, x):
        z = x/self.lstar
        learned = self.body(z)
        if not self.coordinate_features:
            return learned
        r2 = z.square().sum(-1)
        # Shared exterior coordinate basis: linear terms support 1/r
        # displacement, angular terms support 1/r^2 stress, and r^2
        # supports the finite-outer-boundary constant stress correction.
        direct = torch.stack((z[:, 0], z[:, 1], (z[:, 0]**2-z[:, 1]**2)/r2,
                              2*z[:, 0]*z[:, 1]/r2, r2), -1)
        return torch.cat((learned, direct), -1)

    def fields(self, x):
        # A strictly positive known load scale changes parameter conditioning,
        # not the admissible fields. Its checkpointed buffer makes replay exact.
        outputs = self.load_amplitude*self.head(self.features(x))
        r2 = x.square().sum(-1)/self.lstar**2
        # Common smooth positive factor; both outer displacement components vanish.
        denominator = r2 if self.inverse_square else 1+r2
        # The origin is inside the excluded cavity. This positive exterior
        # scaling supplies the elastic 1/r displacement decay for a linear
        # head, without prescribing a circular solution or a field label.
        dp.require(denominator > 0, "Field envelope is defined only outside the cavity")
        envelope = (1-x.square().sum(-1)/self.radius**2)/denominator
        u = self.length*self.displacement_scale*envelope[:, None]*outputs[:, :2]
        base = torch.stack((self.initial_stress[0, 0], self.initial_stress[0, 1],
                            self.initial_stress[1, 1], self.initial_stress[2, 2]))/self.p0
        wall = self.p0*(outputs[:, 2:6]+base)
        outer_correction = outputs[:, 6:10]/r2[:, None] if self.inverse_square else outputs[:, 6:10]
        outer = self.p0*(outer_correction+base)
        return u, wall, outer

    def deformation(self, points, graph=True):
        x = points.detach().clone().requires_grad_(True)
        u, aw, ao = self.fields(x)
        grad = torch.stack([torch.autograd.grad(u[:, i].sum(), x, create_graph=graph,
                                               retain_graph=True)[0] for i in range(2)], -2)
        f = dp.plane_tensor(self.f0[:2, :2]+grad)
        dp.check_deformation(f)
        if not graph:
            return tuple(t.detach() for t in (u, f, aw, ao))
        return u, f, aw, ao


class EvaluationPool:
    def __init__(self, name, mesh, initial_pressure):
        self.mesh = mesh
        self.nv = len(mesh.volume.x)
        self.x = torch.cat((mesh.volume.x, mesh.boundary.x))
        self.history = PointHistory(name, self.x, initial_pressure)
        self.tests = MultiScaleTests(mesh, 2*float(mesh.wall.radii[0]),
                                     shift=1.13 if name == "validation" else 1.)
        projection = mesh.wall.project(self.x)
        self.distance, self.normal = projection.distance.detach(), projection.normal.detach()
        # Wall quadrature carries analytic normals and exactly d=0.
        self.distance[self.nv:] = 0
        self.normal[self.nv:] = mesh.boundary.normal

    def evaluate(self, model, pressure, material, initial, graph=True):
        u, f, aw, ao = model.deformation(self.x, graph)
        state = self.history
        trial = state.trial(f, self.x, state.ids, state.state.step, material)
        stress = ct.blended_stress(f, aw, ao, self.distance, self.normal, pressure, model.delta,
                                  basis=model.basis, initial_f=model.f0.expand_as(f))
        piola = dp.cauchy_to_piola(f, stress)
        weak = self.mesh.weak(piola[:self.nv], f[self.nv:], pressure, model.p0, model.f0, initial.piola)
        multi = self.tests.residual(piola[:self.nv], f[self.nv:], pressure, model.p0, model.f0, initial.piola)
        cweak, cmulti = constitutive_work(self, piola[:self.nv]-trial.piola[:self.nv], model.p0)
        rmweak, rmmulti = weak-cweak, multi-cmulti
        error = (stress-trial.sigma)/model.p0
        return {"u": u, "f": f, "trial": trial, "stress": stress, "weak": weak, "pressure": pressure,
                "material_weak": rmweak, "multi": multi, "material_multi": rmmulti, "error": error,
                "constitutive_weak": cweak, "constitutive_multi": cmulti}

    def consistency(self, data, delta):
        # Region-balanced Frobenius norm; far-domain volume cannot hide wall errors.
        norm = data["error"].square().sum((-2, -1))
        d = self.distance[:self.nv]
        masks = (d < delta, (d >= delta) & (d < 2*delta), d >= 2*delta)
        return torch.stack([norm[:self.nv][mask].mean() for mask in masks]+[norm[self.nv:].mean()]).mean()


def checks(pool, data, model, config, initial):
    trial, f = data["trial"], data["f"]
    nv, b = pool.nv, pool.mesh.boundary
    n, _, area = ct.current_frame(f[nv:], b.normal)
    pressure = data["pressure"]
    tnet = (data["stress"][nv:] @ n[:, :, None]).squeeze(-1)+pressure*n
    trm = (trial.sigma[nv:] @ n[:, :, None]).squeeze(-1)+pressure*n
    d = pool.distance[:nv]
    errors = data["error"].square().sum((-2, -1))
    out = {"consistency_rms": float(pool.consistency(data, model.delta).sqrt()),
        "consistency_wall_rms": float(errors[nv:].mean().sqrt()),
        "consistency_collar_rms": float(errors[:nv][d < model.delta].mean().sqrt()),
        "consistency_transition_rms": float(errors[:nv][(d >= model.delta) & (d < 2*model.delta)].mean().sqrt()),
        "consistency_outer_rms": float(errors[:nv][d >= 2*model.delta].mean().sqrt()),
        "traction_material_rms": float(trm.square().sum(-1).mean().sqrt()/model.p0),
        "hard_traction_max": float(tnet.abs().max()/model.p0),
        "weak_rms": float(data["weak"].square().mean().sqrt()),
        "weak_max": float(data["weak"].abs().max()),
        "material_weak_rms": float(data["material_weak"].square().mean().sqrt()),
        "material_weak_max": float(data["material_weak"].abs().max()),
        "multiscale_weak_rms": float(data["multi"].square().mean().sqrt()),
        "multiscale_weak_max": float(data["multi"].abs().max()),
        "multiscale_material_weak_rms": float(data["material_multi"].square().mean().sqrt()),
        "multiscale_material_weak_max": float(data["material_multi"].abs().max()),
        "j_min": float(torch.linalg.det(f).min()), "yield_max": float(trial.yield_value.max()/model.p0),
        "plastic_volume_max": float((.5*torch.linalg.slogdet(trial.cp)[1]-config["material"]["beta"]*trial.kappa).abs().max()),
        "cp_eigenvalue_min": float(torch.stack([torch.linalg.eigvalsh(chunk).min()
                                                for chunk in trial.cp.split(4096)]).min()),
        "endpoint_dissipation_min": float((trial.tau*(trial.trial_log-trial.elastic_log)).sum((-2, -1)).min()),
        "kappa_max": float(trial.kappa.max()), "delta_lambda_max": float(trial.delta_lambda.max()),
        "cumulative_plastic_area_m2": float((pool.mesh.volume.weight*(trial.kappa[:nv] > config["plastic_threshold"])).sum()),
        "active_plastic_area_m2": float((pool.mesh.volume.weight*(trial.delta_lambda[:nv] > config["plastic_threshold"])).sum()),
        "current_area_ratio_min": float((area/model.f0[0, 0]).min()),
        "current_area_ratio_max": float((area/model.f0[0, 0]).max()),
        "normal_rotation_max_rad": float(torch.atan2(torch.linalg.cross(b.normal, n).norm(dim=-1), (b.normal*n).sum(-1)).max())}
    # Independent, denser wall polygon and exact fixed material gauge points.
    ids = torch.arange(6, device=f.device).repeat_interleave(128)
    frac = torch.arange(128, device=f.device, dtype=f.dtype).repeat(6)/128
    wallx, _ = pool.mesh.wall.sample(ids, frac)
    wu = model.fields(wallx)[0]
    xcur = wallx @ model.f0[:2, :2].T+wu
    out.update(wall_geometry_checks(xcur))
    initial_geo = wall_geometry_checks(wallx @ model.f0[:2, :2].T)
    out["area_closure"] = 1-out["wall_polygon_area_m2"]/initial_geo["wall_polygon_area_m2"]
    gauges = torch.tensor([[6.73, 0], [-6.73, 0], [0, 6.73], [0, -4.32]], device=f.device, dtype=f.dtype)
    cur = gauges+model.fields(gauges/model.f0[0, 0])[0].detach()
    out["width_closure"] = float(1-(cur[0]-cur[1]).norm()/13.46)
    out["height_closure"] = float(1-(cur[2]-cur[3]).norm()/11.05)
    scale = (max(abs(1-pressure/model.p0), config["load_scaling"]["minimum_amplitude"])
             if config.get("acceptance_scaling") == "unloading_amplitude" else 1.)
    relative_keys = {"consistency_rms", "traction_material_rms", "weak_rms", "weak_max"}
    if config.get("constitutive_acceptance_scaling") == "p0":
        relative_keys.remove("consistency_rms")
    thresholds = {key: value*scale if key in relative_keys else value for key, value in config["acceptance"].items()}
    out["physical_residual_scale"] = scale
    out["effective_thresholds"] = thresholds
    failed = [key for key, tol in thresholds.items() if (out[key] < tol if key == "j_min" else out[key] > tol)]
    if out["cp_eigenvalue_min"] <= 0 or out["endpoint_dissipation_min"] < -1e-11:
        failed.append("material_admissibility")
    if out["wall_self_intersections"] or out["wall_polygon_area_m2"] <= 0:
        failed.append("wall_geometry")
    if out["material_weak_rms"] > thresholds["weak_rms"] or out["material_weak_max"] > thresholds["weak_max"]:
        failed.append("material_virtual_work")
    if (out["multiscale_weak_max"] > thresholds["weak_rms"]
            or out["multiscale_material_weak_max"] > thresholds["weak_rms"]):
        failed.append("multiscale_virtual_work")
    if pressure < model.p0 and min(out["width_closure"], out["height_closure"], out["area_closure"]) < -1e-7:
        failed.append("small_unloading_response_sign")
    if max(out["consistency_wall_rms"], out["consistency_collar_rms"], out["consistency_transition_rms"],
           out["consistency_outer_rms"]) > thresholds["consistency_rms"]:
        failed.append("regional_consistency")
    out["accepted"], out["failed_checks"] = not failed, failed
    return out


def train_step(model, train, validation, pressure, material, initial, config, emit, candidate_callback=None,
               optimizer_resume=None):
    original = copy.deepcopy(model.state_dict())
    previous_amplitude = float(model.load_amplitude)
    model.set_pressure(pressure)
    controls = config["optimizer"]
    counts = {"evaluations": 0, "invalid_updates": 0, "physical_checks": 0}
    progress = {"phase": "initial"}
    if optimizer_resume is not None:
        model.load_state_dict(optimizer_resume["network"])
        model.set_pressure(pressure)
        counts.update(optimizer_resume["training_counts"])
        progress = optimizer_resume["optimizer_checkpoint"].copy()
    def save_optimizer_state(state):
        nonlocal progress
        progress = state
    def ready():
        counts["physical_checks"] += 1
        passed = True
        reports = []
        for pool in (train, validation):
            candidate = pool.evaluate(model, pressure, material, initial, graph=False)
            candidate["pressure"] = pressure
            verdict = checks(pool, candidate, model, config, initial)
            passed = passed and verdict["accepted"]
            reports.append(verdict)
        report = {"pressure_ratio": pressure/model.p0, "training_physics": reports[0],
                  "validation": reports[1], "physical_checks_passed": passed,
                  "optimizer_checkpoint": progress, **counts}
        if candidate_callback is not None:
            candidate_callback(report)
        emit({"phase": "physical_validation", **report})
        return passed
    def loss():
        data = train.evaluate(model, pressure, material, initial)
        result = objective(data, train, model, controls)
        counts["evaluations"] += 1
        return result
    if pressure != config["p0"] or train.history.state.step > 0:
        optimizer = torch.optim.Adam(model.parameters(), lr=controls["adam_lr"])
        try:
            converged = ready()
        except ValueError:
            # Back off the load predictor while retaining its parameter scale.
            with torch.no_grad():
                model.head.weight.mul_(previous_amplitude/float(model.load_amplitude))
                model.head.bias.mul_(previous_amplitude/float(model.load_amplitude))
            converged = False
            counts["invalid_updates"] += 1
        for iteration in range(0 if converged or optimizer_resume is not None else controls["adam_steps"]):
            safe = copy.deepcopy(model.state_dict())
            optimizer.zero_grad(set_to_none=True)
            try:
                value = loss()
                value.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 10.)
                optimizer.step()
                # Reject orientation failures before the next inverse/log.
                model.deformation(train.x, graph=False)
            except ValueError:
                model.load_state_dict(safe)
                counts["invalid_updates"] += 1
                optimizer = torch.optim.Adam(model.parameters(), lr=controls["adam_lr"]*.5)
            if (iteration+1) % controls["check_every"] == 0:
                emit({"phase": "adam", "iteration": iteration+1, "loss": float(value.detach()), **counts})
                if ready():
                    converged = True
                    break
        if not converged and optimizer_resume is None and controls.get("head_newton_steps", 0):
            from mixed_head_newton import head_newton
            counts.update(head_newton(model, train, pressure, material, initial, controls,
                                      controls["head_newton_steps"], emit, stop_check=ready))
            converged = counts.get("head_physics_passed", False)
        if not converged and controls.get("full_newton_steps", 0):
            from mixed_full_newton import full_newton
            counts.update(full_newton(model, train, pressure, material, initial, controls, emit, ready,
                resume_state=progress if optimizer_resume is not None else None,
                state_callback=save_optimizer_state))
            converged = counts.get("full_physics_passed", False)
        optimizer = torch.optim.LBFGS(model.parameters(), lr=1., max_iter=20, max_eval=25,
                                     history_size=50, tolerance_grad=1e-11, tolerance_change=1e-14,
                                     line_search_fn="strong_wolfe")
        # PyTorch rejects curvature pairs when y.s <= 1e-10. Scaling the
        # entire objective preserves its minimizer and relative terms while
        # keeping small-unloading curvature above that absolute cutoff.
        objective_scale = controls.get("lbfgs_objective_scale", 1.)
        progress = {"phase": "lbfgs"}
        start_count = counts["evaluations"]
        while not converged and counts["evaluations"]-start_count < controls["lbfgs_evaluations"]:
            safe = copy.deepcopy(model.state_dict())
            before = counts["evaluations"]
            def closure():
                optimizer.zero_grad(set_to_none=True)
                value = objective_scale*loss()
                value.backward()
                return value
            try:
                value = optimizer.step(closure)/objective_scale
            except ValueError:
                model.load_state_dict(safe)
                counts["invalid_updates"] += 1
                break
            if (counts["evaluations"]-start_count)//controls["check_every"] > (before-start_count)//controls["check_every"]:
                history = optimizer.state[next(iter(model.parameters()))]
                emit({"phase": "lbfgs", "loss": float(value.detach()),
                      "curvature_pairs": len(history.get("old_dirs", [])), **counts})
                if ready():
                    converged = True
            if counts["evaluations"]-before <= 1:
                break
    td = train.evaluate(model, pressure, material, initial, graph=False)
    vd = validation.evaluate(model, pressure, material, initial, graph=False)
    td["pressure"], vd["pressure"] = pressure, pressure
    validation_checks = checks(validation, vd, model, config, initial)
    train_checks = checks(train, td, model, config, initial)
    accepted = validation_checks["accepted"] and train_checks["accepted"]
    if candidate_callback is not None:
        candidate_callback({"pressure_ratio": pressure/model.p0, "training_physics": train_checks,
                            "validation": validation_checks, "physical_checks_passed": accepted, **counts})
    result = {"pressure_ratio": pressure/config["p0"], "accepted": accepted,
              "validation": validation_checks, "training_physics": train_checks, **counts}
    if accepted:
        accept_all([train.history, validation.history], [td["trial"], vd["trial"]], pressure, {"accepted": True})
    else:
        model.load_state_dict(original)
    return result
