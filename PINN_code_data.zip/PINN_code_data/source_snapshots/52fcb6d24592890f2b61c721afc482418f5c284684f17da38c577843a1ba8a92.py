"""Verify the reduced head residual against the full mixed AD graph."""
import copy
from pathlib import Path
import torch
from mixed_geometry import geometry_from_config
from mixed_pinn import MixedNet, EvaluationPool
from mixed_head_newton import HeadResidual, head_newton
from mixed_residual import objective
from mixed_full_newton import FullResidual, full_newton


def run_head_checks(config, f0, initial, material, emit):
    small = copy.deepcopy(config)
    small["network"].update(width=8, depth=2)
    root = Path(__file__).resolve().parents[1]
    mesh = geometry_from_config(small, root, f0, mesh={"angular": 16, "radial": 4, "quadrature": 3})
    pool = EvaluationPool("head_test", mesh, config["p0"])
    metrics = {}
    for method in ("W-GH", "W-LH", "W-RH"):
        model = MixedNet(small, f0, initial, mesh.radius, method)
        with torch.no_grad():
            model.head.weight.normal_(0, .001)
            model.head.bias.normal_(0, .001)
        reduced = HeadResidual(model, pool, .98, material, initial, config["optimizer"])
        weights = reduced.parameters()
        r = reduced.residual(weights)
        full = pool.evaluate(model, .98, material, initial)
        loss = objective(full, pool, model, config["optimizer"])
        value_error = float((r.square().sum()-loss).abs().detach())
        assert value_error < 1e-12
        dw, db = torch.autograd.grad(loss, (model.head.weight, model.head.bias))
        gradient = torch.cat((dw, db[:, None]), -1).flatten()
        direction = torch.randn_like(weights)
        _, dr = torch.func.jvp(reduced.residual, (weights,), (direction,))
        expected = gradient @ direction
        actual = 2*(r*dr).sum()
        derivative_error = float(((expected-actual).abs()/expected.abs().clamp_min(1e-10)).detach())
        assert derivative_error < 1e-7
        old = pool.history.state
        before = float(loss.detach())
        head_newton(model, pool, .98, material, initial, config["optimizer"], 1, emit)
        new_reduced = HeadResidual(model, pool, .98, material, initial, config["optimizer"])
        after = float(new_reduced.residual(new_reduced.parameters()).square().sum())
        assert after < before
        assert pool.history.state is old and old.kappa.max() == 0
        metrics[method] = {"value_error": value_error, "directional_derivative_error": derivative_error,
                           "loss_before": before, "loss_after": after, "history_unchanged": True}
        emit({"check": "head_residual_full_graph_equivalence", "method": method, **metrics[method]})
        complete = FullResidual(model, pool, .98, material, initial, config["optimizer"])
        parameters = complete.parameters()
        explicit = complete.fields(parameters)
        automatic = model.deformation(pool.x)
        spatial_error = max(float((a-b).abs().max().detach()) for a, b in zip(explicit, automatic[1:]))
        assert spatial_error < 1e-12
        full = pool.evaluate(model, .98, material, initial)
        expected_loss = objective(full, pool, model, config["optimizer"])
        expected_gradient = torch.cat([v.flatten() for v in torch.autograd.grad(expected_loss, tuple(model.parameters()))])
        r, backward = torch.func.vjp(complete.residual, parameters)
        actual_gradient = 2*backward(r)[0]
        gradient_error = float((expected_gradient-actual_gradient).norm()/expected_gradient.norm())
        assert gradient_error < 1e-9
        vector = torch.randn_like(parameters)
        other = torch.randn_like(parameters)
        _, jv = torch.func.jvp(complete.residual, (parameters,), (vector,))
        transpose_error = float(((r*jv).sum()-backward(r)[0] @ vector).abs())
        assert transpose_error < 1e-9
        _, jo = torch.func.jvp(complete.residual, (parameters,), (other,))
        symmetry_error = float((other @ backward(jv)[0]-vector @ backward(jo)[0]).abs())
        assert symmetry_error < 1e-8
        # The volume-only difference must reproduce material virtual work,
        # including the same current boundary load exactly once.
        raw_material = mesh.weak(full["trial"].piola[:pool.nv], full["f"][pool.nv:], .98,
                                 model.p0, model.f0, initial.piola)
        work_error = float((raw_material-full["material_weak"]).abs().max().detach())
        assert work_error < 1e-12
        limited = dict(config["optimizer"], full_newton_steps=2, full_newton_cg_iterations=60)
        full_newton(model, pool, .98, material, initial, limited, emit)
        final = pool.evaluate(model, .98, material, initial)
        after_full = float(objective(final, pool, model, config["optimizer"]).detach())
        assert after_full < float(expected_loss.detach())
        assert pool.history.state is old
        emit({"check": "full_parameter_gauss_newton", "method": method, "spatial_gradient_error": spatial_error,
              "parameter_gradient_error": gradient_error, "transpose_error": transpose_error,
              "symmetry_error": symmetry_error, "single_load_work_error": work_error,
              "loss_before": float(expected_loss.detach()), "loss_after": after_full, "history_unchanged": True})
    return metrics
