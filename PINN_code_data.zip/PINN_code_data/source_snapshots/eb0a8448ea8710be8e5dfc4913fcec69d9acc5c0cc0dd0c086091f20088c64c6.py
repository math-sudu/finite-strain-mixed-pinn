"""Common residual assembly; constitutive virtual work adds no boundary load."""
import torch


REGIONAL_KEYS = ("regional_consistency_weight", "regional_consistency_target", "regional_activation_pressure")


def regional_enabled(controls, pressure, p0):
    return (controls.get("regional_consistency_weight", 0.) > 0
            and pressure/p0 <= controls.get("regional_activation_pressure", float("inf")))


def regional_excess(error, pool, delta, controls):
    """Four train-only excess residuals; no load or material state update.

    The target is an optimizer margin below the unchanged acceptance bound.
    The tiny norm floor only defines a finite derivative at exact agreement.
    """
    norm = error.square().sum((-2, -1))
    distance = pool.distance[:pool.nv]
    masks = (distance < delta, (distance >= delta) & (distance < 2*delta), distance >= 2*delta)
    means = torch.stack([norm[:pool.nv][mask].mean() for mask in masks]+[norm[pool.nv:].mean()])
    excess = (means.clamp_min(1e-30).sqrt()-controls["regional_consistency_target"]).clamp_min(0)
    return controls["regional_consistency_weight"]**.5*excess


def constitutive_work(pool, delta_piola, p0):
    v = pool.mesh.volume
    p = delta_piola[:, :2, :2]
    internal = pool.mesh.assemble(torch.einsum("qij,qaj,q->qai", p, v.grad, v.weight), v.conn)
    local = internal[pool.mesh.free]/(p0*pool.mesh.test_scale[pool.mesh.free, None])
    multi = torch.einsum("qij,aqj,q->ai", p, pool.tests.grad, v.weight)/(p0*pool.tests.scale[:, None])
    return local, multi


def objective(data, pool, model, controls):
    value = (controls["weak_weight"]*(data["weak"].square().mean()+data["multi"].square().mean())
             +controls["consistency_weight"]*pool.consistency(data, model.delta))
    value = value+controls.get("consistency_weak_weight", 0.)*(
        data["constitutive_weak"].square().mean()+data["constitutive_multi"].square().mean())
    if regional_enabled(controls, data["pressure"], model.p0):
        value = value+regional_excess(data["error"], pool, model.delta, controls).square().sum()
    return value/model.load_amplitude**2 if controls.get("normalize_residual_by_load", False) else value
