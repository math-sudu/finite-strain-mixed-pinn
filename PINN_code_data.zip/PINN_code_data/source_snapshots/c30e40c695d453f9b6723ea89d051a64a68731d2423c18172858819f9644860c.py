"""Integration acceptance checks, run by run_mixed_feasibility.py check."""
import copy
import json
from pathlib import Path
import torch
import dp_material as dp
import dp_reference
from mixed_geometry import geometry_from_config, cofactor_normal
from mixed_history import PointHistory, accept_all, replay
from mixed_pinn import MixedNet, EvaluationPool, checks
from mixed_reference import ReferenceSolver
from mixed_residual import objective, REGIONAL_KEYS, regional_enabled
from mixed_full_newton import FullResidual


def run_checks(config, f0, initial, material, emit):
    root = Path(__file__).resolve().parents[1]
    mesh = geometry_from_config(config, root, f0, mesh={"angular": 24, "radial": 6, "quadrature": 4})
    pool = EvaluationPool("test", mesh, config["p0"])
    results = {}
    def record(name, value):
        results[name] = float(value)
        emit({"check": name, "value": float(value)})
    # Independent assembled initial virtual-work identity, without subtraction.
    raw = mesh.weak(initial.piola.expand(len(mesh.volume.x), 3, 3),
                     f0.expand(len(mesh.boundary.x), 3, 3), config["p0"], config["p0"], f0,
                     initial.piola, subtract_initial=False)
    record("raw_precompression_virtual_work_max", raw.abs().max())
    assert raw.abs().max() < 2e-6
    for method in ("W-GH", "W-LH", "W-RH"):
        torch.manual_seed(config["seed"])
        model = MixedNet(config, f0, initial, mesh.radius, method)
        data = pool.evaluate(model, config["p0"], material, initial, graph=False)
        data["pressure"] = config["p0"]
        metrics = checks(pool, data, model, config, initial)
        assert metrics["accepted"], metrics
        record(method+"_initial_consistency", metrics["consistency_rms"])
        # Reverse parameter derivative through F, materials and current pressure.
        with torch.no_grad():
            model.head.bias[0] = .0001
            model.head.bias[3] = .02
        outer_error = model.fields(mesh.nodes[-mesh.na:])[0].abs().max()
        assert outer_error < 1e-12
        record(method+"_outer_displacement_max", outer_error.detach())
        def residual():
            data = pool.evaluate(model, .98*config["p0"], material, initial)
            return data["weak"].square().mean()+data["multi"].square().mean()+pool.consistency(data, model.delta)
        value = residual()
        derivative = torch.autograd.grad(value, model.head.bias)[0][0]
        eps = 2e-7
        with torch.no_grad():
            model.head.bias[0] += eps
        plus = residual().detach()
        with torch.no_grad():
            model.head.bias[0] -= 2*eps
        minus = residual().detach()
        error = (derivative-(plus-minus)/(2*eps)).abs()/derivative.abs().clamp_min(1e-9)
        assert error < 1e-5
        record(method+"_mixed_parameter_derivative_error", error)
        if config["optimizer"].get("regional_consistency_weight", 0):
            pressure = .98*config["p0"]
            assert not regional_enabled(config["optimizer"], pressure, config["p0"])
            baseline = {k: v for k, v in config["optimizer"].items() if k not in REGIONAL_KEYS}
            data = pool.evaluate(model, pressure, material, initial)
            old_loss = objective(data, pool, model, baseline)
            new_loss = objective(data, pool, model, config["optimizer"])
            assert torch.equal(old_loss, new_loss)
            old_problem = FullResidual(model, pool, pressure, material, initial, baseline)
            new_problem = FullResidual(model, pool, pressure, material, initial, config["optimizer"])
            weights = old_problem.parameters()
            assert torch.equal(old_problem.residual(weights), new_problem.residual(weights))
            record(method+"_inactive_regional_prefix_exact_equivalence", 0.)
    # Independent material spectrum/implicit solve on mixed branches and history.
    f = dp.plane_tensor(torch.tensor([[[.984, 0], [0, .984]], [[1.02, .21], [.01, .96]],
                                     [[1.05, .005], [0, 1.04]]], device=f0.device, dtype=f0.dtype))
    old = dp.MaterialState.virgin((3,), device=f0.device)
    for i in range(3):
        tr = dp.evaluate(f, old, material)
        ref = dp_reference.update(f, old.cp, old.kappa, material)
        err = (ref.sigma-tr.sigma).abs().max()
        assert err < 1e-10
        assert (ref.cp-tr.cp).abs().max() < 1e-10
        record(f"independent_material_history_{i}", err)
        old = dp.commit_state(old, tr)
        f = f.clone()
        f[:, 0, 1] += .007
    history = pool.history
    trial = history.trial(f0.expand(len(pool.x), 3, 3), pool.x, history.ids, 0, material)
    for badx, badids, badstep in ((pool.x.flip(0), history.ids, 0), (pool.x, history.ids.flip(0), 0), (pool.x, history.ids, 1)):
        try:
            history.check(badx, badids, badstep)
            raise AssertionError("Changed pool was accepted")
        except ValueError:
            pass
    before = history.state
    try:
        accept_all([history], [trial], .98, {"accepted": False})
        raise AssertionError("Failed physics was accepted")
    except ValueError:
        pass
    assert history.state is before
    accept_all([history], [trial], .98, {"accepted": True})
    try:
        accept_all([history], [trial], .95, {"accepted": True})
        raise AssertionError("Stale trial was accepted")
    except ValueError:
        pass
    record("history_identity_rollback_stale_checks", 5)
    model = MixedNet(config, f0, initial, mesh.radius, "W-GH")
    xp = pool.x[:256]
    live = PointHistory("replay_test", xp, 1.)
    saved = []
    for magnitude in (1., 1.2):
        with torch.no_grad():
            model.head.bias[0] = magnitude/model.load_amplitude
        ff = model.deformation(xp, graph=False)[1]
        tr = live.trial(ff, xp, live.ids, live.state.step, material)
        live.state = dp.commit_state(live.state, tr)
        saved.append({"network": copy.deepcopy(model.state_dict()), "pressure": .6})
    restored = replay(model, saved, xp, material, 1.)
    assert live.state.kappa.max() > 1e-7
    assert (live.state.cp-restored.state.cp).abs().max() < 1e-12
    assert (live.state.kappa-restored.state.kappa).abs().max() < 1e-12
    record("plastic_history_replay_cp_error", (live.state.cp-restored.state.cp).abs().max())
    # Reproduce the observed false acceptance under the old physical scaling.
    old_run = root/"results/mixed_feasibility/gh_01/accepted_001.pt"
    if old_run.exists():
        old_config = json.loads((old_run.parent/"config.json").read_text(encoding="utf-8"))
        model = MixedNet(old_config, f0, initial, mesh.radius, "W-GH")
        model.displacement_scale = 1.
        model.inverse_square = False
        model.load_state_dict(torch.load(old_run, map_location=f0.device, weights_only=True)["network"])
        independent = EvaluationPool("validation", mesh, 1.)
        bad = independent.evaluate(model, .98, material, initial, graph=False)
        bad["pressure"] = .98
        verdict = checks(independent, bad, model, config, initial)
        assert not verdict["accepted"] and "multiscale_virtual_work" in verdict["failed_checks"]
        record("false_acceptance_multiscale_residual", verdict["multiscale_weak_max"])
    small_run = root/"results/mixed_feasibility/gh_08/accepted_001.pt"
    if small_run.exists():
        saved_config = json.loads((small_run.parent/"config.json").read_text(encoding="utf-8"))
        candidate = MixedNet(saved_config, f0, initial, mesh.radius, "W-GH")
        candidate.load_state_dict(torch.load(small_run, map_location=f0.device, weights_only=True)["network"])
        independent = EvaluationPool("validation", mesh, 1.)
        data = independent.evaluate(candidate, .98, material, initial, graph=False)
        data["pressure"] = .98
        verdict = checks(independent, data, candidate, config, initial)
        assert not verdict["accepted"] and "multiscale_virtual_work" in verdict["failed_checks"]
        record("small_unloading_acceptance_regression", verdict["consistency_rms"])
    # Point location reproduces an affine field on the actual curved mesh.
    from mixed_reference_sampling import locate
    sampling = locate(mesh, mesh.volume.x)
    assert (sampling.grad-mesh.volume.grad).abs().max() < 1e-10
    assert torch.equal(sampling.conn, mesh.volume.conn)
    record("independent_inverse_geometry_gradient_error", (sampling.grad-mesh.volume.grad).abs().max())
    for degree in (1, 2):
        graded = geometry_from_config(config, root, f0,
            mesh={"angular": 16, "radial": 8, "quadrature": 8, "degree": degree, "radial_exponent": 2.})
        located = locate(graded, graded.volume.x)
        error = (located.grad-graded.volume.grad).abs().max()
        assert torch.equal(located.conn, graded.volume.conn) and error < 1e-9
        assert graded.levels[1] == 1/64
        stress = initial.piola.expand(len(graded.volume.x), -1, -1)
        equilibrium = graded.weak(stress, f0.expand(len(graded.boundary.x), -1, -1),
                                  config["p0"], config["p0"], f0, initial.piola, subtract_initial=False)
        assert equilibrium.abs().max() < 1e-8, float(equilibrium.abs().max())
        record(f"graded_q{degree}_inverse_map_and_precompression_error", error)
        record(f"graded_q{degree}_unsubtracted_precompression_residual", equilibrium.abs().max())
    # Reference tangent directional check, including follower stiffness.
    solver = ReferenceSolver(mesh, f0, material, config["p0"], config["reference"])
    r, _, ff, _ = solver.residual(solver.u, .98)
    tangent = solver.tangent(solver.u, .98, ff)
    direction = .0001*torch.randn_like(solver.u)
    direction[len(mesh.free):] = 0
    eps = 1e-3
    numerical = (solver.residual(solver.u+eps*direction, .98)[0]-solver.residual(solver.u-eps*direction, .98)[0])/(2*eps)
    actual = (tangent @ direction[mesh.free].flatten()).reshape_as(numerical)
    err = (actual-numerical).norm()/numerical.norm()
    assert err < 1e-6
    record("reference_assembled_tangent_directional_error", err)
    q2mesh = geometry_from_config(config, root, f0, mesh={"angular": 16, "radial": 4, "quadrature": 4, "degree": 2})
    q2sample = locate(q2mesh, q2mesh.volume.x)
    assert torch.equal(q2sample.conn, q2mesh.volume.conn)
    assert (q2sample.grad-q2mesh.volume.grad).abs().max() < 1e-10
    assert (q2mesh.volume.shape.sum(-1)-1).abs().max() < 1e-12
    assert q2mesh.volume.grad.sum(1).abs().max() < 1e-12
    solver2 = ReferenceSolver(q2mesh, f0, material, config["p0"], config["reference"])
    rr, _, ff, _ = solver2.residual(solver2.u, .98)
    matrix = solver2.tangent(solver2.u, .98, ff)
    direction = .0001*torch.randn_like(solver2.u)
    direction[len(q2mesh.free):] = 0
    numerical = (solver2.residual(solver2.u+eps*direction, .98)[0]-solver2.residual(solver2.u-eps*direction, .98)[0])/(2*eps)
    actual = (matrix @ direction[q2mesh.free].flatten()).reshape_as(numerical)
    err = (actual-numerical).norm()/numerical.norm()
    assert err < 1e-6
    record("q2_assembled_tangent_directional_error", err)
    # Compare the unsymmetric sparse solve to independent dense GPU algebra.
    from mixed_krylov import bicgstab
    sparse_controls = dict(config["reference"], linear_solver="bicgstab")
    sparse_solver = ReferenceSolver(q2mesh, f0, material, config["p0"], sparse_controls)
    sparse = sparse_solver.tangent(sparse_solver.u, .98, ff)
    assert (sparse.matrix.to_dense()-matrix).abs().max() < 1e-10
    expected = torch.linalg.solve(matrix, -rr.flatten())
    actual, report = bicgstab(sparse, -rr.flatten())
    error = (expected-actual).norm()/expected.norm()
    assert error < 1e-7 and report["relative_residual"] < 1e-10
    record("q2_sparse_dense_newton_direction_error", error)
    tiny, report = bicgstab(sparse, -1e-12*rr.flatten())
    error = (expected-tiny/1e-12).norm()/expected.norm()
    assert error < 1e-7 and report["relative_residual"] < 1e-10
    record("q2_sparse_tiny_rhs_direction_error", error)
    if config["network"].get("coordinate_features") == "linear_angular_quadratic":
        model = MixedNet(config, f0, initial, mesh.radius, "W-GH")
        with torch.no_grad():
            model.head.weight[0, -5] = .01
            model.head.weight[1, -4] = .01
        radius = model.lstar*torch.tensor([2., 3., 4.], device=f0.device)
        angle = torch.tensor([0., .7, 1.4], device=f0.device)
        direction = torch.stack((angle.cos(), angle.sin()), -1)
        points = radius[:, None]*direction
        u, f, _, _ = model.deformation(points, graph=False)
        constant = .01*model.load_amplitude*model.length*model.displacement_scale*model.lstar
        amplitude = (u*direction).sum(-1)*radius/(1-radius.square()/model.radius**2)
        grad = constant*((1/radius.square()-1/model.radius**2)[:, None, None]*torch.eye(2, device=f0.device)
                         -2*points[:, :, None]*points[:, None, :]/radius.pow(4)[:, None, None])
        assert (amplitude-constant).abs().max() < 1e-12
        error = (f[:, :2, :2]-f0[:2, :2]-grad).abs().max()
        assert error < 1e-12
        record("exterior_inverse_radius_mode_gradient_error", error)
    return {"accepted": True, "checks": results}
