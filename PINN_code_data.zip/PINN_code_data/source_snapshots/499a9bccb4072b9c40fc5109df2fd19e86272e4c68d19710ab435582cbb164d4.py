"""Recover only saved, completed dense Newton iterations after interruption.

The unaccepted network is an optimizer iterate, never a material history.
The runner first replays and validates every accepted material state. A
recovered step spends only its remaining Newton/L-BFGS budget; incomplete
Jacobian work is repeated and remains included in measured resource bounds.
"""
import hashlib
import json
from pathlib import Path
import torch
from mixed_pinn import checks


def read_interrupted(folder, method):
    if (folder/"result.json").exists():
        raise ValueError("Interrupted recovery requires a run without a final result")
    record = json.loads((folder/"interruption.json").read_text(encoding="utf-8"))
    if record["method"] != method or record["status"] != "process_absent_after_host_restart":
        raise ValueError("Interruption metadata or method mismatch")
    return {"method": method, "records": json.loads((folder/"path.json").read_text(encoding="utf-8")),
            "resources": record["measured_lower_bounds"]}


def restore_optimizer(folder, config, model, train, validation, initial, material, pressure):
    metadata = json.loads((folder/"interruption.json").read_text(encoding="utf-8"))
    root = Path(__file__).resolve().parents[1]
    changes = {}
    recovery_files = {"mixed_pinn.py", "mixed_full_newton.py", "run_mixed_feasibility.py"}
    for old in (folder/"sources").iterdir():
        current = root/("tests" if old.name.startswith("test_") else "code")/old.name
        if old.name == Path(config["geometry"]).name:
            current = root/config["geometry"]
        old_hash = hashlib.sha256(old.read_bytes()).hexdigest()
        current_hash = hashlib.sha256(current.read_bytes()).hexdigest()
        if old_hash != current_hash:
            if old.name not in recovery_files:
                raise ValueError("A non-recovery source changed: "+old.name)
            changes[old.name] = {"interrupted_sha256": old_hash, "recovery_sha256": current_hash}
    name = metadata["candidate"]
    path = folder/name
    if path.resolve().parent != folder.resolve():
        raise ValueError("Recovery candidate escapes the source run")
    if hashlib.sha256(path.read_bytes()).hexdigest() != metadata["candidate_sha256"]:
        raise ValueError("Interrupted candidate changed")
    saved = torch.load(path, map_location=model.f0.device, weights_only=True)
    if saved["accepted"] or abs(saved["pressure"]-pressure) > 1e-12:
        raise ValueError("Recovery requires the uncommitted next pressure candidate")
    if saved["old_accepted_file"] != f"accepted_{train.history.state.step-1:03d}.pt":
        raise ValueError("Candidate is bound to a different accepted prefix")
    for pool, key in ((train, "training"), (validation, "validation")):
        if saved[key+"_state_step"] != pool.history.state.step or saved[key+"_identity"] != pool.history.key:
            raise ValueError("Candidate point identity or history step mismatch")
    events = [json.loads(line) for line in (folder/"events.jsonl").read_text(encoding="utf-8").splitlines()]
    report = saved["physical_report"]
    matching = []
    for i, event in enumerate(events):
        if event.get("phase") == "physical_validation" and all(event.get(k) == v for k, v in report.items()):
            matching.append(i)
    if len(matching) != 1:
        raise ValueError("Candidate has no unique matching physical-validation event")
    boundary = matching[0]
    update = events[boundary-1]
    if update.get("phase") != "full_newton" or not update["accepted_parameter_step"]:
        raise ValueError("Recovery is supported only after a completed dense Newton parameter step")
    if any(e.get("phase") in ("full_newton", "adam", "lbfgs", "pinn_step") for e in events[boundary+1:]):
        raise ValueError("Later optimization or commit events make this candidate stale")
    if update["linear_solver"] != "dense" or report["evaluations"] != config["optimizer"]["adam_steps"]:
        raise ValueError("Recovery requires the completed Adam phase followed by dense Newton")
    progress = {"phase": "full_newton", "iteration": update["iteration"],
        "next_damping": update["next_damping"],
        "counts": {k: v for k, v in update.items() if k.startswith("full_")}}
    if "optimizer_checkpoint" in report and report["optimizer_checkpoint"] != progress:
        raise ValueError("Optimizer checkpoint disagrees with its event")
    original = {key: value.detach().clone() for key, value in model.state_dict().items()}
    errors = []
    try:
        model.load_state_dict(saved["network"])
        for pool, key in ((train, "training_physics"), (validation, "validation")):
            data = pool.evaluate(model, pressure, material, initial, graph=False)
            data["pressure"] = pressure
            current = checks(pool, data, model, config, initial)
            if current["accepted"] != report[key]["accepted"] or current["failed_checks"] != report[key]["failed_checks"]:
                raise ValueError("Recovered candidate changed its physical verdict")
            for name, value in current.items():
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    errors.append(abs(value-report[key][name]))
        if max(errors, default=0.) > 1e-10:
            raise ValueError("Recovered candidate fields do not reproduce the saved checks")
    finally:
        model.load_state_dict(original)
    return {"network": saved["network"], "optimizer_checkpoint": progress,
        "training_counts": {k: report[k] for k in ("evaluations", "invalid_updates", "physical_checks")},
        "verification": {"candidate_sha256": metadata["candidate_sha256"],
            "recovery_orchestration_source_changes": changes,
            "completed_newton_iterations": progress["iteration"],
            "remaining_newton_iterations": config["optimizer"]["full_newton_steps"]-progress["iteration"],
            "next_damping": progress["next_damping"], "physical_metric_max_difference": max(errors, default=0.),
            "candidate_material_state_committed": False}}
