"""GPU Gauss-Newton for the complete mixed neural field.

The spatial derivative of the tanh network is propagated analytically.
Parameter JVP/VJP still differentiate current F, material return, normals and
follower pressure. No field labels, energy potential or state commits enter.
Linear directions use matrix-free CG or batched reverse Jacobians and a
column-scaled dense GPU solve, with a true linear residual check.
"""
import torch
from itertools import count
import math
import dp_material as dp
from mixed_head_newton import HeadResidual


class FullResidual(HeadResidual):
    def __init__(self, model, pool, pressure, material, initial, controls):
        super().__init__(model, pool, pressure, material, initial, controls)
        self.spec = [(name, p.shape, p.numel()) for name, p in model.named_parameters()]
        self.z = (pool.x/model.lstar).detach()
        self.zgrad = torch.eye(2, device=pool.x.device, dtype=pool.x.dtype).expand(len(pool.x), -1, -1)/model.lstar
        r2 = self.z.square().sum(-1)
        denominator = r2 if model.inverse_square else 1+r2
        self.envelope = (1-pool.x.square().sum(-1)/model.radius**2)/denominator
        self.envgrad = (-2*pool.x/(model.radius**2*denominator[:, None])
            -(1-pool.x.square().sum(-1)/model.radius**2)[:, None]*2*pool.x
            /(model.lstar**2*denominator.square()[:, None]))
        self.direct, self.directgrad = None, None
        if model.coordinate_features:
            x = pool.x.detach().clone().requires_grad_(True)
            z = x/model.lstar
            r = z.square().sum(-1)
            direct = torch.stack((z[:, 0], z[:, 1], (z[:, 0]**2-z[:, 1]**2)/r,
                                  2*z[:, 0]*z[:, 1]/r, r), -1)
            self.directgrad = torch.stack([torch.autograd.grad(direct[:, i].sum(), x, retain_graph=True)[0]
                                            for i in range(5)], 1).detach()
            self.direct = direct.detach()

    def parameters(self):
        return torch.cat([p.detach().flatten() for p in self.model.parameters()])

    def unpack(self, weights):
        parts = weights.split([n for _, _, n in self.spec])
        return {name: value.view(shape) for (name, shape, _), value in zip(self.spec, parts)}

    def install(self, weights):
        parameters = self.unpack(weights)
        with torch.no_grad():
            for name, p in self.model.named_parameters():
                p.copy_(parameters[name])

    def fields(self, weights):
        p = self.unpack(weights)
        if self.displacement_cache is not None:
            _, f = self.model.configuration_kinematics(self.displacement_cache, p)
            feature = self.model.features_from_z(self.z, p)
            values = self.model.load_amplitude*(feature @ p["head.weight"].T+p["head.bias"])
            aw = self.model.p0*values[:, 2:6]+self.base
            ao = self.model.p0*self.radial_stress[:, None]*values[:, 6:10]+self.base
            return f, aw, ao
        h, grad = self.z, self.zgrad
        for i, layer in enumerate(self.model.body):
            if isinstance(layer, torch.nn.Linear):
                weight, bias = p[f"body.{i}.weight"], p[f"body.{i}.bias"]
                h = h @ weight.T+bias
                grad = torch.einsum("qaj,ia->qij", grad, weight)
            elif isinstance(layer, torch.nn.Tanh):
                h = torch.tanh(h)
                grad = grad*(1-h.square())[:, :, None]
            else:
                raise ValueError("Explicit spatial derivative supports Linear/Tanh only")
        if self.direct is not None:
            h = torch.cat((h, self.direct), -1)
            grad = torch.cat((grad, self.directgrad), 1)
        values = self.model.load_amplitude*(h @ p["head.weight"].T+p["head.bias"])
        ug = self.model.load_amplitude*torch.einsum("qaj,ia->qij", grad, p["head.weight"][:2])
        factor = self.model.length*self.model.displacement_scale
        uf = factor*(ug*self.envelope[:, None, None]+values[:, :2, None]*self.envgrad[:, None, :])
        f = dp.plane_tensor(self.model.f0[:2, :2]+uf)
        aw = self.model.p0*values[:, 2:6]+self.base
        ao = self.model.p0*self.radial_stress[:, None]*values[:, 6:10]+self.base
        return f, aw, ao

    def residual(self, weights):
        if self.model.displacement_context is not self.field_context:
            raise ValueError("Full solve cannot span a configuration change")
        if self.pool.history.state is not self.old_state:
            raise ValueError("Full neural solve cannot span a history commit")
        return self.residual_from_fields(*self.fields(weights))


def full_newton(model, pool, pressure, material, initial, controls, emit, stop_check=None,
                resume_state=None, state_callback=None):
    problem = FullResidual(model, pool, pressure, material, initial, controls)
    weights = problem.parameters()
    counts = {"full_jvp_evaluations": 0, "full_vjp_evaluations": 0, "full_residual_evaluations": 0}
    dense = controls.get("full_newton_linear_solver") == "dense"
    counts.update(full_dense_backward_batches=0, full_dense_solves=0)
    damping = controls.get("full_newton_damping", 1e-3)
    first_iteration = 0
    if resume_state is not None:
        if not dense or resume_state["phase"] != "full_newton":
            raise ValueError("Optimizer recovery requires a completed dense Newton iteration")
        first_iteration = resume_state["iteration"]
        damping = resume_state["next_damping"]
        limit = controls["full_newton_steps"]
        if first_iteration < 0 or (limit is not None and first_iteration > limit) or not damping > 0:
            raise ValueError("Invalid remaining Newton budget or damping")
        counts.update(resume_state["counts"])
    if controls.get("full_newton_damping_update", "gain_ratio") != "gain_ratio":
        raise ValueError("The current optimizer uses actual/predicted reduction to update damping")
    minimum_gain = controls.get("full_newton_minimum_gain_ratio", 1e-4)
    if not 0 < minimum_gain < 1:
        raise ValueError("Minimum optimizer gain ratio must lie between zero and one")
    selection = controls.get("full_newton_backtracking", "first_admissible")
    if selection not in ("first_admissible", "minimum_objective"):
        raise ValueError("Unknown Newton backtracking selection")
    damping_policy = "gain_ratio_and_step_fraction" if selection == "minimum_objective" else "gain_ratio"
    generator = torch.Generator(device=weights.device).manual_seed(1729)
    limit = controls["full_newton_steps"]
    iterations = count(first_iteration) if limit is None else range(first_iteration, limit)
    for iteration in iterations:
        residual, pullback = torch.func.vjp(problem.residual, weights)
        counts["full_residual_evaluations"] += 1
        residual = residual.detach()
        gradient = pullback(residual)[0].detach()
        counts["full_vjp_evaluations"] += 1
        # Deterministic stochastic diagonal preconditioner. It is optimizer
        # arithmetic only; the physical samples and material states stay fixed.
        if dense:
            from mixed_dense_jacobian import dense_system, solve_damped
            normal, rhs, scale, info = dense_system(residual, pullback, weights, emit,
                controls.get("full_newton_jacobian_batch", 64),
                point_problem=problem if controls.get("full_newton_point_blocks", False) else None)
            counts["full_vjp_evaluations"] += info["dense_jacobian_rows"]-info.get("inactive_work_excess_rows", 0)
            counts["full_dense_backward_batches"] += info["dense_backward_batches"]
        else:
            diagonal = torch.zeros_like(weights)
            probes = controls.get("full_newton_diagonal_probes", 8)
            for _ in range(probes):
                signs = torch.randint(0, 2, residual.shape, device=weights.device, generator=generator)*2-1
                diagonal.add_(pullback(signs.to(weights.dtype))[0].detach().square()/probes)
                counts["full_vjp_evaluations"] += 1
            scale = diagonal.clamp_min(float(diagonal.mean())*1e-8).sqrt()
            rhs = -gradient/scale
        rhsnorm = rhs.norm()
        if rhsnorm < 1e-15:
            counts["full_stop_reason"] = "small_scaled_rhs"
            emit({"phase": "full_newton_stop", "completed_iterations": iteration,
                  "reason": counts["full_stop_reason"], "objective_gradient_norm": 2*float(gradient.norm()),
                  "scaled_rhs_norm": float(rhsnorm)})
            break
        accepted = False
        gain_ratio, accepted_fraction = None, None
        predicted_reduction, actual_reduction = None, None
        backtracking_trials = []
        for attempt in range(5):
            def multiply(direction):
                _, jv = torch.func.jvp(problem.residual, (weights,), (direction/scale,))
                counts["full_jvp_evaluations"] += 1
                value = pullback(jv.detach())[0].detach()/scale+damping*direction
                counts["full_vjp_evaluations"] += 1
                return value
            if dense:
                correction, linear_residual = solve_damped(normal, rhs, damping)
                counts["full_dense_solves"] += 1
                cg = -1
            else:
                correction = torch.zeros_like(weights)
                rr = rhs.clone()
                direction = rr.clone()
                norm2 = rr @ rr
                for cg in range(controls.get("full_newton_cg_iterations", 200)):
                    ad = multiply(direction)
                    denominator = direction @ ad
                    if denominator <= 0 or not torch.isfinite(denominator):
                        raise ValueError("Damped Gauss-Newton operator lost positive definiteness")
                    alpha = norm2/denominator
                    correction.add_(alpha*direction)
                    rr.sub_(alpha*ad)
                    newnorm = rr @ rr
                    if float(newnorm.sqrt()/rhsnorm) <= controls.get("full_newton_cg_tolerance", 1e-3):
                        break
                    direction = rr+(newnorm/norm2)*direction
                    norm2 = newnorm
                    if (cg+1) % 50 == 0:
                        emit({"phase": "full_newton_cg", "iteration": iteration, "attempt": attempt,
                              "cg_iterations": cg+1, "relative_linear_residual": float(newnorm.sqrt()/rhsnorm), **counts})
                # Recompute the true residual; recursive CG residuals can drift.
                linear_residual = float((multiply(correction)-rhs).norm()/rhsnorm)
            step = correction/scale
            before = float(residual.square().sum())
            used_damping = damping
            linear_gain = -2*float(gradient @ step)
            if dense:
                quadratic_gain = float(correction @ (normal @ correction))
            else:
                _, direction_residual = torch.func.jvp(problem.residual, (weights,), (step,))
                counts["full_jvp_evaluations"] += 1
                quadratic_gain = float(direction_residual.square().sum())
            best = None
            for backtrack in range(9):
                fraction = 0.5**backtrack
                predicted = fraction*linear_gain-fraction**2*quadratic_gain
                if predicted <= 0:
                    continue
                trial = weights+fraction*step
                try:
                    value = float(problem.residual(trial).square().sum())
                    counts["full_residual_evaluations"] += 1
                    ratio = (before-value)/predicted
                    admissible = math.isfinite(value) and math.isfinite(ratio) and value < before and ratio >= minimum_gain
                    backtracking_trials.append({"attempt": attempt, "fraction": fraction,
                        "loss": value if math.isfinite(value) else None,
                        "gain_ratio": ratio if math.isfinite(ratio) else None, "admissible": admissible})
                    if admissible and (best is None or value < best[1]):
                        best = (trial.detach(), value, ratio, fraction, predicted)
                        if selection == "first_admissible":
                            break
                except ValueError:
                    counts["full_residual_evaluations"] += 1
                    backtracking_trials.append({"attempt": attempt, "fraction": fraction,
                                                "admissible": False, "invalid_field": True})
            if best is not None:
                weights, value, gain_ratio, accepted_fraction, predicted_reduction = best
                actual_reduction, accepted = before-value, True
                if gain_ratio > .75:
                    damping = max(1e-9, damping*.3)
                elif gain_ratio < .25:
                    damping *= 2.
                if selection == "minimum_objective" and accepted_fraction < 1:
                    # A good ratio for a shortened step does not validate the
                    # full direction. Regularize the next direction accordingly.
                    damping = max(damping, used_damping/accepted_fraction)
                break
            damping *= 10
        problem.install(weights)
        emit({"phase": "full_newton", "iteration": iteration+1, "accepted_parameter_step": accepted,
              "objective_gradient_norm_before": 2*float(gradient.norm()), "scaled_rhs_norm_before": float(rhsnorm),
              "loss_before": before, "loss": value if accepted else before, "next_damping": damping,
              "damping_used": used_damping, "step_fraction": accepted_fraction,
              "predicted_reduction": predicted_reduction, "actual_reduction": actual_reduction,
              "gain_ratio": gain_ratio,
              "backtracking_selection": selection, "backtracking_trials": backtracking_trials,
              "damping_policy": damping_policy,
              "linear_solver": "dense" if dense else "cg", "cg_iterations": cg+1,
              "relative_linear_residual": linear_residual, **counts})
        del pullback
        if dense:
            del normal
        if state_callback is not None:
            state_callback({"phase": "full_newton", "iteration": iteration+1,
                            "next_damping": damping, "counts": counts.copy(), "backtracking_selection": selection,
                            "damping_policy": damping_policy})
        if stop_check is not None and stop_check():
            counts["full_physics_passed"] = True
            counts["full_stop_reason"] = "physical_checks_passed"
            break
        if not accepted:
            counts["full_stop_reason"] = "no_acceptable_parameter_step"
            break
    else:
        counts["full_stop_reason"] = "iteration_budget"
    return counts
