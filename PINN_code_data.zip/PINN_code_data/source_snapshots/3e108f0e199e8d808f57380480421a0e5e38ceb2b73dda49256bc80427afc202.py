"""Locate basis updates and plastic-driving mismatch in saved accepted fields.

This is a development diagnostic on common normal-offset material points.
It replays each input's complete accepted displacement history; it never
optimizes, solves equilibrium, or changes a saved solver state. Reference
substeps remain intact. The .725 -> .7125 predictor uses each field's own
.725 state and is diagnostic only, with no return or commit of that trial.
"""
import os
import time
PW, PC = time.perf_counter(), time.process_time()
THREAD_KEYS = ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
               "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")
for name in THREAD_KEYS:
    os.environ[name] = "1"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import torch
import current_traction as ct
import dp_material as dp
from horseshoe_geometry import HorseshoeWall
from mixed_geometry import gauss, geometry_from_config
from mixed_history import PointHistory, identity
from mixed_pinn import MixedNet
from mixed_reference_sampling import ReferenceProbe

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/mixed_feasibility"
ARC_NAMES = ("crown", "left_wall", "left_knee", "invert", "right_knee", "right_wall")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def folder(name):
    path = (BASE / name).resolve()
    if path.parent != BASE.resolve() or (path / "invalidation.json").exists():
        raise ValueError("Need a direct, non-invalidated result directory")
    return path


def collar_points(config, f0, panels, radial_panels, order):
    wall = HorseshoeWall.from_json(ROOT / config["geometry"], device=f0.device, scale=1/f0[0, 0])
    delta = config["collar_precompressed_m"] / f0[0, 0]
    g, gw = gauss(order, f0.device)
    arcs = torch.cat([torch.full((n * order,), i, device=f0.device, dtype=torch.long)
                      for i, n in enumerate(panels)])
    fractions = torch.cat([((torch.arange(n, device=f0.device)[:, None] + g) / n).flatten()
                           for n in panels])
    lengths = wall.radii * wall.sweeps
    arc_weights = torch.cat([gw.repeat(n) * lengths[i] / n for i, n in enumerate(panels)])
    xw, normal = wall.sample(arcs, fractions)
    levels = delta * torch.linspace(0, 1, radial_panels + 1, device=f0.device).square()
    distances = (levels[:-1, None] + levels.diff()[:, None] * g).flatten()
    dw = (levels.diff()[:, None] * gw).flatten()
    na, nr = len(xw), len(distances)
    xv = (xw[:, None, :] - distances[None, :, None] * normal[:, None, :2]).reshape(-1, 2)
    weights = (arc_weights[:, None] * dw * (1 + distances / wall.radii[arcs, None])).flatten()
    points = torch.cat((xv, xw))
    normals = torch.cat((normal.repeat_interleave(nr, 0), normal))
    d = torch.cat((distances.repeat(na), torch.zeros(na, device=f0.device)))
    arc_index = torch.cat((arcs.repeat_interleave(nr), arcs))
    projection = wall.project(points)
    errors = {"projection_distance_max_m": float((projection.distance - d).abs().max()),
              "projection_normal_max": float((projection.normal - normals).abs().max()),
              "area_quadrature_absolute_error_m2": float((weights.sum() - lengths.sum() * delta - torch.pi * delta.square()).abs()),
              "arc_quadrature_absolute_error_m": float((arc_weights.sum() - lengths.sum()).abs())}
    if max(errors.values()) > 1e-9:
        raise ValueError("Normal-offset geometry/measure check failed: " + repr(errors))
    mesh = SimpleNamespace(wall=wall, radius=config["outer_widths"] * 13.46 / f0[0, 0],
        volume=SimpleNamespace(x=xv, weight=weights),
        boundary=SimpleNamespace(x=xw, normal=normal, weight=arc_weights))
    r = d / delta
    raw = {"x_natural_m": points, "reference_normal": normals, "distance_natural_m": d,
           "arc_index": arc_index, "arc_fraction": torch.cat((fractions.repeat_interleave(nr), fractions)),
           "chi": 1 - 3 * r.square() + 2 * r.pow(3), "eta": (1 - r).square(),
           "volume_weights_m2": weights, "wall_weights_m": arc_weights,
           "radial_distances_natural_m": distances, "radial_weights_m": dw,
           "angular_weights_m": arc_weights, "angular_arc_index": arcs,
           "volume_shape": [na, nr], "volume_count": len(xv), "delta_natural_m": float(delta)}
    return mesh, raw, errors


def predictor(f, cp, kappa, material):
    b = dp.sym(f @ torch.linalg.solve(cp, f.transpose(-1, -2)))
    log = .5 * dp.log_spd_plane(b)
    tau, _ = dp.hencky_response(log, material)
    p, q = dp.invariants(tau)
    strength = torch.linalg.det(f) * material.strength(kappa)
    return {"f_tau": q - material.alpha * p - strength,
            "q_tau": q, "p_tau": p, "J_strength": strength}


def snapshot(f, u, cp_old, kappa_old, trial, pressure, old_pressure, material, sigma_net=None):
    item = {"pressure_ratio": pressure, "previous_pressure_ratio": old_pressure,
            "F": f.detach(), "u_m": u.detach(), "cp_old": cp_old.detach().clone(),
            "kappa_old": kappa_old.detach().clone(), "cp": trial.cp.detach().clone(),
            "kappa": trial.kappa.detach().clone(), "sigma_return": trial.sigma.detach(),
            "branch": trial.branch.detach(), "native_predictor": predictor(f, cp_old, kappa_old, material)}
    item["native_delta_kappa"] = item["kappa"] - item["kappa_old"]
    smooth = trial.branch == 1
    if bool(smooth.any()):
        denominator = 3 * material.shear + material.alpha * material.bulk * material.beta + torch.linalg.det(f) * material.hardening
        error = (item["native_delta_kappa"][smooth] - item["native_predictor"]["f_tau"][smooth] / denominator[smooth]).abs().max()
        item["native_drive_return_check_max"] = float(error)
        if float(error) > 1e-11:
            raise ValueError("Native predictor does not reproduce its smooth return increment")
    else:
        item["native_drive_return_check_max"] = 0.
    if sigma_net is not None:
        item["sigma_network"] = sigma_net.detach()
    return item


def checkpoints(directory, config):
    rows = read(directory / "result.json")["records"]
    expected = [float(row["pressure_ratio"]) for row in rows if row["accepted"]]
    paths = sorted(directory.glob("accepted_*.pt"))
    if len(expected) != len(paths) or not expected or abs(expected[0] - 1) > 1e-12:
        raise ValueError("Accepted checkpoint/record coverage differs")
    previous = None
    for path, pressure in zip(paths, expected):
        saved = torch.load(path, map_location="cuda:0", weights_only=True)
        p = float(saved["pressure"]) / config["p0"]
        if abs(p - pressure) > 1e-12 or (previous is not None and p >= previous):
            raise ValueError("Accepted checkpoint pressure/order differs from physical record")
        yield path, saved, round(p, 12), previous
        previous = p


def replay_reference(name, mesh, config, f0, material):
    original = read(folder(name) / "config.json")
    source = geometry_from_config(original, ROOT, f0, mesh=original["reference_mesh"])
    probe = ReferenceProbe(source, mesh, f0, material)
    data, history = {}, []
    targets = {.725, .71875, .7125, .675}
    for path, saved, p, previous in checkpoints(folder(name), config):
        f, u, trial = probe.evaluate(saved["u"])
        if p in targets:
            data[p] = snapshot(f, u, probe.cp, probe.kappa, trial, p, previous, material)
        probe.commit(trial)
        history.append({"file": path.name, "pressure_ratio": p})
        if len(history) % 12 == 0:
            print(json.dumps({"phase": "reference_replay", "accepted_states_replayed": len(history), "pressure_ratio": p}), flush=True)
    if set(data) != targets:
        raise ValueError("Reference lacks a required accepted pressure")
    return data, history


def replay_neural(name, mesh, grid, config, f0, material, initial):
    metadata = read(folder(name) / "result.json")
    original = read(folder(name) / "config.json")
    model = MixedNet(original, f0, initial, mesh.radius, metadata["method"])
    x = grid["x_natural_m"]
    history = PointHistory("basis_mechanism", x, config["p0"])
    data, records = {}, []
    for path, saved, p, previous in checkpoints(folder(name), config):
        model.load_state_dict(saved["network"])
        parts = []
        for left in range(0, len(x), 4096):
            right = min(left + 4096, len(x))
            u, f, aw, ao = model.deformation(x[left:right], graph=False)
            sigma = ct.blended_stress(f, aw, ao, grid["distance_natural_m"][left:right],
                grid["reference_normal"][left:right], p * config["p0"], model.delta,
                basis=model.basis, initial_f=f0.expand_as(f))
            parts.append((u, f, sigma))
        u, f, sigma = [torch.cat([part[i] for part in parts]) for i in range(3)]
        trial = history.trial(f, x, history.ids, history.state.step, material)
        if p in {.725, .7125}:
            data[p] = snapshot(f, u, history.state.cp, history.state.kappa,
                               trial, p, previous, material, sigma)
        history.state = dp.commit_state(history.state, trial)
        records.append({"file": path.name, "pressure_ratio": p})
    if set(data) != {.725, .7125} or records[-1]["pressure_ratio"] != .7125:
        raise ValueError("This diagnostic expects the official accepted prefix through .7125")
    return data, records, metadata["method"]


def square_norm(value):
    return value.square().flatten(1).sum(-1) if value.ndim > 1 else value.square()


def rms(value, weight):
    return float((torch.sum(weight * square_norm(value)) / weight.sum()).sqrt())


def mean(value, weight):
    return float((weight * value).sum() / weight.sum())


def local(sigma, q):
    return q.transpose(-1, -2) @ sigma @ q


def four(sigma):
    return torch.stack((sigma[:, 0, 0], sigma[:, 0, 1], sigma[:, 1, 1], sigma[:, 2, 2]), -1)


def component_rms(sigma, weight):
    return [rms(column, weight) for column in four(sigma).unbind(-1)]


def regions(grid, kappa, threshold):
    nv = grid["volume_count"]
    ids = torch.arange(len(kappa), device=kappa.device)
    v, wall = ids < nv, ids >= nv
    knee = (grid["arc_index"] == 2) | (grid["arc_index"] == 4)
    weights = torch.cat((grid["volume_weights_m2"], grid["wall_weights_m"]))
    masks = {"collar": v, "knee_collar": v & knee, "wall": wall, "knee_wall": wall & knee,
             "reference_plastic_collar": v & (kappa > threshold)}
    return [(name, mask, weights[mask]) for name, mask in masks.items() if bool(mask.any())]


def angular_variation(sigma, grid, mask_angular):
    """Variance along each offset curve, then integrated over offset distance.

    This is a description of component variation, not a differentiability,
    approximation-error, or neural optimization certificate.
    """
    na, nr = grid["volume_shape"]
    values = sigma[:na * nr].reshape(na, nr, 3, 3)[mask_angular]
    w = grid["volume_weights_m2"].reshape(na, nr)[mask_angular]
    average = (w[:, :, None, None] * values).sum(0) / w.sum(0)[:, None, None]
    variance = (values - average).square().sum((-2, -1))
    return float(((w * variance).sum() / w.sum()).sqrt())


def summarize_basis(ref, grid, f0, initial, config):
    _, q0, _ = ct.current_frame(f0.expand_as(ref["F"]), grid["reference_normal"])
    n, q, _ = ct.current_frame(ref["F"], grid["reference_normal"])
    cosine = (q0[:, :, 0] * n).sum(-1)
    sine = torch.linalg.cross(q0[:, :, 0], n)[:, 2]
    angle = torch.atan2(sine, cosine) * 180 / torch.pi
    sigma = ref["sigma_return"]
    initial_components, current_components = local(sigma, q0), local(sigma, q)
    correction = current_components - initial_components
    ref.update(Q_initial=q0, Q_current=q, normal_update_degrees=angle,
               sigma_initial_components=initial_components, sigma_current_components=current_components)
    output = {"regions": {}, "angular_component_variation_rms_over_p0": {}}
    for name, mask, weight in regions(grid, ref["kappa"], config["plastic_threshold"]):
        inc = rms(sigma[mask] - initial.sigma, weight)
        correction_rms = rms(correction[mask], weight)
        selected_ids = torch.where(mask)[0]
        peak = selected_ids[angle[mask].abs().argmax()]
        output["regions"][name] = {
            "measure": "natural_arc_length_m" if "wall" in name else "natural_area_m2",
            "measure_total": float(weight.sum()), "rotation_rms_deg": rms(angle[mask], weight),
            "rotation_max_deg": float(angle[mask].abs().max()), "rotation_peak_point_id": int(peak),
            "rotation_peak_x_natural_m": grid["x_natural_m"][peak].cpu().tolist(),
            "rotation_peak_distance_natural_m": float(grid["distance_natural_m"][peak]),
            "component_update_rms_over_p0": correction_rms / config["p0"],
            "component_update_rms_over_stress_increment_rms": correction_rms / inc if inc > 1e-15 else None,
            "component_update_four_rms_over_p0": component_rms(correction[mask] / config["p0"], weight),
            "chi_weighted_component_update_rms_over_p0": rms(grid["chi"][mask, None, None] * correction[mask], weight) / config["p0"]}
    arc = grid["angular_arc_index"]
    for name, mask in (("all_arcs", torch.ones_like(arc, dtype=torch.bool)),
                       ("both_knees", (arc == 2) | (arc == 4))):
        output["angular_component_variation_rms_over_p0"][name] = {
            label: angular_variation(tensor, grid, mask) / config["p0"] for label, tensor in
            (("cartesian", sigma), ("initial_local", initial_components), ("current_local", current_components))}
    pr, qr = dp.invariants(sigma)
    pl, ql = dp.invariants(current_components)
    output["tensor_rotation_check_max"] = float(torch.stack(((q @ current_components @ q.transpose(-1, -2) - sigma).abs().max(),
                                                            (pr - pl).abs().max(), (qr - ql).abs().max())).max())
    if output["tensor_rotation_check_max"] > 1e-11:
        raise ValueError("Stress tensor reconstruction/invariant rotation check failed")
    return output


def add_interval(data, material):
    old, end = data[.725], data[.7125]
    end["interval_predictor"] = predictor(end["F"], old["cp"], old["kappa"], material)
    end["interval_actual_delta_kappa"] = end["kappa"] - old["kappa"]


def summarize_mismatch(data, refs, grid, config, material):
    end, ref = data[.7125], refs[.7125]
    pred, expected = end["interval_predictor"], ref["interval_predictor"]
    rm_error = end["sigma_return"] - ref["sigma_return"]
    net_error = end["sigma_network"] - ref["sigma_return"]
    compensation = end["sigma_network"] - end["sigma_return"]
    component_difference = local(compensation, ref["Q_current"])
    kerr = end["kappa"] - ref["kappa"]
    dkerr = end["interval_actual_delta_kappa"] - ref["interval_actual_delta_kappa"]
    p, q = dp.invariants(end["sigma_network"])
    net_yield = q - material.alpha * p - material.strength(end["kappa"])
    end.update(stress_difference_reference_current_components=component_difference,
               network_yield_using_return_kappa=net_yield,
               interval_predictor_difference=pred["f_tau"] - expected["f_tau"])
    output = {}
    for name, mask, weight in regions(grid, ref["kappa"], config["plastic_threshold"]):
        kr = rms(ref["kappa"][mask], weight)
        drive = rms(expected["f_tau"][mask], weight)
        cr, er = rms(compensation[mask], weight), rms(rm_error[mask], weight)
        cos = -mean((compensation[mask] * rm_error[mask]).sum((-2, -1)), weight) / (cr * er) if cr * er > 1e-25 else None
        errweight = weight * kerr[mask].square()
        rows = {"measure_total": float(weight.sum()), "kappa_relative_l2": rms(kerr[mask], weight) / kr if kr > 1e-15 else None,
            "actual_delta_kappa_error_rms": rms(dkerr[mask], weight),
            "reference_actual_delta_kappa_mean": mean(ref["interval_actual_delta_kappa"][mask], weight),
            "pinn_actual_delta_kappa_mean": mean(end["interval_actual_delta_kappa"][mask], weight),
            "reference_interval_drive_mean_over_p0": mean(expected["f_tau"][mask], weight) / config["p0"],
            "pinn_interval_drive_mean_over_p0": mean(pred["f_tau"][mask], weight) / config["p0"],
            "interval_drive_difference_relative_l2": rms((pred["f_tau"] - expected["f_tau"])[mask], weight) / drive if drive > 1e-15 else None,
            "drive_underpredicted_measure_fraction": mean((pred["f_tau"][mask] < expected["f_tau"][mask]).to(weight.dtype), weight),
            "pinn_positive_interval_drive_fraction": mean((pred["f_tau"][mask] > 0).to(weight.dtype), weight),
            "drive_difference_mean_terms_over_p0": {
                "q_tau": mean((pred["q_tau"] - expected["q_tau"])[mask], weight) / config["p0"],
                "minus_alpha_p_tau": -material.alpha * mean((pred["p_tau"] - expected["p_tau"])[mask], weight) / config["p0"],
                "minus_J_strength": -mean((pred["J_strength"] - expected["J_strength"])[mask], weight) / config["p0"]},
            "return_stress_error_rms_over_p0": er / config["p0"],
            "network_stress_error_rms_over_p0": rms(net_error[mask], weight) / config["p0"],
            "network_return_difference_rms_over_p0": cr / config["p0"],
            "network_return_difference_four_rms_over_p0": component_rms(component_difference[mask] / config["p0"], weight),
            "compensation_error_alignment_cosine": cos,
            "network_closer_to_reference_fraction": mean((square_norm(net_error[mask]) < square_norm(rm_error[mask])).to(weight.dtype), weight),
            "network_yield_mean_over_p0_using_return_kappa": mean(net_yield[mask], weight) / config["p0"],
            "kappa_error_squared_weighted_reference_rotation_rms_deg": rms(ref["normal_update_degrees"][mask], errweight) if float(errweight.sum()) > 1e-25 else None}
        ids = torch.where(mask)[0]
        peak = ids[kerr[mask].abs().argmax()]
        rows["kappa_error_peak"] = {"point_id": int(peak), "x_natural_m": grid["x_natural_m"][peak].cpu().tolist(),
            "distance_natural_m": float(grid["distance_natural_m"][peak]), "arc": ARC_NAMES[int(grid["arc_index"][peak])],
            "chi": float(grid["chi"][peak]), "eta": float(grid["eta"][peak]),
            "reference_rotation_deg": float(ref["normal_update_degrees"][peak]),
            "reference_kappa": float(ref["kappa"][peak]), "pinn_kappa": float(end["kappa"][peak]),
            "reference_interval_drive_over_p0": float(expected["f_tau"][peak]) / config["p0"],
            "pinn_interval_drive_over_p0": float(pred["f_tau"][peak]) / config["p0"],
            "network_return_difference_four_over_p0": (four(component_difference[peak:peak+1])[0] / config["p0"]).cpu().tolist()}
        output[name] = rows
    # For PINNs, the common-interval old state is exactly the native old state.
    native_error = float((pred["f_tau"] - end["native_predictor"]["f_tau"]).abs().max())
    if native_error > 1e-12:
        raise ValueError("PINN .725 old state did not match its actual final step")
    output["interval_native_predictor_check_max"] = native_error
    return output


def evaluate_conditional_endpoint(model, old, grid, material, pressure, old_step):
    """Evaluate one endpoint on archived points with its fixed accepted old state."""
    x = grid["x_natural_m"]
    parts = []
    for left in range(0, len(x), 4096):
        right = min(left + 4096, len(x))
        u, f, aw, ao = model.deformation(x[left:right], graph=False)
        sigma = ct.blended_stress(f, aw, ao, grid["distance_natural_m"][left:right],
            grid["reference_normal"][left:right], pressure * model.p0, model.delta,
            basis=model.basis, initial_f=model.f0.expand_as(f))
        parts.append((u, f, sigma))
    u, f, sigma = [torch.cat([part[i] for part in parts]) for i in range(3)]
    state = dp.MaterialState(old["cp"], old["kappa"], old_step)
    trial = dp.evaluate(f, state, material)
    return snapshot(f, u, old["cp"], old["kappa"], trial, pressure,
                    old["pressure_ratio"], material, sigma)


def summarize_conditional_increment(data, refs, grid, config, material):
    """Add gradient and full-collar support errors to the fixed mechanism metrics."""
    add_interval(data, material)
    output = {"endpoint_mismatch": summarize_mismatch(data, refs, grid, config, material)}
    old, end, rold, ref = data[.725], data[.7125], refs[.725], refs[.7125]
    def dev_trial(f, cp):
        b = dp.sym(f @ torch.linalg.solve(cp, f.transpose(-1, -2)))
        e = .5 * dp.log_spd_plane(b)
        return e - e.diagonal(dim1=-2, dim2=-1).sum(-1)[:, None, None] / 3 * torch.eye(3, device=f.device)
    df, dfr = end["F"] - old["F"], ref["F"] - rold["F"]
    dev, devr = dev_trial(end["F"], old["cp"]), dev_trial(ref["F"], rold["cp"])
    end.update(interval_delta_F=df, interval_trial_deviatoric_log_strain=dev)
    nv, tol = grid["volume_count"], config["plastic_threshold"]
    all_weight = torch.cat((grid["volume_weights_m2"], grid["wall_weights_m"]))
    volume = torch.arange(len(all_weight), device=all_weight.device) < nv
    masks = [(name, mask, weight) for name, mask, weight in regions(grid, ref["kappa"], tol)]
    for arc, name in ((2, "left_knee_collar"), (4, "right_knee_collar")):
        mask = volume & (grid["arc_index"] == arc)
        masks.append((name, mask, all_weight[mask]))
    details = {}
    for name, mask, weight in masks:
        def relative(error, expected):
            denominator = rms(expected[mask], weight)
            return rms(error[mask], weight) / denominator if denominator > 1e-20 else None
        pred_plastic, ref_plastic = end["kappa"][mask] > tol, ref["kappa"][mask] > tol
        pred_active = end["interval_actual_delta_kappa"][mask] > tol
        ref_active = ref["interval_actual_delta_kappa"][mask] > tol
        rows = {"measure_units": "m2" if bool(volume[mask].all()) else "m",
            "delta_F_error_rms": rms((df - dfr)[mask], weight),
            "delta_F_error_relative_l2": relative(df - dfr, dfr),
            "trial_dev_log_strain_error_rms": rms((dev - devr)[mask], weight),
            "trial_dev_log_strain_error_relative_l2": relative(dev - devr, devr),
            "wall_or_collar_displacement_error_rms_m": rms((end["u_m"] - ref["u_m"])[mask], weight),
            "displacement_error_relative_l2": relative(end["u_m"] - ref["u_m"], ref["u_m"]),
            "kappa_mean": mean(end["kappa"][mask], weight),
            "reference_kappa_mean": mean(ref["kappa"][mask], weight),
            "kappa_max": float(end["kappa"][mask].max()),
            "reference_kappa_max": float(ref["kappa"][mask].max()),
            "actual_delta_kappa_error_relative_l2": relative(
                end["interval_actual_delta_kappa"] - ref["interval_actual_delta_kappa"], ref["interval_actual_delta_kappa"])}
        for prefix, predicted, expected in (("cumulative", pred_plastic, ref_plastic), ("interval_active", pred_active, ref_active)):
            rows[prefix + "_support"] = {"predicted_measure": float(weight[predicted].sum()),
                "reference_measure": float(weight[expected].sum()),
                "false_negative_measure": float(weight[expected & ~predicted].sum()),
                "false_positive_measure": float(weight[predicted & ~expected].sum()),
                "intersection_measure": float(weight[predicted & expected].sum())}
        for label, sigma in (("return", end["sigma_return"]), ("network", end["sigma_network"])):
            rows[label + "_stress_error_four_rms_over_p0"] = component_rms(
                local(sigma - ref["sigma_return"], ref["Q_current"])[mask] / config["p0"], weight)
        details[name] = rows
    output["increment_fields"] = details
    output["definitions"] = {"delta_F": "F_end-F_old in natural coordinates, each solution's own .725 endpoint",
        "trial_dev_log_strain": "dev(0.5 log(F_end inv(Cp_.725) F_end^T)); common-interval predictor only",
        "reference_actual_increment": "Archived .725 -> .71875 -> .7125 native returns retained",
        "support": "kappa or actual interval delta_kappa > fixed plastic_threshold; area/arc-length weights"}
    return output


def to_host(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu()
    if isinstance(value, dict):
        return {key: to_host(item) for key, item in value.items()}
    if isinstance(value, list):
        return [to_host(item) for item in value]
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", default=["gh_gain_recovered_02", "lh_gain_recovered_01", "rh_gain_01"])
    parser.add_argument("--reference", default="reference_gain_union_01")
    parser.add_argument("--config", default="config/mixed_horseshoe_gain_ratio.json")
    parser.add_argument("--angular-panels", nargs=6, type=int, default=[48, 8, 48, 24, 48, 8])
    parser.add_argument("--radial-panels", type=int, default=24)
    parser.add_argument("--quadrature", type=int, default=4)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if min(args.angular_panels + [args.radial_panels, args.quadrature]) < 1:
        raise ValueError("Sampling counts must be positive")
    config = read(ROOT / args.config)
    for name in args.runs:
        if read(folder(name) / "config.json") != config:
            raise ValueError("Official PINN config differs from the declared common config: " + name)
    original = read(folder(args.reference) / "config.json")
    for key in ("geometry", "p0", "material", "outer_widths", "collar_precompressed_m", "plastic_threshold"):
        if original[key] != config[key]:
            raise ValueError("Reference boundary-value problem differs: " + key)
    source_names = (Path(__file__).name, "mixed_pinn.py", "dp_material.py", "dp_reference.py",
        "current_traction.py", "horseshoe_geometry.py", "mixed_geometry.py", "mixed_q2.py",
        "mixed_history.py", "mixed_residual.py", "mixed_reference_sampling.py", "mixed_reference.py", "mixed_krylov.py")
    sources = [ROOT / "code" / name for name in source_names]
    inputs = sources + [ROOT / args.config, ROOT / config["geometry"]]
    for name in args.runs + [args.reference]:
        directory = folder(name)
        inputs.extend(directory / name for name in ("config.json", "result.json"))
        inputs.extend(sorted(directory.glob("accepted_*.pt")))
        for name in ("dp_material.py", "dp_reference.py", "current_traction.py", "horseshoe_geometry.py", "mixed_pinn.py", "mixed_geometry.py", "mixed_q2.py", "mixed_reference_sampling.py"):
            saved_source = directory / "sources" / name
            if saved_source.exists() and digest(saved_source) != digest(ROOT / "code" / name):
                raise ValueError("Saved scientific source differs: " + str(saved_source))
    hashes = {str(path.relative_to(ROOT)): digest(path) for path in inputs}
    out = folder(args.output)
    out.mkdir(exist_ok=False)
    (out / "sources").mkdir()
    for path in sources:
        (out / "sources" / path.name).write_bytes(path.read_bytes())
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.cuda.set_device(0)
    torch.manual_seed(config["seed"])
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    wall, cpu = time.perf_counter(), time.process_time()
    start.record()
    result = {"mode": "saved_field_basis_mechanism", "status": "running", "reference": args.reference,
        "config": args.config, "input_sha256": hashes, "runs": [],
        "sampling": {"angular_panels_by_arc": dict(zip(ARC_NAMES, args.angular_panels)),
                     "radial_panels": args.radial_panels, "quadrature": args.quadrature, "radial_exponent": 2},
        "scope": "Development-selected normal-offset collar including both known underplasticized knees. Common natural material points, physical area/arc-length weights, own complete histories. No optimization or equilibrium solve; no new acceptance or field-accuracy ranking.",
        "definitions": {"components": ["nn", "nt", "tt", "33"],
            "basis": "Q_current=frame(F(X),N(nearest reference wall)); inside collar it is the implemented extended basis, not a recomputed closest point on the current wall.",
            "interval": "Actual kappa growth includes each input's native accepted substeps. Predictor at .7125 uses that input's committed .725 Cp/kappa, is not returned or committed, and is not the reference's native .71875 -> .7125 increment.",
            "compensation_error_alignment_cosine": "Weighted inner product of sigma_network-sigma_return with sigma_reference-sigma_return, divided by their weighted norms. A descriptive association, not evidence of causal correction.",
            "component_variation": "Subtract the weighted angular mean at each fixed normal offset, then integrate squared component deviations over the collar. Coordinate-component variation is not a neural approximation or optimization certificate."}}
    try:
        material = dp.DPParameters.from_young_poisson(**config["material"])
        f0, _, initial = dp.elastic_precompression(material, torch.tensor(config["p0"], device="cuda:0", dtype=torch.float64))
        mesh, grid, checks = collar_points(config, f0, args.angular_panels, args.radial_panels, args.quadrature)
        result["geometry_checks"] = checks
        result["sampling"].update(volume_points=grid["volume_count"], wall_points=len(mesh.boundary.x),
            material_point_identity_sha256=identity(grid["x_natural_m"], torch.arange(len(grid["x_natural_m"]), device=f0.device)),
            delta_natural_m=grid["delta_natural_m"])
        print(json.dumps({"phase": "sampling_ready", **result["sampling"]}), flush=True)
        refs, history = replay_reference(args.reference, mesh, config, f0, material)
        add_interval(refs, material)
        result["reference_history"] = history
        result["reference_native_drive_return_check_max"] = max(row["native_drive_return_check_max"] for row in refs.values())
        result["reference_basis"] = {str(p): summarize_basis(refs[p], grid, f0, initial, config) for p in (.725, .7125, .675)}
        torch.save(to_host({"grid": grid, "reference": refs, "f0": f0}), out / "reference_fields.pt")
        for name in args.runs:
            data, history, method = replay_neural(name, mesh, grid, config, f0, material, initial)
            add_interval(data, material)
            item = {"run": name, "method": method, "accepted_history": history,
                    "native_drive_return_check_max": max(row["native_drive_return_check_max"] for row in data.values()),
                    "endpoint_mismatch": summarize_mismatch(data, refs, grid, config, material)}
            result["runs"].append(item)
            torch.save(to_host(data), out / (name + "_fields.pt"))
            print(json.dumps({"phase": "neural_replay_complete", "run": name,
                              "reference_plastic_collar": item["endpoint_mismatch"]["reference_plastic_collar"]}), flush=True)
            del data
        result["raw_field_sha256"] = {path.name: digest(path) for path in out.glob("*_fields.pt")}
        result["status"] = "complete"
    except Exception as error:
        result["status"], result["error"] = "failed", repr(error)
        raise
    finally:
        end.record()
        torch.cuda.synchronize()
        result["resources"] = {"wall_seconds": time.perf_counter() - wall, "process_cpu_seconds": time.process_time() - cpu,
            "cuda_event_span_seconds_including_host_gaps": start.elapsed_time(end) / 1000,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "process_wall_including_imports": time.perf_counter() - PW, "process_cpu_including_imports": time.process_time() - PC,
            "device": "cuda:0", "dtype": "torch.float64", "tensor_threads": torch.get_num_threads(),
            "interop_threads": torch.get_num_interop_threads(), "pid": os.getpid(), "torch": torch.__version__,
            "cuda_build": torch.version.cuda, "gpu_name": torch.cuda.get_device_name(),
            "cpu_library_threads": {key: os.environ[key] for key in THREAD_KEYS}}
        result["inputs_unchanged"] = all(digest(ROOT / path) == value for path, value in hashes.items())
        if not result["inputs_unchanged"]:
            result["status"], result["error"] = "invalid", "An input changed during diagnostic replay"
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        (out / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        print(json.dumps({"status": result["status"], "resources": result["resources"], "inputs_unchanged": result["inputs_unchanged"]}), flush=True)
    if result["status"] != "complete":
        raise ValueError(result.get("error", "Diagnostic did not complete"))


if __name__ == "__main__":
    main()
