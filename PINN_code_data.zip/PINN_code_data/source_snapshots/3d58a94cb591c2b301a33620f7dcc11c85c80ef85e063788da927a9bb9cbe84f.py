"""Reproducible, isolated GPU feasibility entry; one process and one seed.

Examples (from project root):
  python code/run_mixed_feasibility.py reference --tag reference_base
  python code/run_mixed_feasibility.py pinn --method W-GH --tag gh
  python code/run_mixed_feasibility.py check --tag integration_checks
Each tag must be new. Config, source snapshots, accepted states, failures and
actual process/CUDA-event timing are saved beneath results/mixed_feasibility.
"""
import os
import time
PROCESS_WALL, PROCESS_CPU = time.perf_counter(), time.process_time()
for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
             "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import traceback
import torch
import dp_material as dp
from mixed_geometry import geometry_from_config, wall_geometry_checks
from mixed_reference import ReferenceSolver
from mixed_pinn import MixedNet, EvaluationPool, train_step, checks
from mixed_history import accept_all

ROOT = Path(__file__).resolve().parents[1]


def snapshot():
    p = subprocess.run(["nvidia-smi", "--query-gpu=index,name,memory.used,memory.free,utilization.gpu",
                        "--format=csv,noheader"], capture_output=True, text=True)
    return p.stdout.strip()


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def observations(solver):
    device, dtype = solver.f0.device, solver.f0.dtype
    arc = torch.tensor([0, 0, 0, 3], device=device)
    frac = torch.tensor([0., 1., .5, .5], device=device, dtype=dtype)
    x, _ = solver.mesh.wall.sample(arc, frac)
    current = x @ solver.f0[:2, :2].T+solver.wall_displacement(arc, frac)
    ids = torch.arange(6, device=device).repeat_interleave(128)
    fr = torch.arange(128, device=device, dtype=dtype).repeat(6)/128
    wx = solver.mesh.wall.sample(ids, fr)[0] @ solver.f0[:2, :2].T
    wu = solver.wall_displacement(ids, fr)
    area0 = wall_geometry_checks(wx)["wall_polygon_area_m2"]
    area = wall_geometry_checks(wx+wu)["wall_polygon_area_m2"]
    return {"width_closure": float(1-(current[0]-current[1]).norm()/13.46),
            "height_closure": float(1-(current[2]-current[3]).norm()/11.05), "area_closure": 1-area/area0}, wu


def run_reference(config, f0, material, out, emit):
    mesh = geometry_from_config(config, ROOT, f0, mesh=config["reference_mesh"])
    solver = ReferenceSolver(mesh, f0, material, config["p0"], config["reference"])
    records = []
    pending = list(config["pressures"])
    while pending:
        pressure = pending.pop(0)
        start = time.perf_counter()
        metrics = solver.solve(pressure*config["p0"])
        metrics["wall_seconds"] = time.perf_counter()-start
        if metrics["accepted"]:
            obs, wall_u = observations(solver)
            metrics.update(obs)
            cp = solver.checkpoint()
            cp["wall_displacement_768"] = wall_u
            torch.save(cp, out/f"accepted_{len(records):03d}.pt")
        records.append(metrics)
        save_json(out/"path.json", records)
        emit({"phase": "reference_step", **metrics})
        if not metrics["accepted"]:
            break
    return {"mode": "reference", "records": records, "dofs": 2*len(mesh.free),
            "volume_points": len(mesh.volume.x), "wall_points": len(mesh.boundary.x)}


def resume_prefix(source, config, f0, initial, material, train, validation, model, out, emit, through=None,
                  recover_interrupted=False):
    folder = ROOT/"results/mixed_feasibility"/source
    if folder.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Resume source must be one run name")
    if (folder/"invalidation.json").exists():
        raise ValueError("An invalidated diagnostic cannot supply an accepted history")
    old_config = json.loads((folder/"config.json").read_text(encoding="utf-8"))
    if recover_interrupted:
        from mixed_recovery import read_interrupted
        old_result = read_interrupted(folder, model.method)
    else:
        old_result = json.loads((folder/"result.json").read_text(encoding="utf-8"))
    if (old_result.get("error") not in (None, "Cooperative stop requested for this run")
            or old_result.get("method") != model.method):
        raise ValueError("Resume requires the same method and a completed or cooperatively stopped run")
    records = []
    accepted = [row["pressure_ratio"] for row in old_result["records"] if row["accepted"]]
    if "accepted_pressures" in old_result and accepted != old_result["accepted_pressures"]:
        raise ValueError("Accepted checkpoint index disagrees with physical-step records")
    files = sorted(folder.glob("accepted_*.pt"))
    if len(files) != len(accepted):
        raise ValueError("Incomplete accepted checkpoint sequence")
    if through is not None:
        matches = [i for i, p in enumerate(accepted) if abs(p-through) < 1e-12]
        if len(matches) != 1:
            raise ValueError("Requested resume endpoint is not one accepted source pressure")
        accepted = accepted[:matches[0]+1]
        files = files[:len(accepted)]
    # A new regional training term may be added only when it is inactive on
    # every reused pressure. Thus the accepted prefix has the same objective,
    # budget, fields, material points and physical acceptance in both runs.
    from mixed_residual import REGIONAL_KEYS, regional_enabled
    def compatible_config(candidate):
        result = {k: v for k, v in candidate.items() if k != "pressures"}
        result["optimizer"] = {k: v for k, v in candidate["optimizer"].items() if k not in REGIONAL_KEYS}
        return result
    if compatible_config(old_config) != compatible_config(config):
        raise ValueError("Resume must preserve material, points, architecture, budgets and physical tolerances")
    changed_regions = any(old_config["optimizer"].get(k) != config["optimizer"].get(k) for k in REGIONAL_KEYS)
    if changed_regions and any(regional_enabled(c["optimizer"], p*c["p0"], c["p0"])
                               for c in (old_config, config) for p in accepted):
        raise ValueError("Changed regional objective was active on the reused pressure prefix")
    if config["pressures"][:len(accepted)] != accepted:
        raise ValueError("Accepted source pressures must be the exact target-path prefix")
    for index, path in enumerate(files):
        begin = time.perf_counter()
        saved = torch.load(path, map_location=f0.device, weights_only=True)
        pressure = accepted[index]*config["p0"]
        if abs(saved["pressure"]-pressure) > 1e-12:
            raise ValueError("Resume pressure does not match the checkpoint")
        model.load_state_dict(saved["network"])
        if not torch.equal(model.f0, f0):
            raise ValueError("Resume changed the natural-reference precompression")
        trials, reports, replay_errors = [], [], []
        for pool, key in ((train, "train_history"), (validation, "validation_history")):
            old = saved[key]
            pool.history.check(old["coordinates"], old["ids"], pool.history.state.step)
            if old["step"] != pool.history.state.step+1 or old["identity_sha256"] != pool.history.key:
                raise ValueError("Resume point identity or load step is inconsistent")
            if old["pressures"] != pool.history.pressures+[pressure]:
                raise ValueError("Resume material state is bound to a different pressure history")
            data = pool.evaluate(model, pressure, material, initial, graph=False)
            data["pressure"] = pressure
            report = checks(pool, data, model, config, initial)
            trial = data["trial"]
            error = max(float((old["cp"]-trial.cp).abs().max()), float((old["kappa"]-trial.kappa).abs().max()))
            if not report["accepted"] or error > 1e-10:
                raise ValueError("Resume prefix failed physical acceptance or material-history replay")
            trials.append(trial)
            reports.append(report)
            replay_errors.append(error)
        accept_all([train.history, validation.history], trials, pressure, {"accepted": True})
        torch.save({"network": model.state_dict(), "pressure": pressure,
            "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint()},
            out/f"accepted_{index:03d}.pt")
        record = {"pressure_ratio": accepted[index], "accepted": True, "replayed_prefix": True,
            "source_run": source, "evaluations": 0, "validation": reports[1], "training_physics": reports[0],
            "history_replay_max_error": max(replay_errors),
            "wall_seconds": time.perf_counter()-begin}
        records.append(record)
        save_json(out/"path.json", records)
        emit({"phase": "replayed_prefix", "method": model.method, **record})
    return records, accepted.copy(), old_result["resources"]


def run_pinn(config, f0, initial, material, out, emit, method, resume=None, resume_through=None,
             recover_interrupted=False):
    trainmesh = geometry_from_config(config, ROOT, f0)
    valmesh = geometry_from_config(config, ROOT, f0, mesh=config["validation_mesh"])
    train = EvaluationPool("training", trainmesh, config["p0"])
    validation = EvaluationPool("validation", valmesh, config["p0"])
    model = MixedNet(config, f0, initial, trainmesh.radius, method)
    records, accepted = [], []
    source_resources = None
    if resume is not None:
        records, accepted, source_resources = resume_prefix(resume, config, f0, initial, material,
            train, validation, model, out, emit, resume_through, recover_interrupted)
    pending = list(config["pressures"])[len(accepted):]
    optimizer_resume = None
    recovery_verification = None
    if recover_interrupted:
        from mixed_recovery import restore_optimizer, pending_from_records
        source_records = json.loads((ROOT/"results/mixed_feasibility"/resume/"path.json").read_text(encoding="utf-8"))
        pending = pending_from_records(config, source_records)
        if not pending:
            raise ValueError("Interrupted source already exhausted its admissible pressure queue")
        optimizer_resume = restore_optimizer(ROOT/"results/mixed_feasibility"/resume, config, model,
            train, validation, initial, material, pending[0]*config["p0"])
        recovery_verification = optimizer_resume["verification"]
        recovery_verification["pending_pressures"] = pending.copy()
        # Preserve attempted failures in chronological order without reusing
        # their training cost or treating them as accepted history.
        replayed = iter(records)
        records = [next(replayed) if row["accepted"] else dict(row, replayed_failure_record=True,
            source_run=resume, source_wall_seconds=row["wall_seconds"], wall_seconds=0.)
            for row in source_records]
        save_json(out/"path.json", records)
        emit({"phase": "optimizer_recovery_verified", **recovery_verification})
    while pending:
        pressure = pending.pop(0)
        start = time.perf_counter()
        emit({"phase": "start_pressure", "method": method, "pressure_ratio": pressure})
        def save_candidate(report):
            attempt = len(records)
            temporary = out/f"candidate_{attempt:03d}.tmp.pt"
            torch.save({"network": model.state_dict(), "pressure": pressure*config["p0"], "accepted": False,
                "old_accepted_file": f"accepted_{len(accepted)-1:03d}.pt" if accepted else None,
                "training_state_step": train.history.state.step, "validation_state_step": validation.history.state.step,
                "training_identity": train.history.key, "validation_identity": validation.history.key,
                "physical_report": report}, temporary)
            temporary.replace(out/f"candidate_{attempt:03d}.pt")
        metrics = train_step(model, train, validation, pressure*config["p0"], material, initial, config, emit,
                             save_candidate, optimizer_resume=optimizer_resume)
        optimizer_resume = None
        metrics["wall_seconds"] = time.perf_counter()-start
        if metrics["accepted"]:
            step = {"network": model.state_dict(), "pressure": pressure*config["p0"],
                    "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint()}
            torch.save(step, out/f"accepted_{len(accepted):03d}.pt")
            accepted.append(pressure)
        records.append(metrics)
        save_json(out/"path.json", records)
        emit({"phase": "pinn_step", "method": method, **metrics})
        if not metrics["accepted"]:
            # Full parameter rollback already occurred. No failed trial is committed.
            previous = accepted[-1] if accepted else 1.
            if previous-pressure >= 2*config["minimum_pressure_increment"]-1e-12:
                middle = round(.5*(previous+pressure), 12)
                pending[0:0] = [middle, pressure]
                emit({"phase": "load_step_bisection", "rejected": pressure, "retry": middle})
            else:
                break
    return {"mode": "pinn", "method": method, "records": records, "accepted_pressures": accepted,
            "resumed_from": resume, "resumed_through": resume_through,
            "recovered_interrupted_optimizer": recover_interrupted, "recovery_verification": recovery_verification,
            "source_run_resources": source_resources,
            "source_resource_scope": "Entire source run, including diagnostics; excluded from this run's timers and not a prefix-only cost",
            "parameters": sum(p.numel() for p in model.parameters()),
            "training_points": len(train.x), "validation_points": len(validation.x),
            "training_identity": train.history.key, "validation_identity": validation.history.key}


def run_conditional_increment(config, f0, initial, material, out, emit, source, mechanism):
    """One .725 -> .7125 GH solve, conditioned on an immutable accepted history."""
    from mixed_history import identity
    from mixed_residual import objective, regional_enabled, regional_excess, WEAK_COUPLINGS
    from assess_mixed_basis_mechanism import (folder, read, digest, to_host,
        evaluate_conditional_endpoint, summarize_conditional_increment, conditional_return_anchor)
    from copy import deepcopy
    start_ratio, end_ratio = .725, .7125
    start_pressure, end_pressure = start_ratio * config["p0"], end_ratio * config["p0"]
    directory, archive = folder(source), folder(mechanism)
    old_config, metadata, mechanism_meta = [read(p) for p in
        (directory/"config.json", directory/"result.json", archive/"result.json")]
    candidate_config = deepcopy(config)
    candidate_config["optimizer"].pop("weak_coupling", None)
    representation = candidate_config.pop("stress_representation", "independent")
    if representation not in ("independent", "anchored_return_increment"):
        raise ValueError("Unknown conditional stress representation")
    lifting = representation == "anchored_return_increment"
    if candidate_config != old_config or metadata.get("method") != "W-GH":
        raise ValueError("Conditional increment must preserve the entire original GH configuration")
    expected_coupling = "constitutive_difference" if lifting else "material_equilibrium"
    if config["optimizer"].get("weak_coupling", "constitutive_difference") != expected_coupling:
        raise ValueError("Conditional stress lifting and residual replacement cannot be combined")
    if mechanism_meta.get("status") != "complete" or not mechanism_meta.get("inputs_unchanged"):
        raise ValueError("A complete immutable mechanism archive is required")
    accepted = [r for r in metadata["records"] if r["accepted"]]
    files = sorted(directory.glob("accepted_*.pt"))
    if len(files) != len(accepted):
        raise ValueError("Accepted checkpoint/record coverage differs")
    indices = [next(i for i, r in enumerate(accepted) if r["pressure_ratio"] == p)
               for p in (start_ratio, end_ratio)]
    if indices[1] != indices[0] + 1:
        raise ValueError("The original neural increment must have no intermediate accepted step")
    start_path, baseline_path = [files[i] for i in indices]
    origin = folder(accepted[indices[1]].get("source_run", source))
    original_record = next(r for r in read(origin/"path.json")
                           if r["pressure_ratio"] == end_ratio and r["accepted"])
    original_events, active = [], False
    for line in (origin/"events.jsonl").read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row.get("phase") == "start_pressure":
            if active:
                break
            active = row["pressure_ratio"] == end_ratio
        if active:
            original_events.append(row)
    original_initial = next(r for r in original_events if r.get("phase") == "physical_validation")
    original_newton = [r for r in original_events if r.get("phase") == "full_newton"]
    if not original_newton or original_record.get("replayed_prefix"):
        raise ValueError("Need the original optimization record, not replay cost")
    inputs = [directory/"config.json", directory/"result.json", start_path, baseline_path,
              origin/"path.json", origin/"events.jsonl", archive/"result.json",
              archive/"reference_fields.pt", archive/(source+"_fields.pt")]
    input_hashes = {str(p.relative_to(ROOT)): digest(p) for p in inputs}
    for path in (directory/"config.json", directory/"result.json", start_path, baseline_path):
        if digest(path) != mechanism_meta["input_sha256"][str(path.relative_to(ROOT))]:
            raise ValueError("Saved endpoint input no longer matches the mechanism archive")
    for path in inputs[-2:]:
        if digest(path) != mechanism_meta["raw_field_sha256"][path.name]:
            raise ValueError("Archived field checksum changed")
    allowed = {"run_mixed_feasibility.py", "mixed_residual.py", "mixed_head_newton.py", "mixed_full_newton.py"}
    allowed.update(("current_traction.py", "mixed_pinn.py", "mixed_local_jacobian.py"))
    source_changes = {}
    for name, saved_hash in metadata["source_sha256"].items():
        live, saved = ROOT/name, directory/"sources"/Path(name).name
        if digest(saved) != saved_hash:
            raise ValueError("Original source snapshot checksum changed: " + name)
        current = digest(live)
        if current != saved_hash:
            if live.name not in allowed:
                raise ValueError("Unplanned scientific source change: " + name)
            source_changes[name] = {"original": saved_hash, "candidate": current}
    restored = torch.load(start_path, map_location=f0.device, weights_only=True)
    baseline = torch.load(baseline_path, map_location=f0.device, weights_only=True)
    if restored["pressure"] != start_pressure or baseline["pressure"] != end_pressure:
        raise ValueError("Checkpoint pressure mismatch")
    trainmesh = geometry_from_config(config, ROOT, f0)
    train = EvaluationPool("training", trainmesh, config["p0"])
    validation = EvaluationPool("validation", geometry_from_config(config, ROOT, f0,
                                mesh=config["validation_mesh"]), config["p0"])
    model = MixedNet(config, f0, initial, trainmesh.radius, "W-GH")
    pools = ((train, "train_history", "training_physics"), (validation, "validation_history", "validation"))
    def restore_histories():
        for pool, key, _ in pools:
            saved, later = restored[key], baseline[key]
            if (saved["name"] != pool.history.name or saved["identity_sha256"] != pool.history.key
                    or not torch.equal(saved["coordinates"], pool.x) or not torch.equal(saved["ids"], pool.history.ids)
                    or later["identity_sha256"] != pool.history.key or saved["step"] != indices[0]+1
                    or later["step"] != saved["step"]+1 or later["pressures"] != saved["pressures"]+[end_pressure]
                    or saved["pressures"] != [config["p0"]]+[r["pressure_ratio"]*config["p0"] for r in accepted[:indices[0]+1]]):
                raise ValueError("Checkpoint history identity, coordinates or pressure sequence differs")
            pool.history.state = dp.MaterialState(saved["cp"].clone(), saved["kappa"].clone(), saved["step"])
            pool.history.pressures = saved["pressures"].copy()
    restore_histories()
    def compare_report(actual, expected):
        errors = []
        for key, value in expected.items():
            present = actual[key]
            if isinstance(value, dict):
                errors.append(compare_report(present, value))
            elif isinstance(value, (int, float)) and not isinstance(value, bool):
                error = abs(present-value)/max(1., abs(value))
                if error > 1e-10:
                    raise ValueError("Restored report differs: " + key)
                errors.append(error)
            elif present != value:
                raise ValueError("Restored discrete report differs: " + key)
        return max(errors, default=0.)
    def measure_model(expected=None, expected_state=None):
        output = {}
        for pool, key, label in pools:
            data = pool.evaluate(model, end_pressure, material, initial, graph=False)
            physical = checks(pool, data, model, config, initial)
            blocks = {name: {"local_mean_square": float(data[local].square().mean()),
                            "multiscale_mean_square": float(data[multi].square().mean())}
                for name, local, multi in (("network", "weak", "multi"),
                    ("constitutive_difference", "constitutive_weak", "constitutive_multi"),
                    ("material", "material_weak", "material_multi"))}
            blocks["point_consistency"] = float(pool.consistency(data, model.delta))
            blocks["regional_excess_sum_square"] = (float(regional_excess(data["error"], pool,
                model.delta, config["optimizer"]).square().sum()) if regional_enabled(
                config["optimizer"], end_pressure, config["p0"]) else 0.)
            blocks["load_amplitude"] = float(model.load_amplitude)
            objectives = {kind: float(objective(data, pool, model, dict(config["optimizer"], weak_coupling=kind)))
                          for kind in WEAK_COUPLINGS}
            row = {"physical": physical, "residual_blocks": blocks, "objectives": objectives}
            if expected is not None:
                row["saved_report_scaled_max_error"] = compare_report(physical, expected[label])
            if expected_state is not None:
                error = max(float((data["trial"].cp-expected_state[key]["cp"]).abs().max()),
                            float((data["trial"].kappa-expected_state[key]["kappa"]).abs().max()))
                if error > 1e-10:
                    raise ValueError("Restored baseline material endpoint differs")
                row["saved_material_max_error"] = error
            output[label] = row
        return output
    model.load_state_dict(baseline["network"])
    if not torch.equal(model.f0, f0) or not torch.equal(model.initial_stress, initial.sigma):
        raise ValueError("Initial precompression or stress changed")
    baseline_measures = measure_model(original_record, baseline)
    original_loss_error = abs(baseline_measures["training_physics"]["objectives"]["constitutive_difference"]
                              -original_newton[-1]["loss"])
    if original_loss_error > 1e-10:
        raise ValueError("Restored original objective differs from the final Gauss-Newton event")
    model.load_state_dict(restored["network"])
    if not torch.equal(model.f0, f0) or not torch.equal(model.initial_stress, initial.sigma):
        raise ValueError("Restored start changed initial precompression")
    model.set_pressure(end_pressure)
    initial_measures = measure_model(original_initial)
    anchor_payload, anchor_reference, anchor_seconds = None, {}, 0.
    anchored_initial_error = None
    if lifting:
        anchor_begin = time.perf_counter()
        for pool, _, _ in pools:
            pool.freeze_return_anchor(model, end_pressure, material)
        torch.cuda.synchronize()
        anchor_seconds = time.perf_counter()-anchor_begin
        anchored_initial_error = compare_report(measure_model(original_initial), initial_measures)
        anchor_payload = {"stress_representation": representation, "interval": [start_ratio, end_ratio],
            "start_checkpoint": str(start_path.relative_to(ROOT)), "start_checkpoint_sha256": digest(start_path),
            "predictor_network": deepcopy(model.state_dict()), "old_state_step": train.history.state.step,
            "training": train.return_anchor_checkpoint(), "validation": validation.return_anchor_checkpoint()}
        torch.save(anchor_payload, out/"stress_anchors.pt")
        anchor_reference = {"stress_anchor_file": "stress_anchors.pt",
                            "stress_anchor_sha256": digest(out/"stress_anchors.pt")}
    model.load_state_dict(restored["network"])
    provenance = {"source_run": source, "original_optimization_run": origin.name,
        "start_checkpoint": str(start_path.relative_to(ROOT)), "baseline_checkpoint": str(baseline_path.relative_to(ROOT)),
        "interval": [start_ratio, end_ratio], "old_state_step": train.history.state.step,
        "training_identity": train.history.key, "validation_identity": validation.history.key,
        "input_sha256": input_hashes, "source_changes": source_changes,
        "baseline_measurements": baseline_measures, "initial_predictor_measurements": initial_measures,
        "original_objective_absolute_error": original_loss_error, "original_increment_record": original_record,
        "original_newton_events": original_newton,
        "stress_representation": representation, "stress_anchor": anchor_reference,
        "anchor_construction_wall_seconds": anchor_seconds,
        "anchored_initial_scaled_max_error": anchored_initial_error,
        "scope": "One conditional increment; fixed original old history; reference fields only used after training"}
    save_json(out/"restoration.json", provenance)
    torch.save(restored, out/"initial_state.pt")
    emit({"phase": "conditional_restore_verified", "interval": provenance["interval"],
          "old_state_step": train.history.state.step, "original_objective_absolute_error": original_loss_error,
          "original_increment_wall_seconds": original_record["wall_seconds"],
          "stress_representation": representation, "anchored_initial_scaled_max_error": anchored_initial_error})
    def save_candidate(report):
        temporary = out/"candidate.tmp.pt"
        torch.save({"network": model.state_dict(), "pressure": end_pressure,
            "old_checkpoint": provenance["start_checkpoint"], "old_checkpoint_sha256": digest(start_path),
            "training_state_step": train.history.state.step, "validation_state_step": validation.history.state.step,
            "training_identity": train.history.key, "validation_identity": validation.history.key,
            "physical_report": report, **anchor_reference}, temporary)
        temporary.replace(out/"candidate.pt")
    train_begin = time.perf_counter()
    metrics = train_step(model, train, validation, end_pressure, material, initial, config, emit,
                         save_candidate, optimizer_resume=None)
    metrics["wall_seconds"] = time.perf_counter()-train_begin
    save_json(out/"path.json", [metrics])
    if metrics["accepted"]:
        torch.save({"network": model.state_dict(), "pressure": end_pressure,
                    "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint(),
                    **anchor_reference},
                   out/"accepted_conditional.pt")
    emit({"phase": "conditional_increment_finished", **metrics})
    # train_step can roll back a rejected network. Evaluate its last callback,
    # and restore the old private histories before any endpoint return.
    candidate = torch.load(out/"candidate.pt", map_location=f0.device, weights_only=True)
    model.load_state_dict(candidate["network"])
    restore_histories()
    if lifting:
        if (candidate.get("stress_anchor_file") != "stress_anchors.pt"
                or candidate.get("stress_anchor_sha256") != digest(out/"stress_anchors.pt")):
            raise ValueError("Candidate stress anchor reference changed")
        anchor_payload = torch.load(out/"stress_anchors.pt", map_location=f0.device, weights_only=True)
        if (anchor_payload["start_checkpoint_sha256"] != digest(start_path)
                or anchor_payload["interval"] != [start_ratio, end_ratio]
                or anchor_payload["old_state_step"] != train.history.state.step):
            raise ValueError("Reloaded stress anchor provenance differs")
        train.restore_return_anchor(anchor_payload["training"])
        validation.restore_return_anchor(anchor_payload["validation"])
    final_measures = measure_model(metrics)
    eval_begin = time.perf_counter()
    archive_ref = torch.load(archive/"reference_fields.pt", map_location=f0.device, weights_only=True)
    base_fields = torch.load(archive/(source+"_fields.pt"), map_location=f0.device, weights_only=True)
    grid, refs = archive_ref["grid"], archive_ref["reference"]
    grid_identity = identity(grid["x_natural_m"], torch.arange(len(grid["x_natural_m"]), device=f0.device))
    if (not torch.equal(archive_ref["f0"], f0)
            or grid_identity != mechanism_meta["sampling"]["material_point_identity_sha256"]
            or base_fields[end_ratio]["previous_pressure_ratio"] != start_ratio
            or refs[end_ratio]["previous_pressure_ratio"] != .71875):
        raise ValueError("Archived material points or native interval changed")
    evaluation_anchor, evaluation_anchor_seconds = None, 0.
    if lifting:
        anchor_begin = time.perf_counter()
        predictor_model = MixedNet(config, f0, initial, trainmesh.radius, "W-GH")
        predictor_model.load_state_dict(anchor_payload["predictor_network"])
        evaluation_anchor = conditional_return_anchor(predictor_model, base_fields[start_ratio], grid,
                                                     material, restored["train_history"]["step"])
        torch.cuda.synchronize()
        evaluation_anchor_seconds = time.perf_counter()-anchor_begin
        torch.save({"sigma": evaluation_anchor, "point_identity_sha256": grid_identity,
                    "pressure": end_pressure, "stress_anchor_sha256": anchor_reference["stress_anchor_sha256"],
                    "old_state_step": restored["train_history"]["step"]}, out/"evaluation_anchor.pt")
        del predictor_model
    fields = {start_ratio: base_fields[start_ratio], end_ratio: evaluate_conditional_endpoint(
        model, base_fields[start_ratio], grid, material, end_ratio, restored["train_history"]["step"], evaluation_anchor)}
    comparison = {"baseline": summarize_conditional_increment(base_fields, refs, grid, config, material),
                  "candidate": summarize_conditional_increment(fields, refs, grid, config, material)}
    torch.save(to_host(fields), out/"candidate_fields.pt")
    final_inputs = all(digest(ROOT/p) == h for p, h in input_hashes.items())
    if not final_inputs:
        raise ValueError("A source input changed during the conditional solve")
    return {"mode": "conditional_increment", "method": "W-GH", "status": "complete",
        "accepted": metrics["accepted"], "records": [metrics], "restoration": provenance,
        "candidate_measurements": final_measures, "field_comparison": comparison,
        "field_evaluation_wall_seconds": time.perf_counter()-eval_begin,
        "sampling": mechanism_meta["sampling"], "inputs_unchanged": final_inputs,
        "stress_representation": representation, "stress_anchor": anchor_reference,
        "evaluation_anchor_wall_seconds": evaluation_anchor_seconds,
        "evaluation_anchor_sha256": digest(out/"evaluation_anchor.pt") if lifting else None,
        "candidate_fields_sha256": digest(out/"candidate_fields.pt"),
        "parameters": sum(p.numel() for p in model.parameters()),
        "training_points": len(train.x), "validation_points": len(validation.x),
        "scope": "No pressure queue, prefix replay, reference labels, or changes to source histories"}


def run_configuration_increment(config, f0, initial, material, out, emit, source, mechanism, baseline_run):
    """One configuration-displacement increment with a saved PINN-only baseline."""
    from copy import deepcopy
    from mixed_history import identity
    from mixed_pinn import FrozenConfiguration
    from mixed_residual import objective, regional_enabled, regional_excess
    from assess_mixed_basis_mechanism import (folder, read, digest, to_host, ARC_NAMES, collar_points,
        select_pinn_fields, evaluate_conditional_endpoint, summarize_internal_increment)
    start_ratio, end_ratio = .725, .7125
    start_pressure, end_pressure = start_ratio*config["p0"], end_ratio*config["p0"]
    directory, archive, pair = folder(source), folder(mechanism), folder(baseline_run)
    original_config, original, mechanism_meta, paired = [read(path) for path in
        (directory/"config.json", directory/"result.json", archive/"result.json", pair/"result.json")]
    plain_config = deepcopy(config)
    representation = plain_config.pop("displacement_representation", None)
    if (representation != "accepted_configuration_increment" or config.get("stress_representation", "independent") != "independent"
            or config["optimizer"].get("weak_coupling") != "material_equilibrium"):
        raise ValueError("Configuration displacement requires material equilibrium and independent GH stress")
    if plain_config != read(pair/"config.json"):
        raise ValueError("Only displacement representation may differ from the paired return-balance configuration")
    old_config = deepcopy(plain_config)
    old_config["optimizer"].pop("weak_coupling")
    if old_config != original_config or original.get("method") != "W-GH":
        raise ValueError("The original GH physics, point pools and optimization limits must remain fixed")
    if (paired.get("status") != "complete" or not paired.get("accepted") or paired.get("method") != "W-GH"
            or paired.get("stress_representation", "independent") != "independent" or len(paired["records"]) != 1
            or paired["records"][0]["pressure_ratio"] != end_ratio or not paired.get("inputs_unchanged")):
        raise ValueError("Need the completed independent-stress return-balance PINN increment")
    if (mechanism_meta.get("status") != "complete" or not mechanism_meta.get("inputs_unchanged")
            or paired["sampling"] != mechanism_meta["sampling"]):
        raise ValueError("Saved PINN sampling provenance differs")
    start_path = directory/"accepted_008.pt"
    base_path, base_fields_path = pair/"accepted_conditional.pt", pair/"candidate_fields.pt"
    old_fields_path = archive/(source+"_fields.pt")
    inputs = [directory/"config.json", directory/"result.json", start_path,
        pair/"config.json", pair/"result.json", pair/"events.jsonl", base_path, base_fields_path,
        archive/"result.json", old_fields_path, ROOT/config["geometry"]]
    input_hashes = {str(path.relative_to(ROOT)).replace("\\", "/"): digest(path) for path in inputs}
    start_key = str(start_path.relative_to(ROOT)).replace("\\", "/")
    old_hashes = {key.replace("\\", "/"): value for key, value in paired["restoration"]["input_sha256"].items()}
    if (input_hashes[start_key] != old_hashes[start_key] or paired["restoration"]["old_state_step"] != 9
            or digest(base_fields_path) != paired["candidate_fields_sha256"]
            or digest(old_fields_path) != mechanism_meta["raw_field_sha256"][old_fields_path.name]):
        raise ValueError("Saved old history or paired field checksum differs")
    allowed = {"mixed_residual.py", "mixed_head_newton.py", "mixed_full_newton.py", "mixed_pinn.py",
        "mixed_local_jacobian.py", "mixed_history.py", "mixed_recovery.py", "run_mixed_feasibility.py",
        "assess_mixed_basis_mechanism.py", "current_traction.py"}
    source_changes = {}
    for name, saved_hash in original["source_sha256"].items():
        live, saved = ROOT/name, directory/"sources"/Path(name).name
        if digest(saved) != saved_hash:
            raise ValueError("Original source snapshot changed: "+name)
        current = digest(live)
        if current != saved_hash:
            if live.name not in allowed:
                raise ValueError("Unplanned source change: "+name)
            source_changes[name] = {"original": saved_hash, "candidate": current}
    restored = torch.load(start_path, map_location=f0.device, weights_only=True)
    baseline_checkpoint = torch.load(base_path, map_location=f0.device, weights_only=True)
    if restored["pressure"] != start_pressure or baseline_checkpoint["pressure"] != end_pressure:
        raise ValueError("Conditional checkpoint pressure differs")
    mesh = geometry_from_config(config, ROOT, f0)
    train = EvaluationPool("training", mesh, config["p0"])
    validation = EvaluationPool("validation", geometry_from_config(config, ROOT, f0,
        mesh=config["validation_mesh"]), config["p0"])
    pools = ((train, "train_history", "training_physics"), (validation, "validation_history", "validation"))
    accepted = [row["pressure_ratio"]*config["p0"] for row in original["records"] if row["accepted"]][:9]
    if len(accepted) != 9 or accepted[-1] != start_pressure:
        raise ValueError("The accepted source prefix does not end at step 9, .725")
    def restore_histories():
        for pool, key, _ in pools:
            saved, later = restored[key], baseline_checkpoint[key]
            if (saved["step"] != 9 or saved["name"] != pool.history.name or saved["identity_sha256"] != pool.history.key
                    or not torch.equal(saved["coordinates"], pool.x) or not torch.equal(saved["ids"], pool.history.ids)
                    or saved["pressures"] != [config["p0"]]+accepted or later["step"] != 10
                    or later["identity_sha256"] != pool.history.key or later["pressures"] != saved["pressures"]+[end_pressure]):
                raise ValueError("Conditional material history identity or pressure sequence differs")
            pool.history.state = dp.MaterialState(saved["cp"].clone(), saved["kappa"].clone(), saved["step"])
            pool.history.pressures = saved["pressures"].copy()
    restore_histories()
    model = MixedNet(config, f0, initial, mesh.radius, "W-GH")
    model.load_state_dict(restored["network"])
    if not torch.equal(model.f0, f0) or not torch.equal(model.initial_stress, initial.sigma):
        raise ValueError("Restored field changed precompression")
    if sum(p.numel() for p in model.parameters()) != 13372:
        raise ValueError("The conditional field must retain 13372 trainable parameters")
    def measure(current):
        output = {}
        for pool, _, label in pools:
            data = pool.evaluate(current, end_pressure, material, initial, graph=False)
            blocks = {name: {"local_mean_square": float(data[local].square().mean()),
                            "multiscale_mean_square": float(data[multi].square().mean())}
                for name, local, multi in (("network", "weak", "multi"),
                    ("constitutive_difference", "constitutive_weak", "constitutive_multi"),
                    ("material", "material_weak", "material_multi"))}
            blocks["point_consistency"] = float(pool.consistency(data, current.delta))
            blocks["regional_excess_sum_square"] = (float(regional_excess(data["error"], pool, current.delta,
                config["optimizer"]).square().sum()) if regional_enabled(config["optimizer"], end_pressure, current.p0) else 0.)
            blocks["load_amplitude"] = float(current.load_amplitude)
            output[label] = {"physical": checks(pool, data, current, config, initial), "residual_blocks": blocks,
                "objectives": {"material_equilibrium": float(objective(data, pool, current, config["optimizer"]))}}
        return output
    def compare(actual, expected):
        errors = []
        for key, value in actual.items():
            other = expected[key]
            if isinstance(value, dict):
                errors.append(compare(value, other))
            elif isinstance(value, (float, int)) and not isinstance(value, bool):
                errors.append(abs(value-other)/max(1., abs(other)))
            elif value != other:
                raise ValueError("Saved discrete report differs: "+key)
        error = max(errors, default=0.)
        if error > 1e-10:
            raise ValueError("Saved conditional field report differs: "+str(error))
        return error
    context_source = {"start_checkpoint": start_key, "start_checkpoint_sha256": digest(start_path),
        "interval": [start_ratio, end_ratio], "old_state_step": 9,
        "training_identity": train.history.key, "validation_identity": validation.history.key}
    context = FrozenConfiguration(model, end_pressure, context_source)
    model.set_pressure(end_pressure)
    predictor_measurements = measure(model)
    saved_predictor_error = compare(predictor_measurements, paired["restoration"]["initial_predictor_measurements"])
    torch.cuda.synchronize()
    cache_begin = time.perf_counter()
    for pool, _, _ in pools:
        context.prepare(pool.x)
    ids = torch.arange(6, device=f0.device).repeat_interleave(128)
    fractions = torch.arange(128, device=f0.device, dtype=f0.dtype).repeat(6)/128
    wall_points, _ = mesh.wall.sample(ids, fractions)
    context.prepare(wall_points)
    context.prepare(f0.new_tensor([[6.73, 0], [-6.73, 0], [0, 6.73], [0, -4.32]])/f0[0, 0])
    torch.cuda.synchronize()
    cache_seconds = time.perf_counter()-cache_begin
    model.set_displacement_context(context)
    initial_measurements = measure(model)
    predictor_error = compare(initial_measurements, predictor_measurements)
    field_errors = {}
    for pool, _, label in pools:
        new = pool.evaluate(model, end_pressure, material, initial, graph=False)
        old = pool.evaluate(context.predictor_model, end_pressure, material, initial, graph=False)
        field_errors[label] = max(float((new[key]-old[key]).abs().max()) for key in ("u", "f", "stress", "weak", "multi", "material_weak", "material_multi"))
        field_errors[label] = max(field_errors[label], float((new["trial"].sigma-old["trial"].sigma).abs().max()))
        if field_errors[label] > 1e-10:
            raise ValueError("Configuration predictor fields differ")
    save_begin = time.perf_counter()
    torch.save(context.checkpoint(), out/"configuration_context.pt")
    context_reference = {"displacement_representation": representation,
        "configuration_context_file": "configuration_context.pt",
        "configuration_context_sha256": digest(out/"configuration_context.pt")}
    torch.save(restored, out/"initial_state.pt")
    context_save_seconds = time.perf_counter()-save_begin
    provenance = {**context_source, "source_run": source, "baseline_run": baseline_run,
        "baseline_checkpoint": str(base_path.relative_to(ROOT)).replace("\\", "/"),
        "baseline_increment_record": paired["records"][0], "baseline_measurements": paired["candidate_measurements"],
        "input_sha256": input_hashes, "source_changes": source_changes, "initial_predictor_measurements": initial_measurements,
        "saved_predictor_scaled_max_error": saved_predictor_error, "initial_scaled_max_error": predictor_error,
        "initial_field_max_errors": field_errors, "configuration_cache_wall_seconds": cache_seconds,
        "context_save_wall_seconds": context_save_seconds, **context_reference,
        "scope": "One conditional PINN increment; no reference fields, labels, pressure queue or prefix replay"}
    save_json(out/"restoration.json", provenance)
    emit({"phase": "configuration_restore_verified", "old_state_step": 9, "interval": [start_ratio, end_ratio],
        "initial_field_max_errors": field_errors, "initial_scaled_max_error": predictor_error,
        "configuration_cache_wall_seconds": cache_seconds, "baseline_increment_wall_seconds": paired["records"][0]["wall_seconds"]})
    model.clear_displacement_context()
    model.load_state_dict(restored["network"])
    def save_candidate(report):
        temporary = out/"candidate.tmp.pt"
        torch.save({"network": model.state_dict(), "pressure": end_pressure, "accepted": False,
            "old_checkpoint": start_key, "old_checkpoint_sha256": digest(start_path),
            "training_state_step": train.history.state.step, "validation_state_step": validation.history.state.step,
            "training_identity": train.history.key, "validation_identity": validation.history.key,
            "physical_report": report, **context_reference}, temporary)
        temporary.replace(out/"candidate.pt")
    torch.cuda.synchronize()
    train_begin = time.perf_counter()
    metrics = train_step(model, train, validation, end_pressure, material, initial, config, emit,
        candidate_callback=save_candidate, displacement_context=context)
    torch.cuda.synchronize()
    metrics["wall_seconds"] = time.perf_counter()-train_begin
    if metrics["accepted"]:
        torch.save({"network": model.state_dict(), "pressure": end_pressure, "accepted": True,
            "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint(),
            **context_reference}, out/"accepted_conditional.pt")
    else:
        if model.displacement_context is not None or any(not torch.equal(model.state_dict()[key], value)
                for key, value in restored["network"].items()):
            raise ValueError("Rejected conditional field did not restore the complete .725 representation")
        metrics["rejected_field_rollback_verified"] = True
    save_json(out/"path.json", [metrics])
    emit({"phase": "conditional_increment_finished", **metrics})
    reload_begin = time.perf_counter()
    candidate = torch.load(out/"candidate.pt", map_location=f0.device, weights_only=True)
    if (candidate["configuration_context_file"] != "configuration_context.pt"
            or candidate["configuration_context_sha256"] != digest(out/"configuration_context.pt")
            or candidate["old_checkpoint_sha256"] != digest(start_path) or candidate["pressure"] != end_pressure):
        raise ValueError("Candidate context or old field provenance changed")
    saved_context = torch.load(out/"configuration_context.pt", map_location=f0.device, weights_only=True)
    if saved_context["source"] != context_source:
        raise ValueError("Restored configuration source binding differs")
    loaded = MixedNet(config, f0, initial, mesh.radius, "W-GH")
    loaded.set_pressure(end_pressure)
    loaded_context = FrozenConfiguration.restore(loaded, saved_context)
    if any(not torch.equal(loaded_context.old_model.state_dict()[key], value) for key, value in restored["network"].items()):
        raise ValueError("Restored configuration changed the frozen accepted parameters")
    loaded.set_displacement_context(loaded_context)
    loaded.load_state_dict(candidate["network"])
    restore_histories()
    final_measurements = measure(loaded)
    for _, _, label in pools:
        compare(final_measurements[label]["physical"], metrics[label])
    torch.cuda.synchronize()
    reload_seconds = time.perf_counter()-reload_begin
    eval_begin = time.perf_counter()
    sampling = paired["sampling"]
    _, grid, geometry_checks = collar_points(config, f0,
        [sampling["angular_panels_by_arc"][name] for name in ARC_NAMES], sampling["radial_panels"], sampling["quadrature"])
    grid_identity = identity(grid["x_natural_m"], torch.arange(len(grid["x_natural_m"]), device=f0.device))
    if grid_identity != sampling["material_point_identity_sha256"]:
        raise ValueError("Pure geometric evaluation points differ from the saved PINN archive")
    old_fields = select_pinn_fields(torch.load(old_fields_path, map_location=f0.device, weights_only=True))
    base_fields = select_pinn_fields(torch.load(base_fields_path, map_location=f0.device, weights_only=True))
    old = old_fields[start_ratio]
    fields = {start_ratio: old, end_ratio: evaluate_conditional_endpoint(loaded, old, grid, material, end_ratio, 9)}
    fields = select_pinn_fields(fields)
    comparison = summarize_internal_increment(fields, base_fields, grid, config, material)
    torch.save(to_host(fields), out/"candidate_fields.pt")
    torch.save(to_host(grid), out/"evaluation_geometry.pt")
    torch.cuda.synchronize()
    eval_seconds = time.perf_counter()-eval_begin
    if not all(digest(ROOT/path) == value for path, value in input_hashes.items()):
        raise ValueError("A conditional input changed during the solve")
    return {"mode": "conditional_configuration_increment", "method": "W-GH", "status": "complete",
        "accepted": metrics["accepted"], "records": [metrics], "restoration": provenance,
        "candidate_measurements": final_measurements, "internal_field_comparison": comparison,
        "sampling": sampling, "geometry_checks": geometry_checks, "inputs_unchanged": True,
        "configuration_cache_wall_seconds": cache_seconds, "context_save_wall_seconds": context_save_seconds,
        "candidate_reload_wall_seconds": reload_seconds, "field_evaluation_wall_seconds": eval_seconds,
        "candidate_fields_sha256": digest(out/"candidate_fields.pt"),
        "evaluation_geometry_sha256": digest(out/"evaluation_geometry.pt"), **context_reference,
        "parameters": sum(p.numel() for p in loaded.parameters()), "training_points": len(train.x),
        "validation_points": len(validation.x), "scope": provenance["scope"]}


def publish_accepted_field(out, field, train, validation, parents, material_id, metrics, before_publish=None):
    """Publish a field and both committed histories through one manifest."""
    if not metrics["accepted"] or train.history.state.step != validation.history.state.step:
        raise ValueError("Only a jointly accepted state can be published")
    reference = field.save(out/"fields")
    for pool, key in ((train, "train_history"), (validation, "validation_history")):
        parent = parents[key]
        if (pool.history.state.step != parent["step"]+1
                or pool.history.pressures != parent["pressures"]+[field.pressure]):
            raise ValueError("Accepting field and material histories have different intervals")
        pool.history.bind(field.field_id, material_id, parent.get("binding", {}).get("history_chain_id"))
    step = train.history.state.step
    payload = {"accepted": True, "field_schema_version": 2, "field_reference": reference,
        "parent_field_id": field.nodes[-1]["parent_field_id"], "pressure": field.pressure,
        "train_history": train.history.checkpoint(), "validation_history": validation.history.checkpoint(),
        "parent_train_history": parents["train_history"], "parent_validation_history": parents["validation_history"],
        "physical_report": metrics}
    path = out/f"accepted_{step:03d}.pt"
    temporary = path.with_suffix(".tmp.pt")
    torch.save(payload, temporary)
    temporary.replace(path)
    manifest_path = out/"accepted_path.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else []
    if manifest and manifest[-1]["field_id"] != payload["parent_field_id"]:
        raise ValueError("Published acceptance would fork the current path")
    manifest.append({"file": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "field_id": field.field_id, "pressure": field.pressure, "step": step,
        "history_chain_ids": [pool.history.history_chain_id for pool in (train, validation)]})
    if before_publish is not None:
        before_publish()
    temp_manifest = out/"accepted_path.tmp.json"
    save_json(temp_manifest, manifest)
    temp_manifest.replace(manifest_path)
    return payload


def run_configuration_continuation(config, f0, initial, material, out, emit, source, continue_candidate=None):
    """Two prescribed pressure steps, with optional saved-candidate continuation."""
    from copy import deepcopy
    from mixed_pinn import AcceptedField, ContinuousConfiguration, FrozenConfiguration
    from mixed_history import content_identity, identity
    from assess_mixed_basis_mechanism import (select_pinn_fields, evaluate_conditional_endpoint,
        summarize_continuation, to_host)
    directory = ROOT/"results/mixed_feasibility"/source
    if directory.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Continuation source must be one run name")
    metadata = json.loads((directory/"result.json").read_text(encoding="utf-8"))
    source_config = json.loads((directory/"config.json").read_text(encoding="utf-8"))
    expected = deepcopy(source_config)
    expected["displacement_representation"] = "continuous_accepted_configuration_increment"
    expected["pressures"] = [.7125, .7, .6875]
    if continue_candidate is not None:
        expected["optimizer"]["stopping_policy"] = "physical_acceptance"
        if "continuation_solver" in config["optimizer"]:
            expected["optimizer"]["continuation_solver"] = config["optimizer"]["continuation_solver"]
        if config["optimizer"].get("continuation_head_polish", False):
            expected["optimizer"]["continuation_head_polish"] = True
        if config["optimizer"].get("virtual_work_excess", False):
            from mixed_residual import enable_virtual_work_excess
            enable_virtual_work_excess(expected)
    if (config != expected or metadata.get("status") != "complete" or not metadata.get("accepted")
            or metadata.get("method") != "W-GH" or not metadata.get("source_unchanged")
            or not metadata.get("inputs_unchanged") or len(metadata["records"]) != 1
            or metadata["records"][0]["pressure_ratio"] != .7125):
        raise ValueError("Need the completed section 8.12 field and unchanged physical/solver settings")
    digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    old_path = ROOT/metadata["restoration"]["start_checkpoint"]
    files = [directory/name for name in ("result.json", "config.json", "restoration.json", "configuration_context.pt",
        "accepted_conditional.pt", "candidate_fields.pt", "evaluation_geometry.pt")]+[old_path, ROOT/config["geometry"]]
    input_hashes = {str(path.relative_to(ROOT)).replace("\\", "/"): digest(path) for path in files}
    for name, key in (("configuration_context.pt", "configuration_context_sha256"),
                      ("candidate_fields.pt", "candidate_fields_sha256"), ("evaluation_geometry.pt", "evaluation_geometry_sha256")):
        if digest(directory/name) != metadata[key]:
            raise ValueError("Accepted continuation input checksum changed: "+name)
    if digest(old_path) != metadata["restoration"]["start_checkpoint_sha256"]:
        raise ValueError("Accepted .725 parent changed")
    source_changes = {}
    allowed = {"mixed_pinn.py", "mixed_history.py", "mixed_head_newton.py", "mixed_full_newton.py",
        "mixed_local_jacobian.py", "mixed_recovery.py", "run_mixed_feasibility.py", "assess_mixed_basis_mechanism.py",
        "mixed_residual.py", "mixed_dense_jacobian.py"}
    for name, recorded in metadata["source_sha256"].items():
        if digest(directory/"sources"/Path(name).name) != recorded:
            raise ValueError("Accepted source snapshot changed: "+name)
        if digest(ROOT/name) != recorded:
            if Path(name).name not in allowed:
                raise ValueError("Unplanned scientific source change: "+name)
            source_changes[name] = {"accepted_source": recorded, "current": digest(ROOT/name)}
    def load(path):
        return torch.load(path, map_location=f0.device, weights_only=True)
    checkpoint, old, saved_context = load(directory/"accepted_conditional.pt"), load(old_path), load(directory/"configuration_context.pt")
    if (not checkpoint["accepted"] or checkpoint["pressure"] != .7125*config["p0"]
            or old["pressure"] != .725*config["p0"] or checkpoint["configuration_context_sha256"] != metadata["configuration_context_sha256"]):
        raise ValueError("Accepted pressure or context binding differs")
    mesh = geometry_from_config(config, ROOT, f0)
    train = EvaluationPool("training", mesh, config["p0"])
    validation = EvaluationPool("validation", geometry_from_config(config, ROOT, f0, mesh=config["validation_mesh"]), config["p0"])
    pools = ((train, "train_history", "training_physics"), (validation, "validation_history", "validation"))
    material_id = content_identity({"material": config["material"], "f0": f0, "initial_stress": initial.sigma,
                                   "geometry_sha256": digest(ROOT/config["geometry"]), "p0": config["p0"]})
    legacy = MixedNet(config, f0, initial, mesh.radius, "W-GH")
    legacy.set_pressure(checkpoint["pressure"])
    context = FrozenConfiguration.restore(legacy, saved_context)
    if any(not torch.equal(value, context.old_model.state_dict()[key]) for key, value in old["network"].items()):
        raise ValueError("Legacy field and old checkpoint differ")
    legacy.set_displacement_context(context)
    legacy.load_state_dict(checkpoint["network"])
    field = AcceptedField.capture(legacy, checkpoint["pressure"])
    parent_field = AcceptedField(field.nodes[:-1], field.models[:-1])
    def report_difference(actual, expected):
        errors = []
        for key, value in expected.items():
            other = actual[key]
            if isinstance(value, dict):
                errors.append(report_difference(other, value))
            elif isinstance(value, (int, float)) and not isinstance(value, bool):
                errors.append(abs(other-value)/max(1., abs(value)))
            elif other != value:
                raise ValueError("Reloaded report discrete field differs: "+key)
        error = max(errors, default=0.)
        if error > 1e-10:
            raise ValueError("Reloaded physical report differs: "+str(error))
        return error
    def verify_field(current, payload, expected_reports):
        candidate_model = current.model({"old_state_step": payload["parent_train_history"]["step"]})
        errors = []
        for pool, key, label in pools:
            previous = payload["parent_"+key]
            pool.history.restore(previous, current.nodes[-1]["parent_field_id"], material_id)
            data = pool.evaluate(candidate_model, current.pressure, material, initial, graph=False)
            data["pressure"] = current.pressure
            errors.append(report_difference(checks(pool, data, candidate_model, config, initial), expected_reports[label]))
            errors.append(max(float((data["trial"].cp-payload[key]["cp"]).abs().max()),
                              float((data["trial"].kappa-payload[key]["kappa"]).abs().max())))
            if errors[-1] > 1e-10:
                raise ValueError("Reloaded field does not reproduce its accepted plastic history")
        for pool, key, _ in pools:
            pool.history.restore(payload[key], current.field_id, material_id)
        return max(errors), candidate_model
    torch.cuda.synchronize()
    import_begin = time.perf_counter()
    imported = dict(checkpoint, parent_train_history=old["train_history"], parent_validation_history=old["validation_history"])
    import_error, model = verify_field(field, imported, metadata["records"][0])
    for pool, key, _ in pools:
        if pool.history.state.step != 10:
            raise ValueError("Continuation must start at accepted step 10")
        old[key] = deepcopy(old[key])
    # Publish a complete import manifest without performing another material step.
    reference = field.save(out/"fields")
    imported.update(field_schema_version=2, field_reference=reference,
        train_history=train.history.checkpoint(), validation_history=validation.history.checkpoint())
    torch.save(imported, out/"accepted_010.pt")
    save_json(out/"accepted_path.json", [{"file": "accepted_010.pt", "sha256": digest(out/"accepted_010.pt"),
        "field_id": field.field_id, "pressure": field.pressure, "step": 10,
        "history_chain_ids": [pool.history.history_chain_id for pool in (train, validation)], "imported": True}])
    loaded_field = AcceptedField.load(model, out/"fields", reference)
    reload_error, model = verify_field(loaded_field, imported, metadata["records"][0])
    field = loaded_field
    torch.cuda.synchronize()
    import_seconds = time.perf_counter()-import_begin
    grid = load(directory/"evaluation_geometry.pt")
    if identity(grid["x_natural_m"], torch.arange(len(grid["x_natural_m"]), device=f0.device)) != metadata["sampling"]["material_point_identity_sha256"]:
        raise ValueError("Continuation evaluation point identity differs")
    fields = select_pinn_fields(load(directory/"candidate_fields.pt"))
    torch.save(to_host(grid), out/"evaluation_geometry.pt")
    save_json(out/"restoration.json", {"source_run": source, "imported_field_id": field.field_id,
        "old_state_step": 10, "input_sha256": input_hashes, "source_changes": source_changes,
        "legacy_endpoint_report_max_error": import_error, "disk_reload_report_max_error": reload_error,
        "import_wall_seconds": import_seconds, "material_identity": material_id,
        "scope": "Import accepted .7125 directly; no prefix replay or repeated conditional solve"})
    emit({"phase": "continuation_import_verified", "field_id": field.field_id, "step": 10,
          "report_max_error": max(import_error, reload_error), "import_wall_seconds": import_seconds})
    records, accepted = [], [.7125]
    resumed_candidate = None
    if continue_candidate is not None:
        resumed_directory = ROOT/"results/mixed_feasibility"/continue_candidate
        if resumed_directory.resolve().parent != directory.resolve().parent or resumed_directory.resolve() == out.resolve():
            raise ValueError("Candidate continuation requires a separate existing run")
        resumed_config = json.loads((resumed_directory/"config.json").read_text(encoding="utf-8"))
        objective_changed = ({k: v for k, v in resumed_config["optimizer"].items() if k.startswith("virtual_work_")}
                             != {k: v for k, v in config["optimizer"].items() if k.startswith("virtual_work_")})
        resumed_config["optimizer"]["stopping_policy"] = "physical_acceptance"
        if "continuation_solver" in config["optimizer"]:
            resumed_config["optimizer"]["continuation_solver"] = config["optimizer"]["continuation_solver"]
        if config["optimizer"].get("continuation_head_polish", False):
            resumed_config["optimizer"]["continuation_head_polish"] = True
        else:
            resumed_config["optimizer"].pop("continuation_head_polish", None)
        if config["optimizer"].get("virtual_work_excess", False):
            from mixed_residual import enable_virtual_work_excess
            enable_virtual_work_excess(resumed_config)
        if resumed_config != config:
            raise ValueError("Candidate continuation changed physical, information or objective settings")
        metadata_file = resumed_directory/"result.json"
        if not metadata_file.exists():
            metadata_file = resumed_directory/"interruption.json"
        resumed_metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
        if metadata_file.name == "interruption.json":
            if (resumed_metadata.get("status") != "interrupted_without_finalization"
                    or digest(resumed_directory/resumed_metadata["candidate_file"]) != resumed_metadata["candidate_sha256"]):
                raise ValueError("Incomplete run recovery candidate changed")
        resumed_manifest = json.loads((resumed_directory/"accepted_path.json").read_text(encoding="utf-8"))
        if (not resumed_manifest or resumed_manifest[0]["field_id"] != field.field_id
                or [row["pressure"]/config["p0"] for row in resumed_manifest] != [.7125, .7, .6875][:len(resumed_manifest)]):
            raise ValueError("Candidate source is not the prescribed accepted path")
        resumed_inputs = [metadata_file]+[resumed_directory/name for name in ("config.json", "accepted_path.json",
                          "accepted_fields.pt", "evaluation_geometry.pt", "restoration.json")]
        resumed_inputs += list((resumed_directory/"fields").glob("*.pt"))
        for row in resumed_manifest:
            accepted_file = resumed_directory/row["file"]
            if accepted_file.resolve().parent != resumed_directory.resolve() or digest(accepted_file) != row["sha256"]:
                raise ValueError("Candidate source accepted checkpoint changed")
            resumed_inputs.append(accepted_file)
            if row["step"] == 10:
                continue
            payload = load(accepted_file)
            current = AcceptedField.load(model, resumed_directory/"fields", payload["field_reference"])
            if current.nodes[-1]["parent_field_id"] != field.field_id or current.field_id != row["field_id"]:
                raise ValueError("Candidate accepted sequence skips or changes a parent")
            error, model = verify_field(current, payload, payload["physical_report"])
            field = current
            payload["field_reference"] = field.save(out/"fields")
            torch.save(payload, out/row["file"])
            output_manifest = json.loads((out/"accepted_path.json").read_text(encoding="utf-8"))
            output_manifest.append(dict(row, sha256=digest(out/row["file"]), imported=True))
            save_json(out/"accepted_path.json", output_manifest)
            accepted.append(current.pressure/config["p0"])
            emit({"phase": "continuation_accepted_import", "pressure_ratio": accepted[-1], "report_max_error": error})
        fields = select_pinn_fields(load(resumed_directory/"accepted_fields.pt"))
        if content_identity(load(resumed_directory/"evaluation_geometry.pt")) != content_identity(grid):
            raise ValueError("Candidate source field evaluation geometry differs")
        candidate_file = resumed_directory/f"candidate_{train.history.state.step+1:03d}.pt"
        if candidate_file.exists():
            resumed_candidate = load(candidate_file)
            loaded_parent = AcceptedField.load(model, resumed_directory/"fields", resumed_candidate["parent_field_reference"])
            if loaded_parent.field_id != field.field_id:
                raise ValueError("Saved candidate has another complete parent field")
            resumed_inputs.append(candidate_file)
            if objective_changed:
                resumed_candidate["optimizer_state"] = None
        for name, recorded in resumed_metadata["source_sha256"].items():
            snapshot_file = resumed_directory/"sources"/Path(name).name
            if digest(snapshot_file) != recorded:
                raise ValueError("Candidate source snapshot changed: "+name)
            if digest(ROOT/name) != recorded and Path(name).name not in allowed:
                raise ValueError("Candidate scientific source changed: "+name)
            resumed_inputs.append(snapshot_file)
        input_hashes.update({str(path.relative_to(ROOT)).replace("\\", "/"): digest(path) for path in resumed_inputs})
        restoration = json.loads((out/"restoration.json").read_text(encoding="utf-8"))
        restoration.update(candidate_source_run=continue_candidate, input_sha256=input_hashes,
            objective_extension_changed=objective_changed,
            optimizer_reset_reason="training_objective_changed" if objective_changed else None,
            candidate_has_optimizer_state=resumed_candidate is not None and resumed_candidate.get("optimizer_state") is not None,
            imported_pressure_ratios=accepted.copy(), scope="Continue own saved field/history to .6875 using original dual-pool acceptance")
        save_json(out/"restoration.json", restoration)
    torch.save(to_host(fields), out/"accepted_fields.pt")
    summary = summarize_continuation(fields, grid, config, material)
    for pressure_ratio in (.7, .6875):
        if pressure_ratio >= accepted[-1]:
            continue
        pressure = pressure_ratio*config["p0"]
        parents = {key: deepcopy(pool.history.checkpoint()) for pool, key, _ in pools}
        old_field, old_model = field, model
        old_step = train.history.state.step
        context = ContinuousConfiguration(field, pressure, {"old_state_step": old_step})
        torch.cuda.synchronize()
        cache_begin = time.perf_counter()
        for pool, _, _ in pools:
            context.prepare(pool.x)
        arc_ids = torch.arange(6, device=f0.device).repeat_interleave(128)
        fractions = torch.arange(128, device=f0.device, dtype=f0.dtype).repeat(6)/128
        context.prepare(mesh.wall.sample(arc_ids, fractions)[0])
        context.prepare(f0.new_tensor([[6.73, 0], [-6.73, 0], [0, 6.73], [0, -4.32]])/f0[0, 0])
        initial_model = field.new_model()
        initial_model.set_pressure(pressure)
        initial_model.set_displacement_context(context)
        predictor_errors = []
        for pool, _, _ in pools:
            cache = context.prepare(pool.x)
            u, f, _, _ = initial_model.deformation(pool.x, graph=False)
            predictor_errors.append(max(float((u-cache["predictor_u"]).abs().max()), float((f-cache["predictor_f"]).abs().max())))
        if max(predictor_errors) > 1e-10:
            raise ValueError("Full-field continuation predictor changed at zero correction")
        torch.cuda.synchronize()
        cache_seconds = time.perf_counter()-cache_begin
        context_ref = field.save(out/"fields")
        candidate_path = out/f"candidate_{old_step+1:03d}.pt"
        def save_candidate(report, optimizer_state=None):
            temp = candidate_path.with_suffix(".tmp.pt")
            torch.save({"network": model.state_dict(), "accepted": False, "pressure": pressure,
                "field_schema_version": 2, "parent_field_reference": context_ref,
                "context_source": context.source, "parent_train_history": parents["train_history"],
                "parent_validation_history": parents["validation_history"], "physical_report": report,
                "optimizer_state": optimizer_state}, temp)
            temp.replace(candidate_path)
        emit({"phase": "continuation_start_pressure", "pressure_ratio": pressure_ratio,
            "parent_field_id": field.field_id, "old_step": old_step, "chain_nodes": len(field.nodes),
            "predictor_max_error": max(predictor_errors), "configuration_cache_wall_seconds": cache_seconds})
        published = False
        try:
            if resumed_candidate is not None:
                from mixed_recovery import install_configuration_candidate
                probe = field.new_model()
                probe.set_pressure(pressure)
                probe.set_displacement_context(context)
                install_configuration_candidate(resumed_candidate, probe, train, validation, pressure)
                errors = []
                for pool, _, label in pools:
                    data = pool.evaluate(probe, pressure, material, initial, graph=False)
                    data["pressure"] = pressure
                    errors.append(report_difference(checks(pool, data, probe, config, initial),
                                                    resumed_candidate["physical_report"][label]))
                emit({"phase": "candidate_reload_verified", "report_max_error": max(errors),
                      "pressure_ratio": pressure_ratio,
                      "optimizer_state_available": resumed_candidate.get("optimizer_state") is not None,
                      "optimizer_state_selected_for_resume": (resumed_candidate.get("optimizer_state") is not None
                          and resumed_candidate["optimizer_state"]["phase"] == config["optimizer"].get("continuation_solver", "lbfgs"))})
                del probe, data
            torch.cuda.synchronize()
            train_begin = time.perf_counter()
            metrics = train_step(model, train, validation, pressure, material, initial, config, emit,
                candidate_callback=save_candidate, displacement_context=context, candidate_resume=resumed_candidate)
            resumed_candidate = None
            torch.cuda.synchronize()
            metrics.update(wall_seconds=time.perf_counter()-train_begin, configuration_cache_wall_seconds=cache_seconds,
                           predictor_max_error=max(predictor_errors), parent_field_id=field.field_id)
            records.append(metrics)
            save_json(out/"path.json", records)
            if metrics["accepted"]:
                save_begin = time.perf_counter()
                field = field.append(model, pressure)
                payload = publish_accepted_field(out, field, train, validation, parents, material_id, metrics)
                published = True
                accepted.append(pressure_ratio)
                metrics["acceptance_save_wall_seconds"] = time.perf_counter()-save_begin
                reload_begin = time.perf_counter()
                payload = load(out/f"accepted_{old_step+1:03d}.pt")
                field = AcceptedField.load(model, out/"fields", payload["field_reference"])
                error, model = verify_field(field, payload, metrics)
                torch.cuda.synchronize()
                metrics.update(reload_report_max_error=error, reload_wall_seconds=time.perf_counter()-reload_begin,
                               field_id=field.field_id, chain_nodes=len(field.nodes))
                evaluation_model = model
            else:
                saved = load(candidate_path)
                evaluation_model = old_field.new_model()
                evaluation_model.set_pressure(pressure)
                evaluation_model.set_displacement_context(context)
                evaluation_model.load_state_dict(saved["network"])
                if AcceptedField.capture(model, old_field.pressure).field_id != old_field.field_id:
                    raise ValueError("Rejected continuation did not restore the full accepted field")
                metrics["rejected_field_rollback_verified"] = True
            eval_begin = time.perf_counter()
            endpoint = evaluate_conditional_endpoint(evaluation_model, fields[accepted[-2] if published else accepted[-1]],
                                                      grid, material, pressure_ratio, old_step)
            if metrics["accepted"]:
                fields[pressure_ratio] = select_pinn_fields({pressure_ratio: endpoint})[pressure_ratio]
            else:
                torch.save(to_host({pressure_ratio: endpoint}), out/f"rejected_fields_{old_step+1:03d}.pt")
                candidate_fields = dict(fields)
                candidate_fields[pressure_ratio] = endpoint
                save_json(out/"rejected_field_summary.json", summarize_continuation(candidate_fields, grid, config, material))
            torch.save(to_host(fields), out/"accepted_fields.pt")
            summary = summarize_continuation(fields, grid, config, material)
            save_json(out/"field_summary.json", summary)
            torch.cuda.synchronize()
            metrics["field_evaluation_wall_seconds"] = time.perf_counter()-eval_begin
            metrics["field_dependency_bytes"] = sum(p.stat().st_size for p in (out/"fields").glob("*.pt"))
            metrics["active_cache_bytes"] = sum(t.numel()*t.element_size() for c in context.caches for t in c.values())
            save_json(out/"path.json", records)
            emit({"phase": "continuation_step_finished", **metrics})
            context.caches.clear()
            if not metrics["accepted"]:
                break
        except Exception:
            if not published:
                field, model = old_field, old_field.model()
                for pool, key, _ in pools:
                    pool.history.restore(parents[key], field.field_id, material_id)
            save_json(out/"continuation_failure.json", {"pressure_ratio": pressure_ratio,
                "last_published_pressure_ratio": accepted[-1], "accepted_before_failure": published,
                "traceback": traceback.format_exc(), "next_pressure_started": False})
            raise
    if not all(digest(ROOT/name) == value for name, value in input_hashes.items()):
        raise ValueError("Continuation input changed")
    return {"mode": "configuration_continuation", "method": "W-GH", "status": "complete",
        "accepted": accepted[-1] == .6875, "accepted_pressures": accepted, "records": records,
        "requested_endpoint": .6875, "source_run": source, "inputs_unchanged": True,
        "sampling": metadata["sampling"], "field_summary": summary,
        "parameters": sum(p.numel() for p in model.parameters()), "training_points": len(train.x), "validation_points": len(validation.x),
        "candidate_source_run": continue_candidate,
        "scope": ("Two prescribed increments through original physical acceptance; no optimizer iteration cutoff"
                  if continue_candidate is not None else "At most two new increments; first rejection stops; no bisection or other path")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["reference", "pinn", "check", "increment", "continue-configuration"])
    parser.add_argument("--config", default="config/mixed_horseshoe_feasibility.json")
    parser.add_argument("--tag", required=True)
    parser.add_argument("--method", choices=["W-GH", "W-LH", "W-RH"], default="W-GH")
    parser.add_argument("--resume-run")
    parser.add_argument("--recover-interrupted", action="store_true")
    parser.add_argument("--resume-through", type=float, help="Replay only through this accepted source pressure ratio")
    parser.add_argument("--angular", type=int)
    parser.add_argument("--radial", type=int)
    parser.add_argument("--quadrature", type=int)
    parser.add_argument("--degree", type=int, choices=[1, 2])
    parser.add_argument("--outer", type=float)
    parser.add_argument("--pressures", nargs="+", type=float)
    parser.add_argument("--max-pressure-step", type=float)
    parser.add_argument("--linear-solver", choices=["dense", "bicgstab"])
    parser.add_argument("--source-run", help="Accepted GH source for the conditional .725 -> .7125 increment")
    parser.add_argument("--mechanism-run", help="Saved common-point mechanism archive; evaluation only")
    from mixed_residual import WEAK_COUPLINGS
    parser.add_argument("--weak-coupling", choices=WEAK_COUPLINGS)
    parser.add_argument("--stress-lifting", action="store_true",
                         help="One conditional increment with anchored return-stress lifting and the original objective")
    parser.add_argument("--configuration-displacement", action="store_true",
                        help="One conditional displacement increment in the accepted configuration")
    parser.add_argument("--baseline-run", help="Completed material-equilibrium PINN increment; comparison only")
    parser.add_argument("--continue-candidate-run", help="Continue an existing complete-configuration field and its own accepted history")
    parser.add_argument("--continuation-solver", choices=["lbfgs", "full_newton"],
                        help="Optimizer for the same saved physical problem; neither uses an iteration cutoff")
    parser.add_argument("--continuation-head-polish", action="store_true",
                        help="One existing joint head Newton correction before continuing L-BFGS")
    parser.add_argument("--virtual-work-excess", action="store_true", help="Add train-only work excess control at the existing margin")
    args = parser.parse_args()
    if args.continue_candidate_run and args.mode != "continue-configuration":
        parser.error("--continue-candidate-run requires continue-configuration")
    if args.continuation_solver is not None and not args.continue_candidate_run:
        parser.error("--continuation-solver requires --continue-candidate-run")
    if args.continuation_head_polish and (not args.continue_candidate_run or args.continuation_solver == "full_newton"):
        parser.error("--continuation-head-polish requires candidate continuation with L-BFGS")
    if args.virtual_work_excess and not args.continue_candidate_run:
        parser.error("--virtual-work-excess requires --continue-candidate-run")
    if args.mode == "continue-configuration":
        if (not args.source_run or args.method != "W-GH" or args.weak_coupling != "material_equilibrium"
                or args.configuration_displacement or args.stress_lifting or args.baseline_run or args.mechanism_run
                or args.resume_run or args.recover_interrupted or any(getattr(args, key) is not None for key in (
                    "resume_through", "angular", "radial", "quadrature", "degree", "outer", "pressures", "max_pressure_step", "linear_solver"))):
            parser.error("continue-configuration requires only the accepted source, W-GH and material_equilibrium")
    elif args.mode == "increment":
        if args.configuration_displacement and (args.stress_lifting or not args.baseline_run):
            parser.error("Configuration displacement requires a baseline run and independent stress")
        if args.baseline_run and not args.configuration_displacement:
            parser.error("--baseline-run requires --configuration-displacement")
        coupling_ok = (args.weak_coupling in (None, "constitutive_difference") if args.stress_lifting
                       else args.weak_coupling == "material_equilibrium")
        if (not args.source_run or not args.mechanism_run or args.method != "W-GH"
                or not coupling_ok or args.resume_run or args.recover_interrupted
                or any(getattr(args, key) is not None for key in ("resume_through", "angular", "radial",
                    "quadrature", "degree", "outer", "pressures", "max_pressure_step", "linear_solver"))):
            parser.error("increment requires source/mechanism runs and W-GH; choose material_equilibrium or stress lifting alone")
    elif args.source_run or args.mechanism_run or args.stress_lifting or args.configuration_displacement or args.baseline_run:
        parser.error("Conditional source, mechanism and lifting options require increment mode")
    if args.resume_through is not None and args.resume_run is None:
        parser.error("--resume-through requires --resume-run")
    if args.recover_interrupted and (args.resume_run is None or args.resume_through is not None or args.mode != "pinn"):
        parser.error("Interrupted recovery requires a complete --resume-run prefix in pinn mode")
    config = json.loads((ROOT/args.config).read_text(encoding="utf-8"))
    if args.configuration_displacement:
        config["displacement_representation"] = "accepted_configuration_increment"
    if args.mode == "continue-configuration":
        config["displacement_representation"] = "continuous_accepted_configuration_increment"
        config["pressures"] = [.7125, .7, .6875]
        if args.continue_candidate_run is not None:
            config["optimizer"]["stopping_policy"] = "physical_acceptance"
            if args.continuation_solver is not None:
                config["optimizer"]["continuation_solver"] = args.continuation_solver
            if args.continuation_head_polish:
                config["optimizer"]["continuation_head_polish"] = True
    if config.get("displacement_representation") is not None and not args.configuration_displacement and args.mode != "continue-configuration":
        parser.error("Configuration displacement requires its explicit conditional entry")
    if args.stress_lifting:
        config["stress_representation"] = "anchored_return_increment"
    if config.get("stress_representation") is not None and args.mode != "increment":
        parser.error("Anchored stress representation currently requires the conditional increment entry")
    if args.weak_coupling is not None:
        config["optimizer"]["weak_coupling"] = args.weak_coupling
    if args.virtual_work_excess:
        from mixed_residual import enable_virtual_work_excess
        enable_virtual_work_excess(config)
    if args.linear_solver is not None:
        config["reference"]["linear_solver"] = args.linear_solver
    if args.pressures is not None:
        config["pressures"] = args.pressures
    if args.max_pressure_step is not None:
        refined = [config["pressures"][0]]
        for left, right in zip(config["pressures"][:-1], config["pressures"][1:]):
            count = max(1, math.ceil((abs(right-left)-1e-12)/args.max_pressure_step))
            refined.extend(round(left+(right-left)*i/count, 12) for i in range(1, count+1))
        config["pressures"] = refined
    for key in ("angular", "radial", "quadrature", "degree"):
        if getattr(args, key) is not None:
            config["reference_mesh"][key] = getattr(args, key)
    if args.outer is not None:
        config["outer_widths"] = args.outer
    if not config["device"].startswith("cuda:") or not torch.cuda.is_available():
        raise RuntimeError("CUDA required; no CPU fallback")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.use_deterministic_algorithms(config.get("deterministic_algorithms", False))
    torch.cuda.set_device(config["device"])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.manual_seed(config["seed"])
    out = ROOT/"results/mixed_feasibility"/args.tag
    if out.resolve().parent != (ROOT/"results/mixed_feasibility").resolve():
        raise ValueError("Tag must be one directory name")
    out.mkdir(parents=True, exist_ok=False)
    save_json(out/"config.json", config)
    sources = ["code/dp_material.py", "code/current_traction.py", "code/horseshoe_geometry.py",
               "code/mixed_geometry.py", "code/dp_reference.py", "code/mixed_reference.py",
               "code/mixed_history.py", "code/mixed_pinn.py", "code/run_mixed_feasibility.py",
               "code/mixed_reference_sampling.py", "code/compare_mixed_feasibility.py",
               "code/mixed_head_newton.py", "code/assess_mixed_pinn.py", "tests/test_mixed_head_newton.py",
               "code/mixed_q2.py", "code/mixed_krylov.py", "code/check_reference_energy.py",
               "code/mixed_residual.py", "code/mixed_full_newton.py",
               "code/mixed_dense_jacobian.py",
               "code/mixed_local_jacobian.py",
               "tests/test_mixed_feasibility.py", config["geometry"]]
    sources.append("tests/test_mixed_determinism.py")
    sources.append("code/mixed_recovery.py")
    if args.mode in ("increment", "continue-configuration"):
        sources.append("code/assess_mixed_basis_mechanism.py")
    hashes = {}
    (out/"sources").mkdir()
    for name in sources:
        source = ROOT/name
        if source.exists():
            data = source.read_bytes()
            hashes[name] = hashlib.sha256(data).hexdigest()
            (out/"sources"/source.name).write_bytes(data)
    f0, _, initial = dp.elastic_precompression(dp.DPParameters.from_young_poisson(**config["material"]),
                        torch.tensor(config["p0"], device=config["device"], dtype=torch.float64))
    material = dp.DPParameters.from_young_poisson(**config["material"])
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    wall, cpu = time.perf_counter(), time.process_time()
    before = snapshot()
    begin.record()
    events = open(out/"events.jsonl", "a", encoding="utf-8", buffering=1)
    def emit(data):
        item = {"elapsed_wall_seconds": time.perf_counter()-wall, "elapsed_process_cpu_seconds": time.process_time()-cpu,
                "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                "peak_reserved_bytes": torch.cuda.max_memory_reserved(), **data}
        line = json.dumps(item, allow_nan=False)
        print(line, flush=True)
        events.write(line+"\n")
        if data.get("phase") != "finished" and "error" not in data and (out/"stop.request").exists():
            raise RuntimeError("Cooperative stop requested for this run")
    emit({"phase": "initialized", "device": str(f0.device), "dtype": str(f0.dtype),
          "threads": [torch.get_num_threads(), torch.get_num_interop_threads()], "gpu_before": before})
    code, result = 0, {}
    try:
        if args.mode == "reference":
            result = run_reference(config, f0, material, out, emit)
        elif args.mode == "continue-configuration":
            result = run_configuration_continuation(config, f0, initial, material, out, emit, args.source_run, args.continue_candidate_run)
        elif args.mode == "pinn":
            result = run_pinn(config, f0, initial, material, out, emit, args.method, args.resume_run,
                              args.resume_through, args.recover_interrupted)
        elif args.mode == "increment":
            if args.configuration_displacement:
                result = run_configuration_increment(config, f0, initial, material, out, emit,
                    args.source_run, args.mechanism_run, args.baseline_run)
            else:
                result = run_conditional_increment(config, f0, initial, material, out, emit,
                    args.source_run, args.mechanism_run)
        else:
            sys.path.insert(0, str(ROOT/"tests"))
            from test_mixed_feasibility import run_checks
            result = run_checks(config, f0, initial, material, emit)
            from test_mixed_head_newton import run_head_checks
            result["head_checks"] = run_head_checks(config, f0, initial, material, emit)
            from test_mixed_determinism import run_determinism_check
            result["determinism_check"] = run_determinism_check(config, f0, initial, material, emit)
    except Exception as error:
        code = 1
        result = {"error": str(error), "traceback": traceback.format_exc()}
        emit(result)
    finally:
        end.record()
        torch.cuda.synchronize()
        result.setdefault("mode", args.mode)
        if args.mode in ("pinn", "increment", "continue-configuration"):
            result.setdefault("method", args.method)
        if "records" not in result and (out/"path.json").exists():
            result["records"] = json.loads((out/"path.json").read_text(encoding="utf-8"))
        result["resources"] = {"wall_seconds": time.perf_counter()-wall, "process_cpu_seconds": time.process_time()-cpu,
            "cuda_event_span_seconds_including_host_gaps": begin.elapsed_time(end)/1000,
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
            "process_wall_including_imports": time.perf_counter()-PROCESS_WALL,
            "process_cpu_including_imports": time.process_time()-PROCESS_CPU,
            "gpu_before": before, "gpu_after": snapshot(), "pid": os.getpid(),
            "torch": torch.__version__, "cuda_build": torch.version.cuda, "python": sys.version,
            "device": str(f0.device), "dtype": str(f0.dtype), "tensor_threads": torch.get_num_threads(),
            "interop_threads": torch.get_num_interop_threads(),
            "cpu_library_threads": {key: os.environ[key] for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS",
                "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")}}
        result["resources"]["deterministic_algorithms"] = torch.are_deterministic_algorithms_enabled()
        result["resources"]["cublas_workspace_config"] = os.environ["CUBLAS_WORKSPACE_CONFIG"]
        result["source_sha256"] = hashes
        result["source_unchanged"] = all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest() == h for p, h in hashes.items())
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        save_json(out/"result.json", result)
        emit({"phase": "finished", "exit_code": code, "resources": result["resources"]})
        events.close()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
