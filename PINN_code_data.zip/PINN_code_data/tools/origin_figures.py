"""Matplotlib style used by the distributed manuscript figure functions."""
import json
import math
from pathlib import Path
import matplotlib as mpl
from matplotlib import font_manager
from cycler import cycler
STYLE = json.loads(Path(__file__).with_name("figure_style.json").read_text(encoding="utf-8"))
BLACK, RED, BLUE = STYLE["colors"]
def apply_style() -> None:
    """Install the sole default; a missing Times font is an actionable error."""
    try:
        font_manager.findfont(STYLE["font_family"], fallback_to_default=False)
    except ValueError as exc:
        raise RuntimeError("Times New Roman is required; install the font before rendering.") from exc
    mpl.rcParams.update(STYLE["rc"])
    mpl.rcParams["axes.prop_cycle"] = (
        cycler(color=STYLE["colors"])
        + cycler(linestyle=STYLE["linestyles"][:3])
    )

def figure(width_mm: float, height_mm: float, **kwargs):
    """Create a white canvas in millimetres; add content-specific axes yourself."""
    from matplotlib import pyplot as plt
    if not all(math.isfinite(v) and v > 0 for v in (width_mm, height_mm)):
        raise ValueError("Figure dimensions must be positive.")
    apply_style()
    return plt.figure(figsize=(width_mm / 25.4, height_mm / 25.4), **kwargs)

def style_axes(ax, *, minor: bool = True, categorical: str = ""):
    """Box numeric axes; preserve log locators and omit categorical minor ticks.

    Photographs and schematics normally use ax.set_axis_off() instead. Fields
    keep physical coordinates, aspect, scientific colormap and a labelled bar.
    """
    from matplotlib.ticker import AutoMinorLocator, NullLocator
    for spine in ax.spines.values():
        spine.set(visible=True, linewidth=STYLE["rc"]["axes.linewidth"], edgecolor=BLACK)
    ax.set_facecolor("white")
    ax.grid(False, which="both")
    ax.tick_params(which="major", direction="in", top=True, right=True,
                   length=STYLE["rc"]["xtick.major.size"],
                   width=STYLE["rc"]["xtick.major.width"], colors=BLACK, pad=3)
    ax.tick_params(which="minor", direction="in", top=True, right=True,
                   length=STYLE["rc"]["xtick.minor.size"],
                   width=STYLE["rc"]["xtick.minor.width"], colors=BLACK)
    for name, axis in (("x", ax.xaxis), ("y", ax.yaxis)):
        if not minor or name in categorical:
            axis.set_minor_locator(NullLocator())
        elif axis.get_scale() == "linear":
            axis.set_minor_locator(AutoMinorLocator(2))
    return ax
