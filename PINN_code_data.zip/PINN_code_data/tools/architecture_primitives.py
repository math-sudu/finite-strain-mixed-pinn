"""Editable vector primitives for the PINN architecture diagram."""
from __future__ import annotations

import argparse
import math
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, PathPatch, Rectangle
from matplotlib.path import Path as MplPath

SIZE_MM = (196, 144)
INK = "#353535"
GRID = "#676267"
GREEN = "#85b94b"
YELLOW = "#fff033"
CREAM = "#fbf4df"
CYAN = "#97cde1"
PURPLE = "#b8a2cc"
ORANGE = "#f2a132"
RED = "#c2766b"


def label(ax, xy, text, *, gid, size=8, align="center", **kwargs):
    """Keep labels as editable SVG text, with stable semantic group IDs."""
    artist = ax.text(*xy, text, ha=align, va="center", fontsize=size,
                     color=INK, linespacing=1.18, zorder=8, **kwargs)
    artist.set_gid(gid)
    return artist


def rounded_path(points, radius=1.1):
    """Round a routed polyline's corners without changing its endpoints."""
    vertices = [points[0]]
    codes = [MplPath.MOVETO]
    for before, corner, after in zip(points, points[1:], points[2:]):
        incoming = (corner[0] - before[0], corner[1] - before[1])
        outgoing = (after[0] - corner[0], after[1] - corner[1])
        a, b = math.hypot(*incoming), math.hypot(*outgoing)
        if not a or not b:
            raise ValueError("Consecutive route points must be distinct.")
        r = min(radius, a / 2, b / 2)
        entry = tuple(corner[i] - r * incoming[i] / a for i in (0, 1))
        leave = tuple(corner[i] + r * outgoing[i] / b for i in (0, 1))
        vertices.extend((entry, corner, leave))
        codes.extend((MplPath.LINETO, MplPath.CURVE3, MplPath.CURVE3))
    vertices.append(points[-1])
    codes.append(MplPath.LINETO)
    return MplPath(vertices, codes)


def arrow(ax, points, *, gid, color=INK, width=.75, head=6,
          dashed=False, tip=True, zorder=2):
    """Route an arrow through explicit anchors; text has separate clear space."""
    artist = FancyArrowPatch(path=rounded_path(points),
                             arrowstyle="-|>" if tip else "-",
                             mutation_scale=head, linewidth=width,
                             color=color, linestyle=(0, (3, 2)) if dashed else "-",
                             zorder=zorder)
    artist.set_gid(gid)
    ax.add_patch(artist)
    return artist


def grid(ax, xy, size, shape, color, *, gid, accents=(), zorder=4):
    """Draw an editable tensor plane. Cells indicate structure, not values.

    accents contains (column, row, column_span, row_span, color), from the
    plane's lower-left corner. Grid strokes stay lighter than flow arrows.
    """
    x, y = xy
    w, h = size
    cols, rows = shape
    dx, dy = w / cols, h / rows
    background = Rectangle(xy, w, h, facecolor=color, edgecolor=GRID,
                           linewidth=.38, zorder=zorder)
    background.set_gid(gid + "-plane")
    ax.add_patch(background)
    for index, (col, row, nx, ny, fill) in enumerate(accents):
        patch = Rectangle((x + col * dx, y + row * dy), nx * dx, ny * dy,
                          facecolor=fill, edgecolor="none", zorder=zorder + .1)
        patch.set_gid(f"{gid}-region-{index}")
        ax.add_patch(patch)
    for col in range(1, cols):
        line, = ax.plot([x + col * dx] * 2, [y, y + h], color=GRID,
                        linewidth=.24, linestyle="-", zorder=zorder + .2)
        line.set_gid(f"{gid}-column-{col}")
    for row in range(1, rows):
        line, = ax.plot([x, x + w], [y + row * dy] * 2, color=GRID,
                        linewidth=.24, linestyle="-", zorder=zorder + .2)
        line.set_gid(f"{gid}-row-{row}")


def stack(ax, xy, size, shape, colors, *, gid, offset=(1.2, -1.2),
          accents=None):
    """Layer tensor planes back to front; return the total bounding rectangle."""
    x, y = xy
    for i, color in enumerate(colors):
        grid(ax, (x + i * offset[0], y + i * offset[1]), size, shape, color,
             gid=f"{gid}-layer-{i}", zorder=4 + i * .4,
             accents=(accents or {}).get(i, ()))
    last_x, last_y = (x + (len(colors) - 1) * offset[0],
                      y + (len(colors) - 1) * offset[1])
    return (min(x, last_x), min(y, last_y),
            max(x, last_x) + size[0], max(y, last_y) + size[1])


def brace(ax, x, bottom, top, *, gid, opening="right", depth=1.6):
    """Draw a vector brace for a collection of outputs or loss branches."""
    sign = 1 if opening == "right" else -1
    mid = (bottom + top) / 2
    outer = x + sign * depth
    vertices = [(outer, top), (x, top), (x, top - 1.5), (x, mid + 1.5),
                (x, mid), (x - sign * depth, mid), (x, mid),
                (x, mid - 1.5), (x, bottom + 1.5), (x, bottom), (outer, bottom)]
    codes = [MplPath.MOVETO, MplPath.CURVE3, MplPath.CURVE3, MplPath.LINETO,
             MplPath.CURVE3, MplPath.CURVE3, MplPath.CURVE3, MplPath.CURVE3,
             MplPath.LINETO, MplPath.CURVE3, MplPath.CURVE3]
    artist = PathPatch(MplPath(vertices, codes), fill=False, edgecolor=INK,
                       linewidth=.75, zorder=3)
    artist.set_gid(gid)
    ax.add_patch(artist)


def network(ax, layers, *, gid, radius=2.85):
    """Draw dense connections behind layered nodes; layers hold (x, ys, labels).

    For another architecture, replace this topology explicitly (e.g. residual
    edges, attention blocks or branches) instead of retaining dense edges.
    """
    for layer_i, (left, right) in enumerate(zip(layers, layers[1:])):
        for i, y1 in enumerate(left[1]):
            for j, y2 in enumerate(right[1]):
                x1, x2 = left[0], right[0]
                distance = math.hypot(x2 - x1, y2 - y1)
                ux, uy = (x2 - x1) / distance, (y2 - y1) / distance
                arrow(ax, [(x1 + radius * ux, y1 + radius * uy),
                           (x2 - radius * ux, y2 - radius * uy)],
                      gid=f"{gid}-edge-{layer_i}-{i}-{j}",
                      color="#999999", width=.32, head=3.4, zorder=1)
    for i, (x, ys, labels) in enumerate(layers):
        for j, y in enumerate(ys):
            node = Circle((x, y), radius, facecolor=YELLOW if labels else GREEN,
                          edgecolor="none", zorder=5)
            node.set_gid(f"{gid}-node-{i}-{j}")
            ax.add_patch(node)
            if labels:
                label(ax, (x, y), labels[j], size=10,
                      gid=f"{gid}-label-{i}-{j}")

