"""Check compact release files and trained parameter identities, without inference."""
import hashlib
import json
from pathlib import Path
import sys
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'code'))
from mixed_history import content_identity


def main():
    torch.set_num_threads(1)
    release = json.loads((ROOT / 'release.json').read_text(encoding='utf-8'))
    for name, expected in release['sha256'].items():
        with (ROOT / name).open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected, name
    path = torch.load(ROOT / 'data/model_path.pt', map_location='cpu', weights_only=True)
    pressures = []
    for item in path['prefix']:
        assert content_identity(item['network']) == item['network_identity']
        pressures.append(item['pressure'])
    nodes, reference = [], path['complete_field']
    while reference:
        file = ROOT / 'data/fields' / reference['file']
        assert file.parent == ROOT / 'data/fields'
        assert hashlib.sha256(file.read_bytes()).hexdigest() == reference['sha256']
        saved = torch.load(file, map_location='cpu', weights_only=True)
        node = saved['node']
        assert content_identity({k: v for k, v in node.items() if k != 'field_id'}) == reference['field_id']
        nodes.append(node)
        reference = saved['parent']
        assert node['parent_field_id'] == (reference['field_id'] if reference else None)
    pressures += [node['pressure'] for node in reversed(nodes)]
    assert pressures == [1., .98, .95, .9, .85, .8, .75, .7375, .725, .7125, .7, .6875, .675]
    print(f"Verified {len(release['sha256'])} files and all thirteen trained states; no inference or training.")


if __name__ == '__main__':
    main()
