"""Regenerate reporting fields and figures from the retained trained path."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[name] = '1'
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'figures/pinn_mechanism_endpoints_01'
sys.path.insert(0, str(ROOT / 'code'))
import dp_material as dp
from mixed_pinn import AcceptedField, MixedNet
from field_export import collar_points, evaluate_conditional_endpoint
from reporting import export_reports
from expanded import export_expanded


def load_models(device):
    config = json.loads((ROOT / 'data/config.json').read_text(encoding='utf-8'))
    path = torch.load(ROOT / 'data/model_path.pt', map_location=device, weights_only=True)
    f0 = path['prefix'][0]['network']['f0']
    initial = SimpleNamespace(sigma=path['prefix'][0]['network']['initial_stress'])
    template = MixedNet(config, f0, initial, config['outer_widths'] * 13.46 / float(f0[0, 0]), 'W-GH')
    field = AcceptedField.load(template, ROOT / 'data/fields', path['complete_field'])
    prefix = []
    for item in path['prefix']:
        model = MixedNet(config, f0, initial, template.radius, 'W-GH')
        model.load_state_dict(item['network'])
        prefix.append(AcceptedField.root(model, item['pressure']))
    chain = [AcceptedField(field.nodes[:i], field.models[:i]) for i in range(1, 6)]
    return config, f0, prefix + chain


def check_table():
    import csv
    expected = json.loads((ROOT / 'data/expected_budgets.json').read_text(encoding='utf-8'))
    with (OUT / 'table1.csv').open(encoding='utf-8', newline='') as stream:
        actual = list(csv.DictReader(stream))
    for reference, row in zip(expected, actual, strict=True):
        assert reference['region'] == row['region']
        for key, value in reference.items():
            if key != 'region':
                np.testing.assert_allclose(float(row[key]), value, rtol=1e-8, atol=1e-11,
                                           err_msg=f"{row['region']}: {key}")
    print(f'Original-budget checks passed: {len(expected)} endpoint/region records', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', choices=['cpu', 'cuda:0'], default='cpu')
    parser.add_argument('--data-only', action='store_true', help='Generate arrays/CSV without rendering figures')
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float64)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    config, f0, history = load_models(args.device)
    material = dp.DPParameters.from_young_poisson(**config['material'])
    _, grid, _ = collar_points(config, f0, [48, 8, 48, 24, 48, 8], 24, 4)
    state = dp.MaterialState.virgin((len(grid['x_natural_m']),), device=args.device)
    previous = {'cp': state.cp, 'kappa': state.kappa, 'pressure_ratio': 1.0}
    fields = {}
    for index, field in enumerate(history):
        current = evaluate_conditional_endpoint(field.model(), previous, grid, material, field.pressure, index)
        if index >= 8:
            fields[field.pressure] = current
        previous = current
        print(f'Reconstructed accepted state {index + 1}/13, pressure={field.pressure}', flush=True)
    full_fields = {field.pressure: field for field in history[-4:]}
    OUT.mkdir(parents=True, exist_ok=True)
    export_reports(config, grid, fields, full_fields, f0)
    check_table()
    with np.load(OUT / 'plot_data.npz', allow_pickle=False) as archive:
        band = dict(archive)
    export_expanded(band, history[:9], history[-1], config, f0, material)
    print('Reporting arrays and CSV regenerated from trained weights; no optimization was run.', flush=True)
    if not args.data_only:
        subprocess.run([sys.executable, '-B', str(OUT / 'render.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
