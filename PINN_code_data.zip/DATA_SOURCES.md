# Measurement and geometry sources

The CSV files contain laboratory and field measurements supplied for
this study. This package selects the columns needed for the reported calculations
without changing their values. The descriptions below identify the measured
quantities, units and scientific uses.

| Files | Source and scientific role |
|---|---|
| `data/laboratory/phyllite_creep_strain_vs_time_cp15.csv`, `data/laboratory/phyllite_creep_strain_vs_time_cp20.csv`, `data/laboratory/phyllite_creep_strain_vs_time_cp25.csv` | Saturated-phyllite triaxial creep tests conducted for this study at 15, 20 and 25 MPa confinement provide the material inputs for the horseshoe comparison. `series` gives nominal additional axial load in MPa, `time_h` is time in hours, and `axial_strain_1e-2` is axial strain in percent. Levels two and three at 15 and 25 MPa calibrate the pressure-dependent law at r=0.10. The 20 MPa records were examined during development and supply a retrospective material comparison. |
| `data/stress/principal_stress_vs_depth_yaan_luding.csv` | Regional measurements of maximum-horizontal, minimum-horizontal and vertical stress against depth; depth in m and stress in MPa. |
| `data/field/x4dk0p860_surrounding_rock_pressure_timehistory.csv` and `x4dk0p860_cumulative_deformation_timehistory.csv` | Contact-pressure, settlement and closure measurements at section +860 of a tunnel in southwestern China. Contact pressure supplies the boundary input. The 55 settlement and closure readings through day 14.5277778 calibrate six effective physical parameters. The continuing neural history is evaluated against 43 later readings in the common interval; the data retain all 99 source readings. |
| `data/material/carbonaceous_slate.json` | Compression loading tests on individual carbonaceous-slate specimens. Intact specimens 9, 17, 42 and 47 give loading moduli of 114.12, 143.01, 214.22 and 182.01 MPa. Broken specimen 25 has 16.66 MPa compaction and 114.76 MPa subsequent loading slopes; badly broken specimen 31 gives 4.91 MPa. Soft intact specimen 1 gives 345.32 MPa, used as a nominal directional scale, with an effective base modulus below it. The individual tests constrain the material family; the displacement calibration determines its effective base modulus. |
| `data/field/x4dk0933_surrounding_rock_pressure_timehistory.csv` | Contact-pressure measurements at section +933 constrain the interpretation of spatially variable contact pressure. |
| `data/stress/field_principal_stress_vs_depth.csv` | Local maximum-principal-stress measurements in MPa against depth in m provide a stress-scale comparison. |
| `data/field/dk0p900_cumulative_deformation_vs_time.csv` | Settlement and closure measurements at section +900. The `series` column distinguishes settlement and the three closures, `days_d` gives time in days, and `cumulative_deformation_mm` gives displacement in mm. This separate section informs construction-prehistory and directional observation interpretation. The construction-stage settlement increments are 199.3, 95.5 and 14.9 mm, with rates 24.9, 5.6 and 0.9 mm/day. |

For +860, pressure and deformation axes begin on 10 April and 4 April 2023,
respectively. Subtract six days from deformation time to align the axes;
retain fractional elapsed times for calculations. Rounded calendar dates are
display information. This alignment does not identify the excavation date.
GD00 is crown settlement; SL01, SL02 and SL03 are line closures at 2.5, 6.0 and
9.5 m below the crown. Contact pressure is in kPa and deformation in mm.

`data/geometry/tangent_arcs.json` supplies the six tangent arcs of the benchmark
horseshoe in metres. It represents the supplied main-tunnel section, with width
13.46 m and height 11.05 m. The separate file
`data/geometry/field_860_section_geometry.json` supplies the +860 field section,
reconstructed from the design radii, crown angle and section height, with
tangency imposed between adjacent arcs. The ground-contact contour is the initial-support outer boundary:
height 10.82 m, maximum width 9.519 m and area 83.509 m². Its inward normal offset
by 0.27 m defines the monitoring contour. Line depths are measured from the inner
crown; each endpoint uses the ground displacement at its outward-normal counterpart.
The 0.40 m secondary lining thickness is a separate design dimension. The bench
is 7.5 m below the outer crown, and the retained bottom slice is 0.5 m high.
The field far boundary is a 39.2 m circle; 4.9 m remains a neural feature length
scale rather than defining the opening area.

For the specimen calculation, the additional axial load is force divided by the
original area, while confining pressure acts on the current area. Hold increments
refer to each hold's first recorded axial strain. The field PINN uses each instrument's first
reading as the reference. Physical parameters are calibrated through pressure
day 14.5277778 and then held fixed for the continuing cumulative response.
Bottom removal over days 13-15 is an equivalent construction
scenario motivated by the localized lower-line increment and invert-pressure
coverage, not a measured excavation calendar. Data from different sections are not
combined into a fictitious coincident measurement.

The continuing response uses measured pressure as a condition. The engineering
description also used the later monitored record during model development;
the comparison of cumulative histories is retrospective.
Fractional reading times and each instrument's first-reading reference are
retained. The final SL01 reading at day 25.055556 is preserved in the source data
but lies beyond the common evaluation interval.
