# Measurement and geometry sources

The CSV files contain digitized readings from author-supplied research-programme
reports. They are not instrument exports. This package selects the columns
needed for the reported calculations without changing their values. The report
titles below identify the underlying sources; English descriptions are translations.

| Files | Source and scientific role |
|---|---|
| `data/laboratory/phyllite_creep_strain_vs_time_cp15.csv`, `data/laboratory/phyllite_creep_strain_vs_time_cp20.csv`, `data/laboratory/phyllite_creep_strain_vs_time_cp25.csv` | *极高地应力环境下隧道围岩力学特性与变形预测方法*, 2022 annual execution report, dated 25 November 2022. Saturated-phyllite triaxial creep at 15, 20 and 25 MPa confinement supplies the manuscript's material comparison. `series` gives deviatoric load in MPa, `time_h` is time in hours, and `axial_strain_1e-2` is axial strain in percent. Levels two and three at 15 and 25 MPa supply the calibration objective; the corresponding 20 MPa curves supply the retrospective held-group comparison. All first and fourth levels are also evaluated. |
| `data/stress/principal_stress_vs_depth_yaan_luding.csv` | The same 2022 report. Separate regional maximum-horizontal, minimum-horizontal and vertical stress trends; depth in m and stress in MPa. |
| `data/field/x4dk0p860_surrounding_rock_pressure_timehistory.csv` and `x4dk0p860_cumulative_deformation_timehistory.csv` | *刚度自适应新型隧道支护结构体系及其工程应用*, midterm execution report, China Railway Eryuan Engineering Group, 29 August 2023, Figures 65 and 70. Contact pressure supplies the boundary input. The 55 settlement and closure readings through day 14.5277778 calibrate six effective physical parameters. The continuing neural history is evaluated against 43 later readings in the common interval; the data retain all 99 source readings. Table 23 supplies the stress, depth and equivalent-radius conditions. Individual carbonaceous-slate tests supply the stiffness evidence. |
| `data/material/carbonaceous_slate.json` | The detailed scientific and technical report with the same title, August 2023, Section 6.3.2: individual intact carbonaceous-slate specimens 9, 17, 42 and 47 give 114.12, 143.01, 214.22 and 182.01 MPa. Broken specimen 25 has 16.66 MPa compaction and 114.76 MPa subsequent loading slopes; badly broken specimen 31 gives 4.91 MPa. Soft intact specimen 1 gives 345.32 MPa, used as a nominal directional scale, with an effective base modulus below it. The individual tests constrain the material family; the displacement calibration determines its effective base modulus. Figure 6.151 labels the nominal section height as 10.82 m. |
| `data/field/x4dk0933_surrounding_rock_pressure_timehistory.csv` | *基于刚度协同的大变形隧道谱系化设计方法与系统平台*, research report, Figure 56. A separate section constrains the interpretation of spatially variable contact pressure. |
| `data/stress/field_principal_stress_vs_depth.csv` | *基于刚度协同的大变形隧道谱系化设计方法与系统平台*, field-test implementation plan. Maximum principal stress in MPa against depth in m provides a local stress-scale comparison. |
| `data/field/dk0p900_cumulative_deformation_vs_time.csv` | *大变形多阶段动态风险定量评估模型及监测预警平台测试报告*, Shijiazhuang Tiedao University, Section 3.1.3(2). The `series` column distinguishes settlement and the three closures, `days_d` gives time in days, and `cumulative_deformation_mm` gives displacement in mm. This separate section informs construction-prehistory and directional observation interpretation. The reported construction-stage settlement increments are 199.3, 95.5 and 14.9 mm, with rates 24.9, 5.6 and 0.9 mm/day. |

For +860, pressure and deformation axes begin on 10 April and 4 April 2023,
respectively. Subtract six days from deformation time to align the axes;
retain fractional elapsed times for calculations. Rounded calendar dates are
display information. This alignment does not identify the excavation date.
GD00 is crown settlement; SL01, SL02 and SL03 are line closures at 2.5, 6.0 and
9.5 m below the crown. Contact pressure is in kPa and deformation in mm.

`data/geometry/tangent_arcs.json` supplies the six tangent arcs of the benchmark
horseshoe in metres. It represents the supplied main-tunnel section, with width
13.46 m and height 11.05 m. The separate file
`data/geometry/field_860_section_geometry.json` supplies the +860 field section,
reconstructed from Figure 6.151 of the detailed scientific and technical report
*刚度自适应新型隧道支护结构体系及其工程应用*, printed page 211, covering
X4DK0+875--+855. The ground-contact contour is the initial-support outer boundary:
height 10.82 m, maximum width 9.519 m and area 83.509 m². Its inward normal offset
by 0.27 m defines the monitoring contour. Line depths are measured from the inner
crown; each endpoint uses the ground displacement at its outward-normal counterpart.
The 0.40 m secondary lining thickness is a separate design dimension. The bench
is 7.5 m below the outer crown, and the retained bottom slice is 0.5 m high.
The field far boundary is a 39.2 m circle; 4.9 m remains a neural feature length
scale rather than defining the opening area.

Confinement groups 15 and 25 MPa, levels two and three, calibrate the laboratory
models. The 20 MPa group is a retrospective held-group comparison; all first
and fourth levels remain in the predictions. The field PINN uses each instrument's first
reading as the reference. Physical parameters are calibrated through pressure
day 14.5277778 and then held fixed for the continuing response. Five-day forecasts
use the last available reading as their observation reference. Bottom removal over days
13-15 is an equivalent construction
scenario motivated by the localized lower-line increment and invert-pressure
coverage, not a measured excavation calendar. Data from different sections are not
combined into a fictitious coincident measurement.

The five-day forecasts start at pressure days 15--19 and use subsequent measured
pressure as a condition. The engineering description also used the monitored
record during model development; these are retrospective conditional comparisons.
Fractional reading times and each instrument's first-reading reference are
retained. The final SL01 reading at day 25.055556 is preserved in the source data
but lies beyond the common evaluation interval.
